"""
Database Creation Script
Run this script to create the database and all tables for Fashion Finance application.

Usage:
    python create_database.py
"""

import mysql.connector
from mysql.connector import Error
from app.config.database import DatabaseConfig
from app.models.database import db
import sys
import io

# Fix Windows console encoding
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def create_database():
    """Create the database if it doesn't exist"""
    try:
        # Connect to MySQL server without specifying database
        connection = mysql.connector.connect(
            host=DatabaseConfig.HOST,
            user=DatabaseConfig.USER,
            password=DatabaseConfig.PASSWORD,
            port=DatabaseConfig.PORT
        )
        
        if connection.is_connected():
            cursor = connection.cursor()
            
            # Create database
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {DatabaseConfig.DATABASE}")
            print(f"[OK] Database '{DatabaseConfig.DATABASE}' created successfully (or already exists)")
            
            cursor.close()
            connection.close()
            return True
            
    except Error as e:
        print(f"[ERROR] Error creating database: {e}")
        print("\n[INFO] Common issues:")
        print("   1. MySQL server is not running (start XAMPP or MySQL service)")
        print("   2. Wrong password - check app/config/database.py")
        print("   3. User doesn't have permission to create databases")
        return False

def create_tables():
    """Create all tables using the Database class"""
    try:
        print("\n[INFO] Creating tables...")
        db.create_tables()
        print("[OK] All tables created successfully!")
        return True
    except Error as e:
        print(f"[ERROR] Error creating tables: {e}")
        return False

def test_connection():
    """Test the database connection"""
    try:
        print("\n[INFO] Testing database connection...")
        if db.test_connection():
            print("[OK] Database connection successful!")
            return True
        else:
            print("[ERROR] Database connection failed!")
            return False
    except Exception as e:
        print(f"[ERROR] Connection test error: {e}")
        return False

def show_config():
    """Display current database configuration"""
    print("\n" + "="*60)
    print("FASHION FINANCE - DATABASE SETUP")
    print("="*60)
    print(f"\n[CONFIG] Current Configuration:")
    print(f"   Host:     {DatabaseConfig.HOST}")
    print(f"   Port:     {DatabaseConfig.PORT}")
    print(f"   User:     {DatabaseConfig.USER}")
    print(f"   Password: {'*' * len(DatabaseConfig.PASSWORD) if DatabaseConfig.PASSWORD else '(empty)'}")
    print(f"   Database: {DatabaseConfig.DATABASE}")
    print("="*60 + "\n")

def main():
    """Main function to run database setup"""
    show_config()
    
    print("[START] Starting database setup...\n")
    
    # Step 1: Create database
    print("Step 1: Creating database...")
    if not create_database():
        print("\n[FAILED] Setup failed at database creation step")
        print("\n[INFO] Please check:")
        print("   1. Is MySQL running? (Check XAMPP or MySQL service)")
        print("   2. Is the password correct in app/config/database.py?")
        print("   3. Does the user have CREATE DATABASE permission?")
        sys.exit(1)
    
    # Step 2: Create tables
    print("\nStep 2: Creating tables...")
    if not create_tables():
        print("\n[FAILED] Setup failed at table creation step")
        sys.exit(1)
    
    # Step 3: Test connection
    if not test_connection():
        print("\n[WARNING] Tables created but connection test failed")
        sys.exit(1)
    
    # Success!
    print("\n" + "="*60)
    print("DATABASE SETUP COMPLETED SUCCESSFULLY!")
    print("="*60)
    print("\n[INFO] Tables created:")
    print("   [+] users          - User accounts (admin & kasir)")
    print("   [+] products       - Product inventory")
    print("   [+] customers      - Customer information")
    print("   [+] sales          - Sales transactions")
    print("   [+] sales_details  - Transaction line items")
    print("   [+] expenses       - Business expenses")
    print("\n[NEXT] You can now run the main application:")
    print("   python main.py")
    print("="*60 + "\n")

if __name__ == "__main__":
    main()
