"""Database compatibility layer - wraps new MySQL models to maintain compatibility with existing UI"""
import os
import shutil
from app.models.database import db as mysql_db
from app.models.product_model import ProductModel
from app.models.user_model import UserModel
from app.models.transaction_model import TransactionModel
from app.models.customer_model import CustomerModel
from app.models.expense_model import ExpenseModel
from app.models.report_model import ReportModel
from datetime import datetime

class Database:
    """Compatibility wrapper for old database interface using MySQL"""
    
    def __init__(self):
        self.conn = None  # Keep for compatibility, but not used
        self._tables_created = False
        self.create_images_folder()
    
    def _ensure_tables(self):
        """Ensure tables are created (lazy initialization)"""
        if not self._tables_created:
            try:
                mysql_db.create_tables()
                self._tables_created = True
            except Exception as e:
                # Don't fail if tables can't be created yet
                pass
    
    def create_images_folder(self):
        """Create images folder if not exists"""
        os.makedirs('images/products', exist_ok=True)
    
    # ========== AUTHENTICATION METHODS ==========
    
    def validate_owner(self, username, password):
        """Validate owner login (compatibility)"""
        self._ensure_tables()
        user = UserModel.authenticate(username, password)
        if user and user['role'] == 'admin':
            # Return in old format: (id, nama, email)
            return (user['id'], user['nama'], user['email'])
        return None
    
    def validate_kasir(self, username, password):
        """Validate kasir login (compatibility)"""
        self._ensure_tables()
        user = UserModel.authenticate(username, password)
        if user and user['role'] == 'kasir':
            # Return in old format: (id_kasir, nama_kasir, no_hp, alamat, nama_owner)
            # For compatibility, we'll use user data
            return (user['id'], user['nama'], user.get('no_hp', ''), user.get('alamat', ''), 'Owner')
        return None
    
    # ========== PRODUCT METHODS (BARANG) ==========
    
    def get_barang(self):
        """Get all products (compatibility)"""
        self._ensure_tables()
        products = ProductModel.get_all(active_only=False)
        # Convert to old format: (id_barang, nama_barang, kategori, stok, harga, kode_barang, nama_kasir, status, gambar)
        result = []
        for p in products:
            result.append((
                p['id'],
                p['nama_produk'],
                p['kategori'],
                p['stok'],
                float(p['harga_jual']),
                p['kode_produk'],
                p.get('user_nama', ''),
                p['status'],
                p.get('gambar', '')
            ))
        return result
    
    def add_barang(self, id_kasir, nama_barang, harga, stok, kode_barang, kategori, gambar_path=None):
        """Add new product (compatibility)"""
        try:
            ProductModel.create(kode_barang, nama_barang, kategori, harga, stok, id_kasir, gambar_path)
            return True
        except Exception:
            return False
    
    def update_barang(self, id_barang, nama_barang, harga, stok, kode_barang, kategori, gambar_path=None):
        """Update product (compatibility)"""
        updates = {
            'nama_produk': nama_barang,
            'harga_jual': harga,
            'stok': stok,
            'kode_produk': kode_barang,
            'kategori': kategori
        }
        if gambar_path:
            updates['gambar'] = gambar_path
        ProductModel.update(id_barang, **updates)
    
    def update_barang_gambar(self, id_barang, gambar_path):
        """Update product image (compatibility)"""
        ProductModel.update(id_barang, gambar=gambar_path)
    
    def get_barang_by_id(self, id_barang):
        """Get product by ID (compatibility)"""
        product = ProductModel.get_by_id(id_barang)
        if product:
            # Return as tuple in old format
            return (
                product['id'],
                product.get('user_id'),
                product['nama_produk'],
                float(product['harga_jual']),
                product['stok'],
                product['kode_produk'],
                product['kategori'],
                product.get('gambar', ''),
                product['status']
            )
        return None
    
    def copy_and_save_image(self, source_path, product_id, product_name):
        """Copy and save image (compatibility)"""
        if not source_path or not os.path.exists(source_path):
            return None
        
        try:
            os.makedirs('images/products', exist_ok=True)
            safe_name = "".join(c for c in product_name if c.isalnum() or c in (' ', '-', '_')).rstrip()
            safe_name = safe_name.replace(' ', '_').lower()
            file_extension = os.path.splitext(source_path)[1].lower()
            new_filename = f"{safe_name}_{product_id}{file_extension}"
            new_path = os.path.join('images', 'products', new_filename)
            shutil.copy2(source_path, new_path)
            return new_path
        except Exception as e:
            print(f"Error copying image: {e}")
            return None
    
    # ========== TRANSACTION METHODS ==========
    
    def create_transaksi(self, id_kasir, id_pembeli, total_harga, metode_pembayaran, items):
        """Create transaction (compatibility)"""
        try:
            sale_id = TransactionModel.create(id_kasir, id_pembeli, items, total_harga, metode_pembayaran)
            return sale_id
        except Exception as e:
            raise e
    
    def get_transaksi(self):
        """Get all transactions (compatibility)"""
        transactions = TransactionModel.get_all()
        # Convert to old format
        result = []
        for t in transactions:
            result.append((
                t['id'],
                t['tanggal_transaksi'],
                t.get('user_nama', ''),
                t.get('customer_nama', ''),
                float(t['total']),
                t['metode_pembayaran'],
                t['status']
            ))
        return result
    
    def get_detail_transaksi(self, id_transaksi):
        """Get transaction details (compatibility)"""
        details = TransactionModel.get_details(id_transaksi)
        # Convert to old format: (jumlah, subtotal, nama_barang, harga)
        result = []
        for d in details:
            result.append((
                d['quantity'],
                float(d['subtotal']),
                d['nama_produk'],
                float(d['harga_satuan'])
            ))
        return result
    
    # ========== CUSTOMER METHODS (PEMBELI) ==========
    
    def get_pembeli(self):
        """Get all customers (compatibility)"""
        customers = CustomerModel.get_all()
        # Convert to old format: (id_pembeli, nama_pembeli, no_hp, alamat)
        result = []
        for c in customers:
            result.append((
                c['id'],
                c['nama_pembeli'],
                c.get('no_hp', ''),
                c.get('alamat', '')
            ))
        return result
    
    def add_pembeli(self, nama_pembeli, no_hp, alamat):
        """Add customer (compatibility)"""
        return CustomerModel.create(nama_pembeli, no_hp, alamat)
    
    # ========== USER METHODS (KASIR) ==========
    
    def get_kasir(self):
        """Get all kasir/users (compatibility)"""
        users = UserModel.get_all()
        # Convert to old format
        result = []
        for u in users:
            if u['role'] == 'kasir':
                result.append((
                    u['id'],
                    u['nama'],
                    u['username'],
                    u.get('no_hp', ''),
                    u.get('alamat', ''),
                    u.get('tanggal_bergabung'),
                    None,  # id_owner (not used in new schema)
                    'Owner'  # nama_owner (placeholder)
                ))
        return result
    
    def add_kasir(self, nama_kasir, username, password, no_hp, alamat, id_owner):
        """Add kasir/user (compatibility)"""
        UserModel.create(username, password, None, nama_kasir, 'kasir', no_hp, alamat)
    
    # ========== DASHBOARD & REPORTS ==========
    
    def get_dashboard_data(self):
        """Get dashboard data (compatibility)"""
        stats = ReportModel.get_dashboard_stats()
        recent_sales = ReportModel.get_recent_sales(5)
        best_sellers = ReportModel.get_best_selling_products(5)
        
        # Convert to old format
        recent_sales_list = []
        for sale in recent_sales:
            recent_sales_list.append((
                sale['id'],
                sale.get('customer_nama', ''),
                float(sale['total']),
                sale['tanggal_transaksi']
            ))
        
        best_sellers_list = []
        for seller in best_sellers:
            best_sellers_list.append((
                seller['nama_produk'],
                int(seller['total_terjual'])
            ))
        
        return {
            'total_sales': float(stats.get('total_sales', 0)),
            'total_transactions': stats.get('total_transactions', 0),
            'total_products': stats.get('total_products', 0),
            'total_stock': stats.get('total_stock', 0),
            'recent_sales': recent_sales_list,
            'best_sellers': best_sellers_list
        }
    
    # ========== SALES DATA (COMPATIBILITY) ==========
    
    def get_sales_data(self):
        """Get sales data (compatibility)"""
        today_stats = TransactionModel.get_today_sales()
        recent = TransactionModel.get_all(10)
        
        # Convert to old format
        recent_list = []
        for t in recent:
            # Get item count
            details = TransactionModel.get_details(t['id'])
            item_count = len(details) if details else 0
            
            recent_list.append((
                t['id'],
                t['tanggal_transaksi'],
                t.get('customer_nama', 'Pembeli Umum'),
                item_count,
                float(t['total']),
                t['status']
            ))
        
        return {
            'today_sales': float(today_stats.get('total_sales', 0)) if today_stats else 0,
            'today_transactions': today_stats.get('total_transactions', 0) if today_stats else 0,
            'recent_transactions': recent_list
        }
    
    def get_products(self):
        """Get active products (compatibility)"""
        products = ProductModel.get_all(active_only=True)
        # Convert to old format: (id_barang, nama_barang, kategori, stok, harga, kode_barang, gambar)
        result = []
        for p in products:
            if p['stok'] > 0:  # Only products with stock > 0
                result.append((
                    p['id'],
                    p['nama_produk'],
                    p['kategori'],
                    p['stok'],
                    float(p['harga_jual']),
                    p['kode_produk'],
                    p.get('gambar', '')
                ))
        return result
    
    def add_sale(self, transaction_id, product_id, product_name, quantity, amount):
        """Add sale (compatibility - simplified)"""
        # This is a simplified method, actual implementation should use TransactionModel.create
        # For now, we'll create a basic transaction
        customer_id = CustomerModel.get_or_create_default()
        items = [{
            'product_id': product_id,
            'quantity': quantity,
            'harga_satuan': amount / quantity,
            'subtotal': amount
        }]
        # Get first user as kasir
        users = UserModel.get_all()
        user_id = users[0]['id'] if users else 1
        TransactionModel.create(user_id, customer_id, items, amount, 'Tunai')
    
    # ========== EXPENSES METHODS ==========
    
    def get_expenses_data(self):
        """Get expenses data (compatibility)"""
        expenses = ExpenseModel.get_all(10)
        total = ExpenseModel.get_total()
        
        # Convert to old format: (date, description, category, amount, status, id)
        expenses_list = []
        for e in expenses:
            expenses_list.append((
                e['tanggal'],
                e['deskripsi'],
                e['kategori'],
                float(e['jumlah']),
                e['status'],
                e['id']
            ))
        
        return {
            'recent_expenses': expenses_list,
            'total_expenses': float(total)
        }
    
    def add_expense(self, date, description, category, amount, status):
        """Add expense (compatibility)"""
        ExpenseModel.create(date, description, category, amount, status)
    
    # ========== REPORTS METHODS ==========
    
    def get_reports_data(self):
        """Get reports data (compatibility)"""
        now = datetime.now()
        performance = ReportModel.get_monthly_performance(now.year, now.month)
        
        return {
            'monthly_sales': float(performance['monthly_sales']),
            'monthly_expenses': float(performance['monthly_expenses']),
            'monthly_profit': float(performance['monthly_profit']),
            'margin': float(performance['margin'])
        }

# Global database instance for compatibility
db = Database()
