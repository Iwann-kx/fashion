import traceback

try:
    import importlib
    importlib.invalidate_caches()
    import ui_login
    print('Loaded ui_login OK:', hasattr(ui_login, 'LoginWindow'))
except Exception:
    traceback.print_exc()
