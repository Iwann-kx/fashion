
import sys
from PyQt5.QtWidgets import QApplication
from app.views.ui_login import LoginView

def test_signal():
    app = QApplication(sys.argv)
    
    try:
        login_window = LoginView()
        print(f"LoginView created: {login_window}", flush=True)
        
        if hasattr(login_window, 'loginSuccessful'):
            print("SUCCESS: loginSuccessful signal FOUND", flush=True)
        else:
            print("FAILURE: loginSuccessful signal NOT FOUND", flush=True)
            
        # Check dir() to see what attributes exist
        print("Attributes:", dir(login_window), flush=True)
            
    except Exception as e:
        print(f"ERROR: {e}", flush=True)

if __name__ == "__main__":
    test_signal()
