# migrate_database.py
import sqlite3
import os
from datetime import datetime

def migrate_database():
    """Migrate dari struktur lama ke struktur baru sesuai EER"""
    
    # Backup database lama
    if os.path.exists('fashion_finance.db'):
        backup_name = f'fashion_finance_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.db'
        os.rename('fashion_finance.db', backup_name)
        print(f"Database lama di-backup sebagai: {backup_name}")
    
    # Import database baru
    from database import Database
    db = Database()
    print("Migrasi database berhasil! Struktur baru sudah sesuai EER diagram.")
    
    # Test data
    conn = sqlite3.connect('fashion_finance.db')
    cursor = conn.cursor()
    
    # Check tables
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = cursor.fetchall()
    print("\nTabel yang tersedia:")
    for table in tables:
        print(f"- {table[0]}")
    
    # Check sample data
    print("\nSample Data:")
    cursor.execute("SELECT COUNT(*) FROM owners")
    print(f"Owners: {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(*) FROM kasir")
    print(f"Kasir: {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(*) FROM barang")
    print(f"Barang: {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(*) FROM pembeli")
    print(f"Pembeli: {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(*) FROM transaksi")
    print(f"Transaksi: {cursor.fetchone()[0]}")
    
    conn.close()

if __name__ == "__main__":
    migrate_database()