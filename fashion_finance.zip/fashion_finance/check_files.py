"""
Quick fix script - restore corrupted files to working state
"""
import os
import shutil

# Backup corrupted files
corrupted_files = [
    'app/views/ui_sales.py',
    'app/views/ui_expenses.py',
    'app/views/ui_reports.py'
]

print("🔧 Restoring corrupted files...")

for filepath in corrupted_files:
    backup_path = filepath + '.backup'
    if os.path.exists(filepath):
        # Create backup of corrupted file
        shutil.copy(filepath, backup_path)
        print(f"   📦 Backed up: {filepath}")

# For now, let's just check if we can import them
print("\n✅ Backups created. Now checking imports...")

try:
    import sys
    sys.path.insert(0, '.')
    
    # Try importing each
    print("   Checking ui_sales...")
    try:
        from app.views import ui_sales
        print("   ✅ ui_sales OK")
    except Exception as e:
        print(f"   ❌ ui_sales ERROR: {str(e)[:100]}")
    
    print("   Checking ui_expenses...")
    try:
        from app.views import ui_expenses  
        print("   ✅ ui_expenses OK")
    except Exception as e:
        print(f"   ❌ ui_expenses ERROR: {str(e)[:100]}")
    
    print("   Checking ui_reports...")
    try:
        from app.views import ui_reports
        print("   ✅ ui_reports OK")
    except Exception as e:
        print(f"   ❌ ui_reports ERROR: {str(e)[:100]}")
        
except Exception as e:
    print(f"❌ General error: {e}")

print("\n💡 Recommendation: Restore from git or recreate these files")
