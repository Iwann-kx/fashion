import subprocess
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler


class ReloadHandler(FileSystemEventHandler):
    def on_modified(self, event):
        if event.src_path.endswith('.py'):
            print(f"Detected change in {event.src_path}, reloading...")
            run_app()
            
process = None

def run_app():
    global process
    if process:
        process.terminate()
    process = subprocess.Popen(['python', 'fashion-finance/main.py'])
    
if __name__ == "__main__":
    run_app()
    
    event_handler = ReloadHandler()
    observer = Observer()
    observer.schedule(event_handler, path='fashion_finance', recursive=True)
    observer.start()
    observer.join()