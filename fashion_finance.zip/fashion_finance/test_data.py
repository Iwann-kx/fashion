# test_data.py
import mysql.connector
from mysql.connector import Error

def test_data_operations():
    """Test operasi CRUD pada database"""
    try:
        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='fashion_finance'
        )
        
        if connection.is_connected():
            cursor = connection.cursor()
            
            print("🔍 TESTING DATABASE CONNECTION...")
            print("=" * 50)
            
            # 1. Test READ - Ambil data users
            print("1. Testing READ operation...")
            cursor.execute("SELECT id, username, role FROM users LIMIT 5")
            users = cursor.fetchall()
            
            print(f"   📝 Data users (total: {len(users)}):")
            for user in users:
                print(f"      ID: {user[0]}, Username: {user[1]}, Role: {user[2]}")
            
            # 2. Test READ - Ambil data products
            print("\n2. Testing PRODUCTS table...")
            cursor.execute("SELECT COUNT(*) as total_products FROM products")
            total_products = cursor.fetchone()[0]
            print(f"   📦 Total produk: {total_products}")
            
            cursor.execute("SELECT kode_produk, nama_produk, harga_jual, stok FROM products LIMIT 3")
            products = cursor.fetchall()
            
            print("   📋 Sample produk:")
            for product in products:
                print(f"      Kode: {product[0]}, Nama: {product[1]}, Harga: Rp {product[2]:,}, Stok: {product[3]}")
            
            # 3. Test COUNT semua tabel
            print("\n3. Testing COUNT semua tabel...")
            cursor.execute("SHOW TABLES")
            tables = cursor.fetchall()
            
            for table in tables:
                table_name = table[0]
                cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                count = cursor.fetchone()[0]
                print(f"   📊 {table_name}: {count} records")
            
            # 4. Test INSERT (opsional)
            print("\n4. Testing INSERT operation...")
            try:
                cursor.execute("""
                    INSERT INTO expenses (kategori, deskripsi, jumlah, tanggal, user_id) 
                    VALUES ('Test', 'Data testing connection', 10000, CURDATE(), 1)
                """)
                connection.commit()
                print("   ✅ INSERT test berhasil!")
                
                # Hapus data test
                cursor.execute("DELETE FROM expenses WHERE deskripsi = 'Data testing connection'")
                connection.commit()
                print("   ✅ CLEANUP test data berhasil!")
                
            except Exception as e:
                print(f"   ⚠️  INSERT test skipped: {e}")
            
            cursor.close()
            connection.close()
            
            print("=" * 50)
            print("🎉 SEMUA TEST BERHASIL! Database terhubung dengan baik.")
            return True
            
    except Error as e:
        print(f"❌ TEST GAGAL: {e}")
        return False

if __name__ == "__main__":
    test_data_operations()