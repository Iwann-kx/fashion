# Fashion Finance - Business Management System

A modular, MVC-based fashion business management application built with PyQt5 and MySQL.

## Architecture

This project follows the **Model-View-Controller (MVC)** architecture pattern:

```
fashion_finance/
├── app/
│   ├── config/          # Configuration files
│   │   └── database.py  # Database configuration
│   ├── models/          # Data models (database operations)
│   │   ├── database.py  # MySQL connection manager
│   │   ├── user_model.py
│   │   ├── product_model.py
│   │   ├── transaction_model.py
│   │   ├── customer_model.py
│   │   ├── expense_model.py
│   │   └── report_model.py
│   ├── controllers/     # Business logic controllers
│   │   ├── auth_controller.py
│   │   ├── product_controller.py
│   │   ├── transaction_controller.py
│   │   ├── expense_controller.py
│   │   └── report_controller.py
│   ├── views/           # UI components (to be migrated)
│   └── utils/           # Utility functions
├── ui_*.py              # UI views (existing, using compatibility layer)
├── main.py              # Application entry point
├── database.py          # Compatibility wrapper for existing UI
└── requirements.txt     # Python dependencies
```

## Features

- **User Management**: Admin and Cashier roles with authentication
- **Product Management**: Inventory tracking with images
- **Sales Management**: Transaction processing and tracking
- **Expense Tracking**: Business expense management
- **Reports & Analytics**: Dashboard with statistics and reports
- **MySQL Database**: Robust database backend

## Setup

### Prerequisites

- Python 3.7+
- MySQL Server (XAMPP recommended)
- PyQt5

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd fashion_finance
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure MySQL**
   - Start MySQL server (XAMPP or standalone)
   - Create database:
     ```sql
     CREATE DATABASE fashion_finance;
     ```

4. **Configure database connection**
   - Edit `app/config/database.py` if needed:
     ```python
     HOST = 'localhost'
     USER = 'root'
     PASSWORD = ''
     DATABASE = 'fashion_finance'
     PORT = 3306
     ```

5. **Run migration (if migrating from SQLite)**
   ```bash
   python migrate_to_mysql.py
   ```

6. **Run the application**
   ```bash
   python main.py
   ```

## Database Schema

The application uses the following main tables:

- **users**: User accounts (admin/kasir)
- **products**: Product inventory
- **customers**: Customer information
- **sales**: Sales transactions
- **sales_details**: Transaction line items
- **expenses**: Business expenses

## Project Structure

### Models (`app/models/`)
- Handle all database operations
- Use MySQL connection pool
- Provide data access layer

### Controllers (`app/controllers/`)
- Implement business logic
- Validate data
- Coordinate between models and views

### Views (`ui_*.py`)
- PyQt5 UI components
- Currently use compatibility layer (`database.py`)
- Can be gradually migrated to use controllers directly

### Compatibility Layer (`database.py`)
- Wraps new MySQL models
- Maintains compatibility with existing UI code
- Allows gradual migration

## Development

### Adding New Features

1. **Create Model** (`app/models/`)
   - Define database operations
   - Use MySQL connection pool

2. **Create Controller** (`app/controllers/`)
   - Implement business logic
   - Validate inputs
   - Handle errors

3. **Update View** (`ui_*.py`)
   - Use controller methods
   - Update UI components

### Database Operations

Always use models, not direct database access:

```python
from app.models.product_model import ProductModel

# Get all products
products = ProductModel.get_all()

# Create product
product_id = ProductModel.create(
    kode_produk="PROD001",
    nama_produk="Product Name",
    kategori="Category",
    harga_jual=100000,
    stok=50
)
```

## Migration from SQLite

If you have an existing SQLite database:

1. Ensure SQLite database file exists (`fashion_finance.db`)
2. Run migration script:
   ```bash
   python migrate_to_mysql.py
   ```
3. The script will:
   - Create MySQL tables
   - Migrate all data
   - Preserve relationships

## Troubleshooting

### Database Connection Issues

1. Check MySQL is running
2. Verify database exists
3. Check credentials in `app/config/database.py`
4. Ensure MySQL user has proper permissions

### Import Errors

- Ensure all dependencies are installed: `pip install -r requirements.txt`
- Check Python path includes project root

## License

[Your License Here]

## Contributing

[Contributing Guidelines Here]

