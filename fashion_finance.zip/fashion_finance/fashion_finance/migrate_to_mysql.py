"""Migration script to convert SQLite data to MySQL"""
import sqlite3
import mysql.connector
from mysql.connector import Error
from app.config.database import DatabaseConfig
from app.models.user_model import UserModel
import hashlib

def migrate_from_sqlite(sqlite_db_path='fashion_finance.db'):
    """Migrate data from SQLite to MySQL"""
    
    # Connect to SQLite
    try:
        sqlite_conn = sqlite3.connect(sqlite_db_path)
        sqlite_cursor = sqlite_conn.cursor()
        print("✅ Connected to SQLite database")
    except Exception as e:
        print(f"❌ Error connecting to SQLite: {e}")
        return False
    
    # Connect to MySQL
    try:
        mysql_conn = mysql.connector.connect(**DatabaseConfig.get_connection_params())
        mysql_cursor = mysql_conn.cursor()
        print("✅ Connected to MySQL database")
    except Error as e:
        print(f"❌ Error connecting to MySQL: {e}")
        return False
    
    try:
        # Migrate users (from owners and kasir)
        print("\n📦 Migrating users...")
        sqlite_cursor.execute("SELECT * FROM owners")
        owners = sqlite_cursor.fetchall()
        
        for owner in owners:
            id_owner, nama_owner, username, password, email = owner
            try:
                UserModel.create(username, password, email, nama_owner, 'admin')
                print(f"  ✓ Migrated owner: {username}")
            except Exception as e:
                print(f"  ⚠ Owner {username} already exists or error: {e}")
        
        sqlite_cursor.execute("SELECT * FROM kasir")
        kasirs = sqlite_cursor.fetchall()
        
        for kasir in kasirs:
            id_kasir, nama_kasir, username, password, no_hp, alamat, tanggal_bergabung, id_owner = kasir
            try:
                UserModel.create(username, password, None, nama_kasir, 'kasir', no_hp, alamat)
                print(f"  ✓ Migrated kasir: {username}")
            except Exception as e:
                print(f"  ⚠ Kasir {username} already exists or error: {e}")
        
        # Migrate products (barang)
        print("\n📦 Migrating products...")
        sqlite_cursor.execute("SELECT * FROM barang")
        products = sqlite_cursor.fetchall()
        
        from app.models.product_model import ProductModel
        
        for product in products:
            id_barang, id_kasir, nama_barang, harga, stok, kode_barang, kategori, gambar, status = product
            try:
                ProductModel.create(kode_barang, nama_barang, kategori, harga, stok, id_kasir, gambar)
                print(f"  ✓ Migrated product: {nama_barang}")
            except Exception as e:
                print(f"  ⚠ Product {nama_barang} already exists or error: {e}")
        
        # Migrate customers (pembeli)
        print("\n📦 Migrating customers...")
        sqlite_cursor.execute("SELECT * FROM pembeli")
        customers = sqlite_cursor.fetchall()
        
        from app.models.customer_model import CustomerModel
        
        for customer in customers:
            id_pembeli, nama_pembeli, no_hp, alamat = customer
            try:
                CustomerModel.create(nama_pembeli, no_hp, alamat)
                print(f"  ✓ Migrated customer: {nama_pembeli}")
            except Exception as e:
                print(f"  ⚠ Customer {nama_pembeli} already exists or error: {e}")
        
        # Migrate transactions (transaksi)
        print("\n📦 Migrating transactions...")
        sqlite_cursor.execute("SELECT * FROM transaksi")
        transactions = sqlite_cursor.fetchall()
        
        from app.models.transaction_model import TransactionModel
        from datetime import datetime
        
        # Get user mapping (old kasir id to new user id)
        user_mapping = {}
        mysql_cursor.execute("SELECT id, username FROM users WHERE role = 'kasir'")
        mysql_users = mysql_cursor.fetchall()
        # We'll need to map based on some logic, for now use first kasir
        
        for transaksi in transactions:
            id_transaksi, id_kasir, id_pembeli, tanggal_transaksi, total_harga, metode_pembayaran, status = transaksi
            # Get details
            sqlite_cursor.execute("SELECT * FROM detail_transaksi WHERE id_transaksi = ?", (id_transaksi,))
            details = sqlite_cursor.fetchall()
            
            # Get new user_id (use first kasir for now)
            mysql_cursor.execute("SELECT id FROM users WHERE role = 'kasir' LIMIT 1")
            user_result = mysql_cursor.fetchone()
            user_id = user_result[0] if user_result else 1
            
            # Get customer_id
            customer_id = id_pembeli if id_pembeli else None
            
            # Prepare items
            items = []
            for detail in details:
                id_detail, id_transaksi_old, id_barang, jumlah, subtotal = detail
                # Get product by old id (we need mapping)
                # For now, skip if product not found
                mysql_cursor.execute("SELECT id FROM products WHERE id = %s", (id_barang,))
                product_result = mysql_cursor.fetchone()
                if product_result:
                    product_id = product_result[0]
                    items.append({
                        'product_id': product_id,
                        'quantity': jumlah,
                        'harga_satuan': subtotal / jumlah if jumlah > 0 else 0,
                        'subtotal': subtotal
                    })
            
            if items:
                try:
                    # Convert datetime string to datetime object if needed
                    if isinstance(tanggal_transaksi, str):
                        tanggal_transaksi = datetime.strptime(tanggal_transaksi, '%Y-%m-%d %H:%M:%S')
                    
                    # Create transaction manually with old ID preservation
                    kode_transaksi = f"TRX-{id_transaksi}"
                    mysql_cursor.execute("""
                        INSERT INTO sales (kode_transaksi, user_id, customer_id, tanggal_transaksi, total, metode_pembayaran, status)
                        VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """, (kode_transaksi, user_id, customer_id, tanggal_transaksi, total_harga, metode_pembayaran, status))
                    sale_id = mysql_cursor.lastrowid
                    
                    # Insert details
                    for item in items:
                        mysql_cursor.execute("""
                            INSERT INTO sales_details (sale_id, product_id, quantity, harga_satuan, subtotal)
                            VALUES (%s, %s, %s, %s, %s)
                        """, (sale_id, item['product_id'], item['quantity'], item['harga_satuan'], item['subtotal']))
                    
                    print(f"  ✓ Migrated transaction: {kode_transaksi}")
                except Exception as e:
                    print(f"  ⚠ Transaction {id_transaksi} error: {e}")
        
        # Migrate expenses
        print("\n📦 Migrating expenses...")
        sqlite_cursor.execute("SELECT * FROM expenses")
        expenses = sqlite_cursor.fetchall()
        
        from app.models.expense_model import ExpenseModel
        
        for expense in expenses:
            id_expense, date, description, category, amount, status = expense
            try:
                ExpenseModel.create(date, description, category, amount, status)
                print(f"  ✓ Migrated expense: {description[:30]}")
            except Exception as e:
                print(f"  ⚠ Expense error: {e}")
        
        mysql_conn.commit()
        print("\n✅ Migration completed successfully!")
        return True
        
    except Exception as e:
        mysql_conn.rollback()
        print(f"\n❌ Migration error: {e}")
        return False
    finally:
        sqlite_cursor.close()
        sqlite_conn.close()
        mysql_cursor.close()
        mysql_conn.close()

if __name__ == "__main__":
    print("🔄 Starting migration from SQLite to MySQL...")
    print("=" * 60)
    
    # Check if SQLite database exists
    import os
    if not os.path.exists('fashion_finance.db'):
        print("⚠ SQLite database not found. Skipping migration.")
        print("MySQL database will be initialized with empty tables.")
    else:
        migrate_from_sqlite()
    
    print("\n" + "=" * 60)
    print("✅ Migration process completed!")

