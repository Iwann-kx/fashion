"""Transaction controller"""
from app.models.transaction_model import TransactionModel
from app.models.customer_model import CustomerModel
from app.models.product_model import ProductModel

class TransactionController:
    """Controller for transaction operations"""
    
    @staticmethod
    def create_transaction(user_id, items, customer_id=None, metode_pembayaran='Tunai'):
        """Create new transaction"""
        # Validate items and calculate total
        total = 0
        validated_items = []
        
        for item in items:
            product = ProductModel.get_by_id(item['product_id'])
            if not product:
                return False, f"Produk dengan ID {item['product_id']} tidak ditemukan"
            
            if product['stok'] < item['quantity']:
                return False, f"Stok {product['nama_produk']} tidak mencukupi"
            
            harga_satuan = product['harga_jual']
            subtotal = harga_satuan * item['quantity']
            total += subtotal
            
            validated_items.append({
                'product_id': item['product_id'],
                'quantity': item['quantity'],
                'harga_satuan': float(harga_satuan),
                'subtotal': float(subtotal)
            })
        
        # Get or create default customer if not provided
        if not customer_id:
            customer_id = CustomerModel.get_or_create_default()
        
        try:
            sale_id = TransactionModel.create(
                user_id, customer_id, validated_items, total, metode_pembayaran
            )
            return True, sale_id
        except Exception as e:
            return False, str(e)
    
    @staticmethod
    def get_all_transactions(limit=None):
        """Get all transactions"""
        return TransactionModel.get_all(limit)
    
    @staticmethod
    def get_transaction(sale_id):
        """Get transaction by ID"""
        return TransactionModel.get_by_id(sale_id)
    
    @staticmethod
    def get_transaction_details(sale_id):
        """Get transaction details"""
        return TransactionModel.get_details(sale_id)
    
    @staticmethod
    def get_today_statistics():
        """Get today's sales statistics"""
        return TransactionModel.get_today_sales()
    
    @staticmethod
    def get_transactions_by_date_range(start_date, end_date):
        """Get transactions by date range"""
        return TransactionModel.get_by_date_range(start_date, end_date)

