"""Header Components - Navigation header with role-based access control"""

from PyQt5.QtWidgets import QFrame, QHBoxLayout, QLabel
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QFont
from .buttons import NavButton


class NavigationHeader(QFrame):
    """
    Reusable navigation header with role-based access control.
    
    Signals:
        dashboard_clicked: Emitted when dashboard button is clicked
        inventory_clicked: Emitted when inventory button is clicked
        sales_clicked: Emitted when sales button is clicked
        expenses_clicked: Emitted when expenses button is clicked
        reports_clicked: Emitted when reports button is clicked
        settings_clicked: Emitted when settings button is clicked
        logout_clicked: Emitted when logout button is clicked
    
    Args:
        active_page (str): Current active page name
        user_role (str): User role ('admin' or 'kasir')
        parent: Parent widget
    """
    
    # Signals
    dashboard_clicked = pyqtSignal()
    inventory_clicked = pyqtSignal()
    sales_clicked = pyqtSignal()
    expenses_clicked = pyqtSignal()
    reports_clicked = pyqtSignal()
    settings_clicked = pyqtSignal()
    logout_clicked = pyqtSignal()
    
    def __init__(self, active_page="dashboard", user_role="kasir", parent=None):
        super().__init__(parent)
        self.active_page = active_page.lower()
        self.user_role = user_role.lower()
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        self.setFixedHeight(70)
        self.setStyleSheet("""
            QFrame {
                background-color: #2c3e50;
                color: white;
            }
        """)
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(30, 15, 30, 15)
        
        # Title
        title = QLabel("🏪 Fashion Finance")
        title.setFont(QFont("Arial", 20, QFont.Bold))
        title.setStyleSheet("color: white;")
        
        # Navigation buttons
        nav_layout = QHBoxLayout()
        nav_layout.setSpacing(10)
        
        self.dashboard_btn = NavButton("📊 Dashboard")
        self.inventory_btn = NavButton("📦 Inventori")
        self.sales_btn = NavButton("💳 Penjualan")
        self.expenses_btn = NavButton("📋 Pengeluaran")
        self.reports_btn = NavButton("📈 Laporan")
        self.settings_btn = NavButton("⚙️ Pengaturan")
        self.logout_btn = NavButton("🚪 Logout")
        
        # Connect signals
        self.dashboard_btn.clicked.connect(self.dashboard_clicked.emit)
        self.inventory_btn.clicked.connect(self.inventory_clicked.emit)
        self.sales_btn.clicked.connect(self.sales_clicked.emit)
        self.expenses_btn.clicked.connect(self.expenses_clicked.emit)
        self.reports_btn.clicked.connect(self.reports_clicked.emit)
        self.settings_btn.clicked.connect(self.settings_clicked.emit)
        self.logout_btn.clicked.connect(self.logout_clicked.emit)
        
        # Set active page
        self._set_active_button()
        
        # Apply role restrictions
        self._apply_role_restrictions()
        
        # Add buttons to layout
        nav_layout.addWidget(self.dashboard_btn)
        nav_layout.addWidget(self.inventory_btn)
        nav_layout.addWidget(self.sales_btn)
        nav_layout.addWidget(self.expenses_btn)
        nav_layout.addWidget(self.reports_btn)
        nav_layout.addWidget(self.settings_btn)
        nav_layout.addStretch()
        nav_layout.addWidget(self.logout_btn)
        
        layout.addWidget(title)
        layout.addStretch()
        layout.addLayout(nav_layout)
    
    def _set_active_button(self):
        """Set the active button based on current page"""
        buttons = {
            'dashboard': self.dashboard_btn,
            'inventory': self.inventory_btn,
            'sales': self.sales_btn,
            'expenses': self.expenses_btn,
            'reports': self.reports_btn,
            'settings': self.settings_btn
        }
        
        active_btn = buttons.get(self.active_page)
        if active_btn:
            active_btn.setEnabled(False)
    
    def _apply_role_restrictions(self):
        """Apply role-based access restrictions"""
        if self.user_role == "kasir":
            # Kasir has limited access
            self.inventory_btn.setEnabled(False)
            self.inventory_btn.setToolTip("Akses terbatas untuk kasir")
            self.reports_btn.setEnabled(False)
            self.reports_btn.setToolTip("Akses terbatas untuk kasir")
            self.settings_btn.setEnabled(False)
            self.settings_btn.setToolTip("Akses terbatas untuk kasir")
    
    def set_active_page(self, page_name):
        """Update the active page"""
        self.active_page = page_name.lower()
        # Re-enable all buttons first
        for btn in [self.dashboard_btn, self.inventory_btn, self.sales_btn, 
                    self.expenses_btn, self.reports_btn, self.settings_btn]:
            btn.setEnabled(True)
        # Set active and apply restrictions
        self._set_active_button()
        self._apply_role_restrictions()
