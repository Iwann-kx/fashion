"""Sales View - Refactored with modular components"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QScrollArea, QMessageBox, QFrame, QDialog,
                             QComboBox, QSpinBox, QDialogButtonBox)
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QFont, QPixmap
from app.components import (StatCard, NavigationHeader, DataTable, 
                            PrimaryButton, SearchInput, StyledComboBox)
from app.controllers.product_controller import ProductController
from app.controllers.transaction_controller import TransactionController
from app.utils.helpers import format_currency
from datetime import datetime
import os


class AddSaleDialog(QDialog):
    """Custom dialog for adding sales with product image preview"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.products_data = []
        self.init_ui()
    
    def init_ui(self):
        """Initialize the UI"""
        self.setWindowTitle("💳 Tambah Transaksi Penjualan")
        self.setFixedSize(700, 600)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        
        # Title
        title = QLabel("Tambah Transaksi Baru")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        title.setStyleSheet("color: #2c3e50; margin-bottom: 10px; background-color: #ecf0f1; padding: 10px; border-radius: 8px;")
        layout.addWidget(title)
        
        # Product selection with image
        product_layout = QHBoxLayout()
        product_layout.setSpacing(20)
        
        # Left: Product selection
        left_layout = QVBoxLayout()
        product_label = QLabel("🛍️ PILIH PRODUK")
        product_label.setFont(QFont("Arial", 12, QFont.Bold))
        product_label.setStyleSheet("color: #2c3e50; background-color: #f8f9fa; padding: 5px; border-radius: 4px;")
        
        self.product_combo = StyledComboBox()
        self.load_products()
        
        left_layout.addWidget(product_label)
        left_layout.addWidget(self.product_combo)
        
        # Right: Product image
        right_layout = QVBoxLayout()
        image_label = QLabel("🖼️ GAMBAR PRODUK")
        image_label.setFont(QFont("Arial", 12, QFont.Bold))
        image_label.setStyleSheet("color: #2c3e50; background-color: #f8f9fa; padding: 5px; border-radius: 4px;")
        
        self.product_image = QLabel()
        self.product_image.setFixedSize(150, 150)
        self.product_image.setStyleSheet("""
            QLabel {
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                background-color: #f8f9fa;
            }
        """)
        self.product_image.setAlignment(Qt.AlignCenter)
        self.product_image.setText("📷\nPilih produk\nuntuk melihat\ngambar")
        
        right_layout.addWidget(image_label)
        right_layout.addWidget(self.product_image, 0, Qt.AlignCenter)
        
        product_layout.addLayout(left_layout)
        product_layout.addLayout(right_layout)
        layout.addLayout(product_layout)
        
        # Quantity
        quantity_label = QLabel("📊 JUMLAH")
        quantity_label.setFont(QFont("Arial", 12, QFont.Bold))
        quantity_label.setStyleSheet("color: #2c3e50; background-color: #f8f9fa; padding: 5px; border-radius: 4px;")
        
        self.quantity_spin = QSpinBox()
        self.quantity_spin.setRange(1, 100)
        self.quantity_spin.setStyleSheet("""
            QSpinBox {
                padding: 12px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 14px;
                background-color: white;
            }
            QSpinBox:focus {
                border-color: #3498db;
            }
        """)
        self.quantity_spin.valueChanged.connect(self.calculate_total)
        
        layout.addWidget(quantity_label)
        layout.addWidget(self.quantity_spin)
        
        # Price and total
        price_layout = QHBoxLayout()
        price_label = QLabel("💰 HARGA SATUAN:")
        price_label.setFont(QFont("Arial", 12, QFont.Bold))
        self.price_label = QLabel("Rp 0")
        self.price_label.setFont(QFont("Arial", 14, QFont.Bold))
        self.price_label.setStyleSheet("color: #27ae60; background-color: #d5f4e6; padding: 8px 12px; border-radius: 6px;")
        price_layout.addWidget(price_label)
        price_layout.addStretch()
        price_layout.addWidget(self.price_label)
        
        total_layout = QHBoxLayout()
        total_label = QLabel("💵 TOTAL:")
        total_label.setFont(QFont("Arial", 14, QFont.Bold))
        self.total_label = QLabel("Rp 0")
        self.total_label.setFont(QFont("Arial", 18, QFont.Bold))
        self.total_label.setStyleSheet("color: #27ae60; background-color: #d5f4e6; padding: 12px 16px; border-radius: 8px; border: 2px solid #27ae60;")
        total_layout.addWidget(total_label)
        total_layout.addStretch()
        total_layout.addWidget(self.total_label)
        
        layout.addSpacing(15)
        layout.addLayout(price_layout)
        layout.addLayout(total_layout)
        layout.addStretch()
        
        # Buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.setStyleSheet("""
            QPushButton {
                padding: 12px 24px;
                border: none;
                border-radius: 6px;
                font-weight: bold;
                min-width: 100px;
            }
            QPushButton[text="OK"] {
                background-color: #27ae60;
                color: white;
            }
            QPushButton[text="OK"]:hover {
                background-color: #2ecc71;
            }
            QPushButton[text="Cancel"] {
                background-color: #95a5a6;
                color: white;
            }
        """)
        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
        # Connect product change
        self.product_combo.currentIndexChanged.connect(self.product_changed)
    
    def load_products(self):
        """Load products into combo box"""
        products = ProductController.get_all_products(active_only=True)
        self.product_combo.clear()
        self.products_data = []
        
        for product in products:
            stok = product.get('stok', 0)
            if stok > 0:
                price = float(product.get('harga_jual', 0))
                price_text = format_currency(price)
                image_icon = " 📷" if product.get('gambar') else ""
                self.product_combo.addItem(f"{product.get('nama_produk', '')} - {price_text} (Stok: {stok}){image_icon}")
                self.products_data.append(product)
        
        if self.products_data:
            self.product_combo.setCurrentIndex(0)
    
    def product_changed(self):
        """Handle product selection change"""
        if self.product_combo.currentIndex() >= 0:
            product = self.products_data[self.product_combo.currentIndex()]
            price = float(product.get('harga_jual', 0))
            self.price_label.setText(format_currency(price))
            self.load_product_image(product.get('gambar'))
            self.calculate_total()
    
    def load_product_image(self, image_path):
        """Load and display product image"""
        if image_path and os.path.exists(image_path):
            pixmap = QPixmap(image_path)
            scaled_pixmap = pixmap.scaled(150, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.product_image.setPixmap(scaled_pixmap)
        else:
            self.product_image.setText("📷\nTidak ada\ngambar")
    
    def calculate_total(self):
        """Calculate total price"""
        if self.product_combo.currentIndex() >= 0:
            product = self.products_data[self.product_combo.currentIndex()]
            total = float(product.get('harga_jual', 0)) * self.quantity_spin.value()
            self.total_label.setText(format_currency(total))
    
    def validate_and_accept(self):
        """Validate form before accepting"""
        if self.product_combo.currentIndex() < 0:
            QMessageBox.warning(self, "Error", "❌ PILIH PRODUK TERLEBIH DAHULU!")
            return
        
        product = self.products_data[self.product_combo.currentIndex()]
        stok = product.get('stok', 0)
        if self.quantity_spin.value() > stok:
            QMessageBox.warning(self, "Error", f"❌ STOK TIDAK MENCUKUPI! Stok tersedia: {stok}")
            return
        
        self.accept()
    
    def get_data(self):
        """Get form data"""
        product = self.products_data[self.product_combo.currentIndex()]
        return {
            'product_id': product.get('id'),
            'product_name': product.get('nama_produk', ''),
            'quantity': self.quantity_spin.value(),
            'amount': float(product.get('harga_jual', 0)) * self.quantity_spin.value()
        }


class SalesWindow(QWidget):
    """Sales window with transaction management"""
    
    # Signals
    back_clicked = pyqtSignal()
    inventory_clicked = pyqtSignal()
    expenses_clicked = pyqtSignal()
    reports_clicked = pyqtSignal()
    settings_clicked = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.init_ui()
    
    def init_ui(self):
        """Initialize the UI"""
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Header
        header = NavigationHeader("sales", "admin")
        header.dashboard_clicked.connect(self.back_clicked.emit)
        header.inventory_clicked.connect(self.inventory_clicked.emit)
        header.expenses_clicked.connect(self.expenses_clicked.emit)
        header.reports_clicked.connect(self.reports_clicked.emit)
        header.settings_clicked.connect(self.settings_clicked.emit)
        header.logout_clicked.connect(self.back_to_login)
        
        # Scroll area
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setStyleSheet("""
            QScrollArea { 
                border: none; 
                background-color: #f8f9fa;
            }
            QScrollBar:vertical {
                background-color: #e0e0e0;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background-color: #bdc3c7;
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #95a5a6;
            }
        """)
        
        # Content widget
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(20)
        
        # Page title
        self._add_page_title(content_layout)
        
        # Search and filter
        filter_layout = QHBoxLayout()
        filter_layout.setSpacing(15)
        
        search_input = SearchInput("🔍 Cari transaksi...")
        date_filter = StyledComboBox(["Semua Waktu", "Hari ini", "Minggu ini", "Bulan ini"])
        date_filter.setFixedWidth(180)
        
        filter_layout.addWidget(search_input)
        filter_layout.addWidget(date_filter)
        filter_layout.addStretch()
        
        content_layout.addLayout(filter_layout)
        
        # Stats section
        self.stats_layout = QHBoxLayout()
        self.stats_layout.setSpacing(20)
        content_layout.addLayout(self.stats_layout)
        
        # Table section
        table_section = self._create_table_section()
        content_layout.addWidget(table_section)
        content_layout.addStretch()
        
        scroll_area.setWidget(content_widget)
        
        # Add to main layout
        main_layout.addWidget(header)
        main_layout.addWidget(scroll_area, 1)
        
        self.setStyleSheet("background-color: #f8f9fa;")
        self.load_data()
    
    def _add_page_title(self, layout):
        """Add page title and subtitle"""
        page_title = QLabel("Penjualan")
        page_title.setFont(QFont("Arial", 24, QFont.Bold))
        page_title.setStyleSheet("color: #2c3e50; margin-bottom: 5px;")
        
        subtitle = QLabel("Kelola dan catat semua transaksi penjualan")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7f8c8d;")
        
        layout.addWidget(page_title)
        layout.addWidget(subtitle)
    
    def _create_table_section(self):
        """Create the table section"""
        table_frame = QFrame()
        table_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
                border: 1px solid #e0e0e0;
            }
        """)
        
        table_layout = QVBoxLayout(table_frame)
        table_layout.setSpacing(15)
        
        # Table header
        header_layout = QHBoxLayout()
        table_title = QLabel("Transaksi Terbaru")
        table_title.setFont(QFont("Arial", 18, QFont.Bold))
        table_title.setStyleSheet("color: #2c3e50;")
        
        add_btn = PrimaryButton("Tambah Transaksi", "➕")
        add_btn.clicked.connect(self.add_sale)
        
        header_layout.addWidget(table_title)
        header_layout.addStretch()
        header_layout.addWidget(add_btn)
        
        # Create table
        self.table = DataTable(["ID TRANSAKSI", "TANGGAL", "PRODUK", "JUMLAH", "TOTAL", "STATUS"])
        
        table_layout.addLayout(header_layout)
        table_layout.addWidget(self.table)
        
        return table_frame
    
    def load_data(self):
        """Load sales data"""
        # Clear existing stats
        self._clear_layout(self.stats_layout)
        
        # Create stat cards
        stats_data = [
            ("Total Penjualan", "Rp 15.750.000", "+8% dari bulan lalu", "#27ae60", "📈"),
            ("Transaksi Hari Ini", "8 transaksi", "+2 dari kemarin", "#3498db", "📊"),
            ("Rata-rata Transaksi", "Rp 156.250", "+5% dari kemarin", "#f39c12", "💰"),
            ("Produk Terlaris", "Dress Floral", "15 terjual", "#9b59b6", "🏆")
        ]
        
        for title, value, change, color, icon in stats_data:
            stat_card = StatCard(title, value, change, color, icon)
            self.stats_layout.addWidget(stat_card)
        
        self.stats_layout.addStretch()
        
        # Load transactions table
        transactions = TransactionController.get_all_transactions(limit=10)
        self.table.clear_data()
        
        for transaction in transactions:
            # Format data
            kode = transaction.get('kode_transaksi', f"TRX-{transaction.get('id', '')}")
            tanggal = transaction.get('tanggal_transaksi', '')
            if hasattr(tanggal, 'strftime'):
                date_str = tanggal.strftime('%Y-%m-%d')
            else:
                date_str = str(tanggal).split()[0] if tanggal else ''
            
            customer = transaction.get('customer_nama', 'Pembeli Umum')
            
            # Get item count
            details = TransactionController.get_transaction_details(transaction.get('id'))
            item_count = len(details) if details else 0
            
            amount = float(transaction.get('total', 0))
            status = transaction.get('status', 'Selesai')
            status_icon = "🟢" if status == "Selesai" else "🟡"
            
            # Add row
            self.table.add_row([
                f"🔖 {kode}",
                f"📅 {date_str}",
                f"🛍️ {customer}",
                f"📦 {item_count} items",
                f"💵 {format_currency(amount)}",
                f"{status_icon} {status}"
            ])
    
    def add_sale(self):
        """Add new sale"""
        dialog = AddSaleDialog(self)
        if dialog.exec_():
            data = dialog.get_data()
            items = [{
                'product_id': data['product_id'],
                'quantity': data['quantity']
            }]
            
            user_id = 1  # Default user
            success, result = TransactionController.create_transaction(
                user_id=user_id,
                items=items,
                customer_id=None,
                metode_pembayaran='Tunai'
            )
            
            if success:
                self.load_data()
                QMessageBox.information(self, "Sukses", "✅ TRANSAKSI BERHASIL DITAMBAHKAN!")
            else:
                QMessageBox.warning(self, "Error", f"❌ Gagal menambah transaksi: {result}")
    
    def back_to_login(self):
        """Handle logout"""
        reply = QMessageBox.question(self, "Konfirmasi", 
                                   "Apakah Anda yakin ingin logout?",
                                   QMessageBox.Yes | QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            self.back_clicked.emit()
    
    def _clear_layout(self, layout):
        """Clear all widgets from a layout"""
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()