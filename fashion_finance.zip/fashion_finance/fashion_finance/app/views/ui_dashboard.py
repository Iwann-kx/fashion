"""Dashboard View - Refactored with modular components"""

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QScrollArea
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QFont
from app.components import StatCard, InfoCard, ItemCard, NavigationHeader
from app.controllers.report_controller import ReportController
from app.utils.helpers import format_currency


class DashboardWindow(QWidget):
    """Dashboard window with overview statistics and recent activity"""
    
    # Signals
    inventory_clicked = pyqtSignal()
    sales_clicked = pyqtSignal()
    expenses_clicked = pyqtSignal()
    reports_clicked = pyqtSignal()
    settings_clicked = pyqtSignal()
    logout_clicked = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.user_role = "kasir"  # Default role
        self.init_ui()
    
    def init_ui(self):
        """Initialize the UI"""
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Header
        header = NavigationHeader("dashboard", self.user_role)
        header.inventory_clicked.connect(self.inventory_clicked.emit)
        header.sales_clicked.connect(self.sales_clicked.emit)
        header.expenses_clicked.connect(self.expenses_clicked.emit)
        header.reports_clicked.connect(self.reports_clicked.emit)
        header.settings_clicked.connect(self.settings_clicked.emit)
        header.logout_clicked.connect(self.logout_clicked.emit)
        
        # Scroll area for content
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setStyleSheet("""
            QScrollArea { 
                border: none; 
                background-color: #f8f9fa;
            }
            QScrollBar:vertical {
                background-color: #e0e0e0;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background-color: #bdc3c7;
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #95a5a6;
            }
        """)
        
        # Content widget
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(20)
        
        # Page title
        self._add_page_title(content_layout)
        
        # Stats cards
        self.stats_layout = QHBoxLayout()
        self.stats_layout.setSpacing(20)
        content_layout.addLayout(self.stats_layout)
        
        # Bottom section with recent sales and best sellers
        bottom_layout = QHBoxLayout()
        bottom_layout.setSpacing(20)
        
        # Recent sales card
        self.recent_sales_card = InfoCard()
        self.recent_sales_card.set_title("Penjualan Terbaru", "🛍️")
        self.recent_sales_content = QVBoxLayout()
        self.recent_sales_content.setSpacing(12)
        self.recent_sales_card.add_layout(self.recent_sales_content)
        
        # Best sellers card
        self.best_sellers_card = InfoCard()
        self.best_sellers_card.set_title("Produk Terlaris", "🏆")
        self.best_sellers_content = QVBoxLayout()
        self.best_sellers_content.setSpacing(12)
        self.best_sellers_card.add_layout(self.best_sellers_content)
        
        bottom_layout.addWidget(self.recent_sales_card)
        bottom_layout.addWidget(self.best_sellers_card)
        
        content_layout.addSpacing(20)
        content_layout.addLayout(bottom_layout)
        content_layout.addStretch()
        
        scroll_area.setWidget(content_widget)
        
        # Add to main layout
        main_layout.addWidget(header)
        main_layout.addWidget(scroll_area, 1)
        
        self.setStyleSheet("background-color: #f8f9fa;")
        self.load_data()
    
    def _add_page_title(self, layout):
        """Add page title and subtitle"""
        from PyQt5.QtWidgets import QLabel
        
        page_title = QLabel("Dashboard")
        page_title.setFont(QFont("Arial", 24, QFont.Bold))
        page_title.setStyleSheet("color: #2c3e50; margin-bottom: 5px;")
        
        subtitle = QLabel("Ringkasan keuangan bisnis fashion Anda")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7f8c8d;")
        
        layout.addWidget(page_title)
        layout.addWidget(subtitle)
    
    def set_user_role(self, role):
        """Set user role and update UI accordingly"""
        self.user_role = role
    
    def load_data(self):
        """Load dashboard data from controller"""
        # Get dashboard stats
        stats = ReportController.get_dashboard_stats()
        recent_sales_list = ReportController.get_recent_sales(5)
        best_sellers = ReportController.get_best_selling_products(5)
        
        # Clear existing stats
        self._clear_layout(self.stats_layout)
        
        # Create stat cards
        stats_data = [
            ("Total Penjualan", format_currency(stats.get('total_sales', 0)), 
             "+8% dari bulan lalu", "#27ae60", "📈"),
            ("Total Pengeluaran", format_currency(stats.get('total_expenses', 0)), 
             "+5% dari bulan lalu", "#e74c3c", "📉"),
            ("Keuntungan Bersih", format_currency(stats.get('total_sales', 0) - stats.get('total_expenses', 0)), 
             "+12% dari bulan lalu", "#2980b9", "💰"),
            ("Stok Produk", f"{stats.get('total_stock', 0)} pcs", 
             "+15 dari bulan lalu", "#f39c12", "📦")
        ]
        
        for title, value, change, color, icon in stats_data:
            stat_card = StatCard(title, value, change, color, icon)
            self.stats_layout.addWidget(stat_card)
        
        self.stats_layout.addStretch()
        
        # Update recent sales
        self._clear_layout(self.recent_sales_content)
        for sale in recent_sales_list:
            customer_name = sale.get('customer_nama', 'Pembeli Umum') or 'Pembeli Umum'
            amount = float(sale.get('total', 0))
            timestamp = sale.get('tanggal_transaksi', '')
            if hasattr(timestamp, 'strftime'):
                timestamp = timestamp.strftime('%d %b %Y - %H:%M')
            else:
                timestamp = str(timestamp)
            
            item_card = ItemCard()
            item_card.add_icon("💰", "#27ae60")
            item_card.add_text_content(customer_name, timestamp)
            item_card.add_value(format_currency(amount), "#27ae60")
            
            self.recent_sales_content.addWidget(item_card)
        
        # Update best sellers
        self._clear_layout(self.best_sellers_content)
        rank_colors = ["#e74c3c", "#3498db", "#f39c12", "#9b59b6", "#1abc9c"]
        
        for rank, seller in enumerate(best_sellers, 1):
            product_name = seller.get('nama_produk', 'Unknown')
            sold_count = int(seller.get('total_terjual', 0))
            
            rank_icon = "🥇" if rank == 1 else "🥈" if rank == 2 else "🥉" if rank == 3 else str(rank)
            rank_color = rank_colors[rank-1] if rank <= 5 else "#95a5a6"
            
            item_card = ItemCard()
            item_card.add_icon(rank_icon, rank_color)
            item_card.add_text_content(product_name, f"{sold_count} terjual")
            
            self.best_sellers_content.addWidget(item_card)
    
    def _clear_layout(self, layout):
        """Clear all widgets from a layout"""
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()