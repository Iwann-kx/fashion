from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QFrame, QLineEdit, QComboBox,
                             QMessageBox, QScrollArea)
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QFont
# Settings view - no database operations needed for now

class SettingsWindow(QWidget):
    dashboard_clicked = pyqtSignal()
    inventory_clicked = pyqtSignal()
    sales_clicked = pyqtSignal()
    expenses_clicked = pyqtSignal()
    reports_clicked = pyqtSignal()
    settings_clicked = pyqtSignal()
    profile_clicked = pyqtSignal()
    logout_clicked = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.user_role = "kasir"  # Default role
        self.init_ui()
        
    def init_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Header - SEPERTI DASHBOARD
        header = self.create_header()
        
        # Content dengan scroll area - SEPERTI DASHBOARD
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setStyleSheet("""
            QScrollArea { 
                border: none; 
                background-color: #f8f9fa;
            }
            QScrollBar:vertical {
                background-color: #e0e0e0;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background-color: #bdc3c7;
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #95a5a6;
            }
        """)
        
        # Content widget utama - SEPERTI DASHBOARD
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(20)
        
        # Page title - SEPERTI DASHBOARD
        page_title = QLabel("Pengaturan")
        page_title.setFont(QFont("Arial", 24, QFont.Bold))
        page_title.setStyleSheet("color: #2c3e50; margin-bottom: 5px;")
        
        subtitle = QLabel("Kelola pengaturan aplikasi dan preferensi")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7f8c8d;")
        
        content_layout.addWidget(page_title)
        content_layout.addWidget(subtitle)
        
        # Settings cards section - FIXED: tidak menggunakan layout yang sama
        settings_cards_layout = QHBoxLayout()
        settings_cards_layout.setSpacing(20)

        settings_cards_data = [
            ("Pengaturan Toko", "3 config", "Siap digunakan", "#3498db", "🏪"),
            ("Pengguna Aktif", "2 users", "Admin & Kasir", "#27ae60", "👥"), 
            ("Backup Data", "24 Nov 2024", "Backup terbaru", "#f39c12", "💾"),
            ("Profil Pengguna", "👤 Lihat", "Edit profil Anda", "#667eea", "👤")
        ]

        for title, value, status, color, icon in settings_cards_data:
            if title == "Profil Pengguna":
                # Create clickable profile card
                card = self.create_profile_card()
                settings_cards_layout.addWidget(card)
            else:
                settings_card = self.create_settings_card(title, value, status, color, icon)
                settings_cards_layout.addWidget(settings_card)

        content_layout.addLayout(settings_cards_layout)
        
        # Settings sections - FIXED: menggunakan layout terpisah
        settings_container = QWidget()
        settings_layout = QHBoxLayout(settings_container)
        settings_layout.setSpacing(20)
        settings_layout.setContentsMargins(0, 0, 0, 0)
        
        # Toko Settings
        toko_section = self.create_toko_section()
        
        # Aplikasi Settings
        app_section = self.create_app_section()
        
        settings_layout.addWidget(toko_section)
        settings_layout.addWidget(app_section)
        
        # Save button - SEPERTI DASHBOARD STYLE
        save_btn = QPushButton("💾 Simpan Pengaturan")
        save_btn.setFixedHeight(50)
        save_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                padding: 15px 30px;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        save_btn.setCursor(Qt.PointingHandCursor)
        save_btn.clicked.connect(self.save_settings)
        
        # Add all to content layout
        content_layout.addSpacing(20)
        content_layout.addWidget(settings_container)
        content_layout.addWidget(save_btn, 0, Qt.AlignCenter)
        content_layout.addStretch()
        
        # Set content widget to scroll area
        scroll_area.setWidget(content_widget)
        
        # Add to main layout
        main_layout.addWidget(header)
        main_layout.addWidget(scroll_area, 1)
        
        self.setLayout(main_layout)
        self.setStyleSheet("background-color: #f8f9fa;")

    def create_profile_card(self):
        """Membuat clickable profile card"""
        card_frame = QFrame()
        card_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 25px;
                border: 1px solid #e0e0e0;
            }
            QFrame:hover {
                background-color: #f8f9fa;
                border: 1px solid #667eea;
            }
        """)
        card_frame.setMinimumHeight(350)
        card_frame.setMinimumWidth(400)
        card_frame.setCursor(Qt.PointingHandCursor)
        
        card_layout = QVBoxLayout(card_frame)
        card_layout.setSpacing(8)
        
        # Header dengan icon
        header_layout = QHBoxLayout()
        icon_label = QLabel("👤")
        icon_label.setFont(QFont("Arial", 16))
        icon_label.setStyleSheet("color: #667eea;")
        
        card_title = QLabel("Profil Pengguna")
        card_title.setFont(QFont("Arial", 12))
        card_title.setStyleSheet("color: #7f8c8d;")
        
        header_layout.addWidget(icon_label)
        header_layout.addWidget(card_title)
        header_layout.addStretch()
        
        # Value
        value_label = QLabel("Lihat & Edit")
        value_label.setFont(QFont("Arial", 18, QFont.Bold))
        value_label.setStyleSheet("color: #667eea; margin-top: 5px;")
        
        # Status
        status_label = QLabel("Kelola profil dan pengaturan akun Anda")
        status_label.setFont(QFont("Arial", 11))
        status_label.setStyleSheet("color: #7f8c8d; font-weight: bold;")
        
        card_layout.addLayout(header_layout)
        card_layout.addWidget(value_label)
        card_layout.addWidget(status_label)
        card_layout.addStretch()
        
        # Make card clickable
        card_frame.mousePressEvent = lambda event: self.profile_clicked.emit()
        
        return card_frame

    def create_settings_card(self, title, value, status, color, icon):
        """Membuat settings card seperti stat card di dashboard"""
        card_frame = QFrame()
        card_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 25px;
                border: 1px solid #e0e0e0;
            }
        """)
        card_frame.setMinimumHeight(350)
        card_frame.setMinimumWidth(400)
        
        card_layout = QVBoxLayout(card_frame)
        card_layout.setSpacing(8)
        
        # Header dengan icon
        header_layout = QHBoxLayout()
        icon_label = QLabel(icon)
        icon_label.setFont(QFont("Arial", 16))
        icon_label.setStyleSheet("color: %s;" % color)
        
        card_title = QLabel(title)
        card_title.setFont(QFont("Arial", 12))
        card_title.setStyleSheet("color: #7f8c8d;")
        
        header_layout.addWidget(icon_label)
        header_layout.addWidget(card_title)
        header_layout.addStretch()
        
        # Value
        value_label = QLabel(value)
        value_label.setFont(QFont("Arial", 18, QFont.Bold))
        value_label.setStyleSheet("color: %s; margin-top: 5px;" % color)
        
        # Status
        status_label = QLabel(status)
        status_label.setFont(QFont("Arial", 11))
        status_label.setStyleSheet("color: #7f8c8d; font-weight: bold;")
        
        card_layout.addLayout(header_layout)
        card_layout.addWidget(value_label)
        card_layout.addWidget(status_label)
        
        return card_frame
    
    def create_toko_section(self):
        """Membuat section informasi toko"""
        section = QFrame()
        section.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 25px;
                border: 1px solid #e0e0e0;
            }
        """)
        section.setMinimumWidth(400)
        
        layout = QVBoxLayout(section)
        layout.setSpacing(20)
        
        # Section title
        section_title = QLabel("🏪 Informasi Toko")
        section_title.setFont(QFont("Arial", 18, QFont.Bold))
        section_title.setStyleSheet("color: #2c3e50; margin-bottom: 10px;")
        
        layout.addWidget(section_title)
        
        # Fields
        fields = [
            ("Nama Toko", QLineEdit(), "Fashion Finance"),
            ("Alamat", QLineEdit(), "Jl. Contoh No. 123"),
            ("Telepon", QLineEdit(), "(021) 1234-5678"),
            ("Email", QLineEdit(), "info@fashionfinance.com")
        ]
        
        for field_name, widget, placeholder in fields:
            field_layout = QVBoxLayout()
            
            field_label = QLabel(field_name)
            field_label.setFont(QFont("Arial", 11, QFont.Bold))
            field_label.setStyleSheet("color: #2c3e50; margin-bottom: 8px;")
            
            widget.setObjectName(field_name)
            if isinstance(widget, QLineEdit):
                widget.setPlaceholderText(placeholder)
                widget.setStyleSheet("""
                    QLineEdit {
                        padding: 12px 15px;
                        border: 2px solid #e0e0e0;
                        border-radius: 8px;
                        font-size: 14px;
                        background-color: white;
                    }
                    QLineEdit:focus {
                        border-color: #3498db;
                    }
                """)
            
            field_layout.addWidget(field_label)
            field_layout.addWidget(widget)
            layout.addLayout(field_layout)
        
        return section
    
    def create_app_section(self):
        """Membuat section pengaturan aplikasi"""
        section = QFrame()
        section.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 25px;
                border: 1px solid #e0e0e0;
            }
        """)
        section.setMinimumWidth(400)
        
        layout = QVBoxLayout(section)
        layout.setSpacing(20)
        
        # Section title
        section_title = QLabel("⚙️ Pengaturan Aplikasi")
        section_title.setFont(QFont("Arial", 18, QFont.Bold))
        section_title.setStyleSheet("color: #2c3e50; margin-bottom: 10px;")
        
        layout.addWidget(section_title)
        
        # Fields
        fields = [
            ("Mata Uang", QComboBox(), "IDR - Rupiah"),
            ("Format Tanggal", QComboBox(), "DD/MM/YYYY"),
            ("Notifikasi", QComboBox(), "Aktif"),
            ("Tema", QComboBox(), "Light Mode")
        ]
        
        for field_name, widget, placeholder in fields:
            field_layout = QVBoxLayout()
            
            field_label = QLabel(field_name)
            field_label.setFont(QFont("Arial", 11, QFont.Bold))
            field_label.setStyleSheet("color: #2c3e50; margin-bottom: 8px;")
            
            widget.setObjectName(field_name)
            if isinstance(widget, QComboBox):
                if field_name == "Mata Uang":
                    widget.addItems(["IDR - Rupiah", "USD - US Dollar", "EUR - Euro"])
                elif field_name == "Format Tanggal":
                    widget.addItems(["DD/MM/YYYY", "MM/DD/YYYY", "YYYY-MM-DD"])
                elif field_name == "Notifikasi":
                    widget.addItems(["Aktif", "Nonaktif"])
                elif field_name == "Tema":
                    widget.addItems(["Light Mode", "Dark Mode", "Auto"])
                
                widget.setStyleSheet("""
                    QComboBox {
                        padding: 12px 15px;
                        border: 2px solid #e0e0e0;
                        border-radius: 8px;
                        font-size: 14px;
                        background-color: white;
                    }
                    QComboBox:focus {
                        border-color: #3498db;
                    }
                """)
            
            field_layout.addWidget(field_label)
            field_layout.addWidget(widget)
            layout.addLayout(field_layout)
        
        return section
    
    def create_header(self):
        header = QFrame()
        header.setFixedHeight(70)
        header.setStyleSheet("""
            QFrame {
                background-color: #2c3e50;
                color: white;
                border-bottom: 3px solid #3498db;
            }
        """)
        
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(30, 15, 30, 15)
        
        title = QLabel("🏪 Fashion Finance - Sistem Manajemen Pengaturan")
        title.setFont(QFont("Arial", 18, QFont.Bold))
        title.setStyleSheet("color: white;")
        
        nav_layout = QHBoxLayout()
        nav_layout.setSpacing(8)
        
        # Navigation buttons - SEPERTI DASHBOARD
        dashboard_btn = QPushButton("📊 Dashboard")
        inventory_btn = QPushButton("📦 Inventori")
        sales_btn = QPushButton("💳 Penjualan")
        expenses_btn = QPushButton("📋 Pengeluaran")
        reports_btn = QPushButton("📈 Laporan")
        settings_btn = QPushButton("⚙️ Pengaturan")
        logout_btn = QPushButton("🚪 Logout")
        
        menu_style = """
            QPushButton {
                color: white;
                border: 2px solid transparent;
                padding: 10px 16px;
                background: rgba(255,255,255,0.1);
                font-size: 12px;
                font-weight: bold;
                border-radius: 8px;
                min-height: 25px;
            }
            QPushButton:hover {
                background-color: #34495e;
                border: 2px solid #5a6c7d;
            }
            QPushButton:disabled {
                background-color: #1abc9c;
                color: white;
                border: 2px solid #16a085;
                font-weight: bold;
            }
        """
        
        for btn in [dashboard_btn, inventory_btn, sales_btn, expenses_btn, reports_btn, settings_btn, logout_btn]:
            btn.setStyleSheet(menu_style)
            btn.setCursor(Qt.PointingHandCursor)
        
        settings_btn.setEnabled(False)
        dashboard_btn.clicked.connect(self.dashboard_clicked.emit)
        inventory_btn.clicked.connect(self.inventory_clicked.emit)
        sales_btn.clicked.connect(self.sales_clicked.emit)
        expenses_btn.clicked.connect(self.expenses_clicked.emit)
        reports_btn.clicked.connect(self.reports_clicked.emit)
        logout_btn.clicked.connect(self.logout_clicked.emit)
        
        # Apply role-based restrictions
        self.apply_role_restrictions(inventory_btn, reports_btn, settings_btn)
        
        nav_layout.addWidget(dashboard_btn)
        nav_layout.addWidget(inventory_btn)
        nav_layout.addWidget(sales_btn)
        nav_layout.addWidget(expenses_btn)
        nav_layout.addWidget(reports_btn)
        nav_layout.addWidget(settings_btn)
        nav_layout.addStretch()
        nav_layout.addWidget(logout_btn)
        
        header_layout.addWidget(title)
        header_layout.addStretch()
        header_layout.addLayout(nav_layout)
        
        return header
    
    def set_user_role(self, role):
        """Set user role and update UI accordingly"""
        self.user_role = role
        self.update_ui_for_role()
    
    def apply_role_restrictions(self, inventory_btn, reports_btn, settings_btn):
        """Apply restrictions based on user role"""
        if self.user_role == "kasir":
            inventory_btn.setEnabled(False)
            inventory_btn.setToolTip("Akses terbatas untuk kasir")
            reports_btn.setEnabled(False)
            reports_btn.setToolTip("Akses terbatas untuk kasir")
            settings_btn.setEnabled(False)
            settings_btn.setToolTip("Akses terbatas untuk kasir")
    
    def update_ui_for_role(self):
        """Update UI elements based on user role"""
        pass
    
    def load_data(self):
        """Load settings data"""
        pass
    
    def save_settings(self):
        """Save settings to database"""
        QMessageBox.information(self, "Sukses", "Pengaturan berhasil disimpan!")
        self.dashboard_clicked.emit()