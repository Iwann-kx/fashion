# app/Views/ProfileView.py

from PyQt5.QtWidgets import (
    QWidget, QLabel, QVBoxLayout, QHBoxLayout, QPushButton,
    QFrame, QScrollArea, QDialog, QLineEdit, QComboBox,
    QTextEdit, QMessageBox, QFileDialog
)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QFont, QPixmap, QIcon


class ProfileView(QWidget):
    back_clicked = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.profile_image_path = "public/assets/profile.png"
        self.initUI()

    def initUI(self):
        mainLayout = QVBoxLayout()
        mainLayout.setSpacing(0)
        mainLayout.setContentsMargins(0, 0, 0, 0)

        # Header with back button
        headerFrame = QFrame()
        headerFrame.setFixedHeight(70)
        headerFrame.setStyleSheet("""
            QFrame {
                background-color: #2c3e50;
                color: white;
                border-bottom: 3px solid #3498db;
            }
        """)
        
        headerLayout = QHBoxLayout()
        headerLayout.setContentsMargins(30, 15, 30, 15)
        
        # Back button
        backBtn = QPushButton("← ⚙️ Kembali ke Pengaturan")
        backBtn.setFont(QFont("Arial", 12, QFont.Bold))
        backBtn.setStyleSheet("""
            QPushButton {
                color: white;
                border: 2px solid transparent;
                padding: 10px 16px;
                background: rgba(255,255,255,0.1);
                font-size: 12px;
                font-weight: bold;
                border-radius: 8px;
                min-height: 25px;
            }
            QPushButton:hover {
                background-color: #34495e;
                border: 2px solid #5a6c7d;
            }
        """)
        backBtn.setCursor(Qt.PointingHandCursor)
        backBtn.clicked.connect(self.back_clicked.emit)
        
        headerLayout.addWidget(backBtn)
        headerLayout.addStretch()
        
        headerFrame.setLayout(headerLayout)
        mainLayout.addWidget(headerFrame)

        # Content Area (no header needed here - main app handles nav)
        scrollArea = QScrollArea()
        scrollArea.setWidgetResizable(True)
        scrollArea.setStyleSheet("""
            QScrollArea {
                background-color: #fafafa;
                border: none;
            }
            QScrollBar:vertical {
                background-color: #fafafa;
                width: 8px;
            }
            QScrollBar::handle:vertical {
                background-color: #ddd;
                border-radius: 4px;
            }
        """)

        content = QFrame()
        content.setStyleSheet("QFrame { background-color: #fafafa; }")
        contentLayout = QVBoxLayout()
        contentLayout.setContentsMargins(24, 24, 24, 24)
        contentLayout.setSpacing(20)

        # Profile Card
        profileCard = self._create_profile_card()
        contentLayout.addWidget(profileCard)

        # Profile Information Card
        infoCard = self._create_info_card()
        contentLayout.addWidget(infoCard)

        # Account Settings Card
        settingsCard = self._create_settings_card()
        contentLayout.addWidget(settingsCard)

        contentLayout.addStretch()

        content.setLayout(contentLayout)
        scrollArea.setWidget(content)
        mainLayout.addWidget(scrollArea)

        self.setLayout(mainLayout)

    def _create_profile_card(self):
        """Create profile picture and basic info card"""
        container = QFrame()
        container.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 8px;
                border: 1px solid #f0f0f0;
            }
        """)
        layout = QHBoxLayout()
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(24)

        # Profile Picture
        pictureContainer = QFrame()
        pictureContainer.setStyleSheet("""
            QFrame {
                background-color: #f0f0f0;
                border-radius: 8px;
            }
        """)
        pictureLayout = QVBoxLayout()
        pictureLayout.setContentsMargins(0, 0, 0, 0)

        profilePic = QLabel()
        profilePic.setFixedSize(120, 120)
        
        # Try to load profile image, use placeholder if not exists
        pixmap = QPixmap(self.profile_image_path)
        if pixmap.isNull():
            # Create a placeholder
            pixmap = QPixmap(120, 120)
            pixmap.fill(Qt.lightGray)
        
        pixmap = pixmap.scaledToWidth(120, Qt.SmoothTransformation)
        profilePic.setPixmap(pixmap)
        profilePic.setAlignment(Qt.AlignCenter)
        
        pictureLayout.addWidget(profilePic, alignment=Qt.AlignCenter)
        pictureContainer.setLayout(pictureLayout)
        pictureContainer.setFixedSize(120, 120)

        layout.addWidget(pictureContainer)

        # Profile Info
        infoLayout = QVBoxLayout()
        infoLayout.setSpacing(12)

        # Name
        nameLabel = QLabel("Admin User")
        nameLabel.setFont(QFont("Segoe UI", 18, QFont.Bold))
        nameLabel.setStyleSheet("color: #222222;")
        infoLayout.addWidget(nameLabel)

        # Email
        emailLabel = QLabel("admin@fashionfinance.com")
        emailLabel.setFont(QFont("Segoe UI", 11))
        emailLabel.setStyleSheet("color: #666666;")
        infoLayout.addWidget(emailLabel)

        # Role
        roleLabel = QLabel("Administrator")
        roleLabel.setFont(QFont("Segoe UI", 11, QFont.Bold))
        roleLabel.setStyleSheet("color: #667eea;")
        infoLayout.addWidget(roleLabel)

        # Status
        statusLabel = QLabel("Status: Active")
        statusLabel.setFont(QFont("Segoe UI", 10))
        statusLabel.setStyleSheet("color: #22aa22; font-weight: bold;")
        infoLayout.addWidget(statusLabel)

        # Buttons
        buttonLayout = QHBoxLayout()
        buttonLayout.setSpacing(12)

        editBtn = QPushButton("Edit Profile")
        editBtn.setFont(QFont("Segoe UI", 10, QFont.Bold))
        editBtn.setMaximumWidth(120)
        editBtn.setStyleSheet("""
            QPushButton {
                background-color: #667eea;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #5568d3;
            }
        """)
        editBtn.clicked.connect(self._on_edit_profile)
        buttonLayout.addWidget(editBtn)

        changePhotoBtn = QPushButton("Change Photo")
        changePhotoBtn.setFont(QFont("Segoe UI", 10))
        changePhotoBtn.setMaximumWidth(120)
        changePhotoBtn.setStyleSheet("""
            QPushButton {
                background-color: #764ba2;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: #6a3f8a;
            }
        """)
        changePhotoBtn.clicked.connect(self._on_change_photo)
        buttonLayout.addWidget(changePhotoBtn)

        buttonLayout.addStretch()
        infoLayout.addLayout(buttonLayout)

        layout.addLayout(infoLayout)
        layout.addStretch()

        container.setLayout(layout)
        return container

    def _create_info_card(self):
        """Create detailed profile information card"""
        container = QFrame()
        container.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 8px;
                border: 1px solid #f0f0f0;
            }
        """)
        layout = QVBoxLayout()
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        # Title
        title = QLabel("Profile Information")
        title.setFont(QFont("Segoe UI", 13, QFont.Bold))
        title.setStyleSheet("color: #222222;")
        layout.addWidget(title)

        # Info grid
        infoGrid = QVBoxLayout()
        infoGrid.setSpacing(12)

        # Full Name
        fullNameLayout = QHBoxLayout()
        fullNameLabel = QLabel("Full Name:")
        fullNameLabel.setFont(QFont("Segoe UI", 10, QFont.Bold))
        fullNameLabel.setStyleSheet("color: #666; min-width: 120px;")
        fullNameValue = QLabel("Admin User")
        fullNameValue.setFont(QFont("Segoe UI", 10))
        fullNameValue.setStyleSheet("color: #222;")
        fullNameLayout.addWidget(fullNameLabel)
        fullNameLayout.addWidget(fullNameValue)
        fullNameLayout.addStretch()
        infoGrid.addLayout(fullNameLayout)

        # Email
        emailLayout = QHBoxLayout()
        emailLabel = QLabel("Email:")
        emailLabel.setFont(QFont("Segoe UI", 10, QFont.Bold))
        emailLabel.setStyleSheet("color: #666; min-width: 120px;")
        emailValue = QLabel("admin@fashionfinance.com")
        emailValue.setFont(QFont("Segoe UI", 10))
        emailValue.setStyleSheet("color: #222;")
        emailLayout.addWidget(emailLabel)
        emailLayout.addWidget(emailValue)
        emailLayout.addStretch()
        infoGrid.addLayout(emailLayout)

        # Phone
        phoneLayout = QHBoxLayout()
        phoneLabel = QLabel("Phone:")
        phoneLabel.setFont(QFont("Segoe UI", 10, QFont.Bold))
        phoneLabel.setStyleSheet("color: #666; min-width: 120px;")
        phoneValue = QLabel("+62 812 3456 7890")
        phoneValue.setFont(QFont("Segoe UI", 10))
        phoneValue.setStyleSheet("color: #222;")
        phoneLayout.addWidget(phoneLabel)
        phoneLayout.addWidget(phoneValue)
        phoneLayout.addStretch()
        infoGrid.addLayout(phoneLayout)

        # Department
        departmentLayout = QHBoxLayout()
        departmentLabel = QLabel("Department:")
        departmentLabel.setFont(QFont("Segoe UI", 10, QFont.Bold))
        departmentLabel.setStyleSheet("color: #666; min-width: 120px;")
        departmentValue = QLabel("Management")
        departmentValue.setFont(QFont("Segoe UI", 10))
        departmentValue.setStyleSheet("color: #222;")
        departmentLayout.addWidget(departmentLabel)
        departmentLayout.addWidget(departmentValue)
        departmentLayout.addStretch()
        infoGrid.addLayout(departmentLayout)

        # Join Date
        joinLayout = QHBoxLayout()
        joinLabel = QLabel("Join Date:")
        joinLabel.setFont(QFont("Segoe UI", 10, QFont.Bold))
        joinLabel.setStyleSheet("color: #666; min-width: 120px;")
        joinValue = QLabel("January 15, 2023")
        joinValue.setFont(QFont("Segoe UI", 10))
        joinValue.setStyleSheet("color: #222;")
        joinLayout.addWidget(joinLabel)
        joinLayout.addWidget(joinValue)
        joinLayout.addStretch()
        infoGrid.addLayout(joinLayout)

        layout.addLayout(infoGrid)
        container.setLayout(layout)
        return container

    def _create_settings_card(self):
        """Create account settings card"""
        container = QFrame()
        container.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 8px;
                border: 1px solid #f0f0f0;
            }
        """)
        layout = QVBoxLayout()
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(12)

        # Title
        title = QLabel("Account Settings")
        title.setFont(QFont("Segoe UI", 13, QFont.Bold))
        title.setStyleSheet("color: #222222; margin-bottom: 12px;")
        layout.addWidget(title)

        # Settings buttons
        buttonLayout = QVBoxLayout()
        buttonLayout.setSpacing(10)

        changePasswordBtn = QPushButton("Change Password")
        changePasswordBtn.setFont(QFont("Segoe UI", 10))
        changePasswordBtn.setStyleSheet("""
            QPushButton {
                background-color: #f093fb;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
                font-weight: bold;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #e07ee5;
            }
        """)
        changePasswordBtn.clicked.connect(self._on_change_password)
        buttonLayout.addWidget(changePasswordBtn)

        twoFactorBtn = QPushButton("Two-Factor Authentication")
        twoFactorBtn.setFont(QFont("Segoe UI", 10))
        twoFactorBtn.setStyleSheet("""
            QPushButton {
                background-color: #4facfe;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
                font-weight: bold;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3d9ceb;
            }
        """)
        twoFactorBtn.clicked.connect(self._on_two_factor)
        buttonLayout.addWidget(twoFactorBtn)

        loginHistoryBtn = QPushButton("Login History")
        loginHistoryBtn.setFont(QFont("Segoe UI", 10))
        loginHistoryBtn.setStyleSheet("""
            QPushButton {
                background-color: #667eea;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
                font-weight: bold;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #5568d3;
            }
        """)
        loginHistoryBtn.clicked.connect(self._on_login_history)
        buttonLayout.addWidget(loginHistoryBtn)

        deleteAccountBtn = QPushButton("Delete Account")
        deleteAccountBtn.setFont(QFont("Segoe UI", 10))
        deleteAccountBtn.setStyleSheet("""
            QPushButton {
                background-color: #dd2222;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
                font-weight: bold;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #bb1111;
            }
        """)
        deleteAccountBtn.clicked.connect(self._on_delete_account)
        buttonLayout.addWidget(deleteAccountBtn)

        layout.addLayout(buttonLayout)
        container.setLayout(layout)
        return container

    def _on_edit_profile(self):
        """Handle edit profile"""
        dialog = EditProfileDialog(self)
        dialog.exec_()

    def _on_change_photo(self):
        """Handle change photo"""
        fileName, _ = QFileDialog.getOpenFileName(
            self, "Select Profile Picture", "",
            "Image Files (*.png *.jpg *.jpeg *.bmp);;All Files (*)"
        )
        if fileName:
            self.profile_image_path = fileName
            QMessageBox.information(self, "Success", "Profile picture updated successfully!")

    def _on_change_password(self):
        """Handle change password"""
        dialog = ChangePasswordDialog(self)
        dialog.exec_()

    def _on_two_factor(self):
        """Handle two-factor authentication"""
        QMessageBox.information(self, "Two-Factor Authentication", 
            "Two-Factor Authentication is currently enabled.\n\nYour account is protected with SMS-based verification.")

    def _on_login_history(self):
        """Handle login history"""
        QMessageBox.information(self, "Login History",
            "Recent Login Activity:\n\n"
            "1. 2025-11-18 14:23 - Chrome (Windows)\n"
            "2. 2025-11-18 09:15 - Safari (macOS)\n"
            "3. 2025-11-17 16:45 - Chrome (Windows)\n"
            "4. 2025-11-17 10:30 - Firefox (Linux)")

    def _on_delete_account(self):
        """Handle delete account"""
        reply = QMessageBox.warning(self, "Delete Account",
            "Are you sure you want to delete your account?\n\n"
            "This action cannot be undone and all your data will be permanently deleted.",
            QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            QMessageBox.information(self, "Account Deleted", "Your account has been deleted successfully.")


class EditProfileDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Edit Profile")
        self.setGeometry(0, 0, 400, 350)
        self.setStyleSheet("QDialog { background-color: white; }")
        
        # Center dialog on parent window
        if self.parent():
            parent_rect = self.parent().frameGeometry()
            center_x = parent_rect.x() + parent_rect.width() // 2 - 200
            center_y = parent_rect.y() + parent_rect.height() // 2 - 175
            self.setGeometry(center_x, center_y, 400, 350)

        layout = QVBoxLayout()
        layout.setSpacing(12)
        layout.setContentsMargins(20, 20, 20, 20)

        # Title
        title = QLabel("Edit Profile")
        title.setFont(QFont("Segoe UI", 13, QFont.Bold))
        title.setStyleSheet("color: #222222;")
        layout.addWidget(title)

        # Full Name
        nameLabel = QLabel("Full Name")
        nameLabel.setFont(QFont("Segoe UI", 10))
        nameLabel.setStyleSheet("color: #666; font-weight: bold;")
        layout.addWidget(nameLabel)

        self.nameInput = QLineEdit()
        self.nameInput.setText("Admin User")
        self.nameInput.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 8px;
                font-size: 10px;
            }
            QLineEdit:focus {
                border: 1px solid #667eea;
            }
        """)
        layout.addWidget(self.nameInput)

        # Email
        emailLabel = QLabel("Email")
        emailLabel.setFont(QFont("Segoe UI", 10))
        emailLabel.setStyleSheet("color: #666; font-weight: bold;")
        layout.addWidget(emailLabel)

        self.emailInput = QLineEdit()
        self.emailInput.setText("admin@fashionfinance.com")
        self.emailInput.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 8px;
                font-size: 10px;
            }
            QLineEdit:focus {
                border: 1px solid #667eea;
            }
        """)
        layout.addWidget(self.emailInput)

        # Phone
        phoneLabel = QLabel("Phone")
        phoneLabel.setFont(QFont("Segoe UI", 10))
        phoneLabel.setStyleSheet("color: #666; font-weight: bold;")
        layout.addWidget(phoneLabel)

        self.phoneInput = QLineEdit()
        self.phoneInput.setText("+62 812 3456 7890")
        self.phoneInput.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 8px;
                font-size: 10px;
            }
            QLineEdit:focus {
                border: 1px solid #667eea;
            }
        """)
        layout.addWidget(self.phoneInput)

        # Department
        departmentLabel = QLabel("Department")
        departmentLabel.setFont(QFont("Segoe UI", 10))
        departmentLabel.setStyleSheet("color: #666; font-weight: bold;")
        layout.addWidget(departmentLabel)

        self.departmentCombo = QComboBox()
        self.departmentCombo.addItems(["Management", "Sales", "Operations", "Finance", "IT"])
        self.departmentCombo.setCurrentText("Management")
        self.departmentCombo.setStyleSheet("""
            QComboBox {
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 8px;
                font-size: 10px;
            }
            QComboBox:focus {
                border: 1px solid #667eea;
            }
        """)
        layout.addWidget(self.departmentCombo)

        # Buttons
        buttonLayout = QHBoxLayout()
        buttonLayout.setSpacing(12)

        saveBtn = QPushButton("Save Changes")
        saveBtn.setFont(QFont("Segoe UI", 10, QFont.Bold))
        saveBtn.setStyleSheet("""
            QPushButton {
                background-color: #667eea;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 10px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #5568d3;
            }
        """)
        saveBtn.clicked.connect(self._on_save)

        cancelBtn = QPushButton("Cancel")
        cancelBtn.setFont(QFont("Segoe UI", 10))
        cancelBtn.setStyleSheet("""
            QPushButton {
                background-color: #e0e0e0;
                color: #333;
                border: none;
                border-radius: 4px;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #d0d0d0;
            }
        """)
        cancelBtn.clicked.connect(self.close)

        buttonLayout.addWidget(saveBtn)
        buttonLayout.addWidget(cancelBtn)

        layout.addLayout(buttonLayout)

        self.setLayout(layout)

    def _on_save(self):
        """Handle save profile changes"""
        name = self.nameInput.text()
        email = self.emailInput.text()
        phone = self.phoneInput.text()
        department = self.departmentCombo.currentText()

        if not name or not email:
            QMessageBox.warning(self, "Validation", "Please fill in all fields")
            return

        message = f"Profile Updated:\n\nName: {name}\nEmail: {email}\nPhone: {phone}\nDepartment: {department}"
        QMessageBox.information(self, "Success", message)
        self.close()


class ChangePasswordDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Change Password")
        self.setGeometry(0, 0, 400, 280)
        self.setStyleSheet("QDialog { background-color: white; }")
        
        # Center dialog on parent window
        if self.parent():
            parent_rect = self.parent().frameGeometry()
            center_x = parent_rect.x() + parent_rect.width() // 2 - 200
            center_y = parent_rect.y() + parent_rect.height() // 2 - 140
            self.setGeometry(center_x, center_y, 400, 280)

        layout = QVBoxLayout()
        layout.setSpacing(12)
        layout.setContentsMargins(20, 20, 20, 20)

        # Title
        title = QLabel("Change Password")
        title.setFont(QFont("Segoe UI", 13, QFont.Bold))
        title.setStyleSheet("color: #222222;")
        layout.addWidget(title)

        # Current Password
        currentLabel = QLabel("Current Password")
        currentLabel.setFont(QFont("Segoe UI", 10))
        currentLabel.setStyleSheet("color: #666; font-weight: bold;")
        layout.addWidget(currentLabel)

        self.currentInput = QLineEdit()
        self.currentInput.setEchoMode(QLineEdit.Password)
        self.currentInput.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 8px;
                font-size: 10px;
            }
            QLineEdit:focus {
                border: 1px solid #667eea;
            }
        """)
        layout.addWidget(self.currentInput)

        # New Password
        newLabel = QLabel("New Password")
        newLabel.setFont(QFont("Segoe UI", 10))
        newLabel.setStyleSheet("color: #666; font-weight: bold;")
        layout.addWidget(newLabel)

        self.newInput = QLineEdit()
        self.newInput.setEchoMode(QLineEdit.Password)
        self.newInput.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 8px;
                font-size: 10px;
            }
            QLineEdit:focus {
                border: 1px solid #667eea;
            }
        """)
        layout.addWidget(self.newInput)

        # Confirm Password
        confirmLabel = QLabel("Confirm New Password")
        confirmLabel.setFont(QFont("Segoe UI", 10))
        confirmLabel.setStyleSheet("color: #666; font-weight: bold;")
        layout.addWidget(confirmLabel)

        self.confirmInput = QLineEdit()
        self.confirmInput.setEchoMode(QLineEdit.Password)
        self.confirmInput.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 8px;
                font-size: 10px;
            }
            QLineEdit:focus {
                border: 1px solid #667eea;
            }
        """)
        layout.addWidget(self.confirmInput)

        # Buttons
        buttonLayout = QHBoxLayout()
        buttonLayout.setSpacing(12)

        saveBtn = QPushButton("Update Password")
        saveBtn.setFont(QFont("Segoe UI", 10, QFont.Bold))
        saveBtn.setStyleSheet("""
            QPushButton {
                background-color: #667eea;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 10px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #5568d3;
            }
        """)
        saveBtn.clicked.connect(self._on_save)

        cancelBtn = QPushButton("Cancel")
        cancelBtn.setFont(QFont("Segoe UI", 10))
        cancelBtn.setStyleSheet("""
            QPushButton {
                background-color: #e0e0e0;
                color: #333;
                border: none;
                border-radius: 4px;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #d0d0d0;
            }
        """)
        cancelBtn.clicked.connect(self.close)

        buttonLayout.addWidget(saveBtn)
        buttonLayout.addWidget(cancelBtn)

        layout.addLayout(buttonLayout)

        self.setLayout(layout)

    def _on_save(self):
        """Handle save password change"""
        current = self.currentInput.text()
        new = self.newInput.text()
        confirm = self.confirmInput.text()

        if not current or not new or not confirm:
            QMessageBox.warning(self, "Validation", "Please fill in all fields")
            return

        if new != confirm:
            QMessageBox.warning(self, "Validation", "New passwords do not match")
            return

        if len(new) < 8:
            QMessageBox.warning(self, "Validation", "Password must be at least 8 characters long")
            return

        QMessageBox.information(self, "Success", "Password updated successfully!")
        self.close()