"""Expenses View - Refactored with modular components"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QScrollArea, QMessageBox, QFrame)
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QFont
from app.components import (StatCard, NavigationHeader, DataTable, 
                            PrimaryButton, SearchInput, StyledComboBox, FormDialog)
from app.controllers.expense_controller import ExpenseController
from app.utils.helpers import format_currency
from datetime import datetime


class AddExpenseDialog(FormDialog):
    """Dialog for adding/editing expenses using FormDialog component"""
    
    def __init__(self, parent=None, expense_data=None):
        is_edit = expense_data is not None
        title = "✏️ Edit Pengeluaran" if is_edit else "➕ Tambah Pengeluaran"
        
        # Configure form fields
        fields_config = [
            {
                'name': 'date',
                'label': '📅 Tanggal',
                'type': 'date',
                'required': True
            },
            {
                'name': 'description',
                'label': '📝 Deskripsi',
                'type': 'text',
                'placeholder': 'Deskripsi pengeluaran',
                'required': True
            },
            {
                'name': 'category',
                'label': '📂 Kategori',
                'type': 'combo',
                'items': ["Bahan Baku", "Operasional", "Marketing", "Lainnya"],
                'required': True
            },
            {
                'name': 'amount',
                'label': '💰 Jumlah',
                'type': 'text',
                'placeholder': 'Contoh: 500000 (tanpa titik/koma)',
                'required': True
            },
            {
                'name': 'status',
                'label': '📊 Status',
                'type': 'combo',
                'items': ["Lunas", "Pending"],
                'required': True
            }
        ]
        
        # Prepare data for pre-filling
        data = {}
        if expense_data:
            try:
                if len(expense_data) >= 6:
                    data['date'] = expense_data[1]
                    data['description'] = str(expense_data[2])
                    
                    category_value = expense_data[3]
                    if isinstance(category_value, int):
                        categories = ["Bahan Baku", "Operasional", "Marketing", "Lainnya"]
                        data['category'] = categories[category_value] if 0 <= category_value < len(categories) else categories[0]
                    else:
                        data['category'] = str(category_value)
                    
                    data['amount'] = str(expense_data[4])
                    
                    status_value = expense_data[5]
                    if isinstance(status_value, int):
                        statuses = ["Lunas", "Pending"]
                        data['status'] = statuses[status_value] if 0 <= status_value < len(statuses) else statuses[0]
                    else:
                        data['status'] = str(status_value)
            except (ValueError, IndexError) as e:
                print(f"Error loading expense data: {e}")
        
        super().__init__(title, fields_config, data, parent)
    
    def validate_and_accept(self):
        """Custom validation for expense form"""
        # First, run parent validation
        super().validate_and_accept()
        
        # Additional validation for amount
        try:
            amount = int(self.fields['amount'].text())
            if amount <= 0:
                self.show_error("Jumlah harus lebih dari 0!")
                return
        except ValueError:
            self.show_error("Jumlah harus angka!")
            return
        
        self.accept()


class ExpensesWindow(QWidget):
    """Expenses window with CRUD operations"""
    
    # Signals
    back_clicked = pyqtSignal()
    inventory_clicked = pyqtSignal()
    sales_clicked = pyqtSignal()
    reports_clicked = pyqtSignal()
    settings_clicked = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.init_ui()
    
    def init_ui(self):
        """Initialize the UI"""
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Header
        header = NavigationHeader("expenses", "admin")
        header.dashboard_clicked.connect(self.back_clicked.emit)
        header.inventory_clicked.connect(self.inventory_clicked.emit)
        header.sales_clicked.connect(self.sales_clicked.emit)
        header.reports_clicked.connect(self.reports_clicked.emit)
        header.settings_clicked.connect(self.settings_clicked.emit)
        header.logout_clicked.connect(self.back_to_login)
        
        # Scroll area
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setStyleSheet("""
            QScrollArea { 
                border: none; 
                background-color: #f8f9fa;
            }
            QScrollBar:vertical {
                background-color: #e0e0e0;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background-color: #bdc3c7;
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #95a5a6;
            }
        """)
        
        # Content widget
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(20)
        
        # Page title
        self._add_page_title(content_layout)
        
        # Search and filter section
        filter_layout = QHBoxLayout()
        filter_layout.setSpacing(15)
        
        search_input = SearchInput("🔍 Cari pengeluaran...")
        category_filter = StyledComboBox(["Semua Kategori", "Bahan Baku", "Operasional", "Marketing", "Lainnya"])
        category_filter.setFixedWidth(180)
        
        filter_layout.addWidget(search_input)
        filter_layout.addWidget(category_filter)
        filter_layout.addStretch()
        
        content_layout.addLayout(filter_layout)
        
        # Stats section
        self.stats_layout = QHBoxLayout()
        self.stats_layout.setSpacing(20)
        content_layout.addLayout(self.stats_layout)
        
        # Table section
        table_section = self._create_table_section()
        content_layout.addWidget(table_section)
        content_layout.addStretch()
        
        scroll_area.setWidget(content_widget)
        
        # Add to main layout
        main_layout.addWidget(header)
        main_layout.addWidget(scroll_area, 1)
        
        self.setStyleSheet("background-color: #f8f9fa;")
        self.load_data()
    
    def _add_page_title(self, layout):
        """Add page title and subtitle"""
        page_title = QLabel("Pengeluaran")
        page_title.setFont(QFont("Arial", 24, QFont.Bold))
        page_title.setStyleSheet("color: #2c3e50; margin-bottom: 5px;")
        
        subtitle = QLabel("Kelola dan catat semua pengeluaran bisnis")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7f8c8d;")
        
        layout.addWidget(page_title)
        layout.addWidget(subtitle)
    
    def _create_table_section(self):
        """Create the table section with header and table"""
        table_frame = QFrame()
        table_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
                border: 1px solid #e0e0e0;
            }
        """)
        
        table_layout = QVBoxLayout(table_frame)
        table_layout.setSpacing(15)
        
        # Table header
        header_layout = QHBoxLayout()
        table_title = QLabel("Pengeluaran Terbaru")
        table_title.setFont(QFont("Arial", 18, QFont.Bold))
        table_title.setStyleSheet("color: #2c3e50;")
        
        add_btn = PrimaryButton("Tambah Pengeluaran", "➕")
        add_btn.clicked.connect(self.add_expense)
        
        header_layout.addWidget(table_title)
        header_layout.addStretch()
        header_layout.addWidget(add_btn)
        
        # Create table
        self.table = DataTable(["TANGGAL", "DESKRIPSI", "KATEGORI", "JUMLAH", "STATUS", "AKSI"])
        
        table_layout.addLayout(header_layout)
        table_layout.addWidget(self.table)
        
        return table_frame
    
    def load_data(self):
        """Load expenses data"""
        # Clear existing stats
        self._clear_layout(self.stats_layout)
        
        # Create stat cards
        stats_data = [
            ("Total Pengeluaran", "Rp 8.250.000", "+5% dari bulan lalu", "#e74c3c", "📉"),
            ("Pengeluaran Bulan Ini", "Rp 1.250.000", "-2% dari target", "#3498db", "📊"),
            ("Rata-rata per Hari", "Rp 41.667", "+8% dari bulan lalu", "#f39c12", "📅"),
            ("Kategori Terbesar", "Bahan Baku", "42% dari total", "#9b59b6", "🏷️")
        ]
        
        for title, value, change, color, icon in stats_data:
            stat_card = StatCard(title, value, change, color, icon)
            self.stats_layout.addWidget(stat_card)
        
        self.stats_layout.addStretch()
        
        # Load expenses table
        expenses = ExpenseController.get_all_expenses(limit=50)
        self.table.clear_data()
        
        for expense in expenses:
            # Format date
            tanggal = expense.get('tanggal', '')
            if isinstance(tanggal, str):
                date_obj = datetime.strptime(tanggal, '%Y-%m-%d')
            else:
                date_obj = tanggal
            date_text = date_obj.strftime('%d %b %Y') if hasattr(date_obj, 'strftime') else str(tanggal)
            
            # Category with icon
            kategori = expense.get('kategori', '')
            category_icons = {
                "Bahan Baku": "🧵",
                "Operasional": "⚡",
                "Marketing": "📢"
            }
            category_icon = category_icons.get(kategori, "📦")
            category_text = f"{category_icon} {kategori}"
            
            # Format amount
            amount = float(expense.get('jumlah', 0))
            amount_text = format_currency(amount)
            
            # Status
            status = expense.get('status', 'Lunas')
            
            # Add row with action callbacks
            self.table.add_row(
                [date_text, expense.get('deskripsi', ''), category_text, amount_text, status],
                {
                    'edit': lambda checked, e=expense: self.edit_expense(e),
                    'delete': lambda checked, e=expense: self.delete_expense(e)
                }
            )
            
            # Style status cell
            row = self.table.rowCount() - 1
            if status == "Lunas":
                self.table.style_cell(row, 4, Qt.darkGreen, True)
            else:
                self.table.style_cell(row, 4, Qt.darkRed, True)
    
    def add_expense(self):
        """Add new expense"""
        dialog = AddExpenseDialog(self)
        if dialog.exec_():
            data = dialog.get_data()
            success, result = ExpenseController.create_expense(
                tanggal=data['date'],
                deskripsi=data['description'],
                kategori=data['category'],
                jumlah=int(data['amount']),
                status=data['status']
            )
            if success:
                QMessageBox.information(self, "Sukses", "✅ Pengeluaran berhasil ditambahkan!")
                self.load_data()
            else:
                QMessageBox.warning(self, "Error", f"❌ Gagal menambah pengeluaran: {result}")
    
    def edit_expense(self, expense):
        """Edit existing expense"""
        expense_tuple = (
            expense.get('id'),
            expense.get('tanggal'),
            expense.get('deskripsi', ''),
            expense.get('kategori', ''),
            float(expense.get('jumlah', 0)),
            expense.get('status', 'Lunas')
        )
        dialog = AddExpenseDialog(self, expense_tuple)
        if dialog.exec_():
            data = dialog.get_data()
            success, result = ExpenseController.update_expense(
                expense.get('id'),
                tanggal=data['date'],
                deskripsi=data['description'],
                kategori=data['category'],
                jumlah=int(data['amount']),
                status=data['status']
            )
            if success:
                QMessageBox.information(self, "Sukses", "✅ Pengeluaran berhasil diupdate!")
                self.load_data()
            else:
                QMessageBox.warning(self, "Error", f"❌ Gagal update pengeluaran: {result}")
    
    def delete_expense(self, expense):
        """Delete expense"""
        deskripsi = expense.get('deskripsi', '').split('\n')[0] if expense.get('deskripsi') else 'pengeluaran ini'
        reply = QMessageBox.question(self, "Konfirmasi", 
                                   f"Apakah Anda yakin ingin menghapus pengeluaran '{deskripsi}'?",
                                   QMessageBox.Yes | QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            success, result = ExpenseController.delete_expense(expense.get('id'))
            if success:
                QMessageBox.information(self, "Sukses", "✅ Pengeluaran berhasil dihapus!")
                self.load_data()
            else:
                QMessageBox.warning(self, "Error", f"❌ Gagal menghapus pengeluaran: {result}")
    
    def back_to_login(self):
        """Handle logout"""
        reply = QMessageBox.question(self, "Konfirmasi", 
                                   "Apakah Anda yakin ingin logout?",
                                   QMessageBox.Yes | QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            self.back_clicked.emit()
    
    def _clear_layout(self, layout):
        """Clear all widgets from a layout"""
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()