from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QFrame, QTableWidget, QTableWidgetItem,
                             QHeaderView, QDialog, QLineEdit, QComboBox, 
                             QSpinBox, QDialogButtonBox, QMessageBox, QScrollArea,
                             QGridLayout, QLineEdit, QFileDialog)
from PyQt5.QtCore import pyqtSignal, Qt, QTimer
from PyQt5.QtGui import QFont, QColor, QPixmap
from app.controllers.product_controller import ProductController
from app.utils.helpers import format_currency
import os
import requests
from PIL import Image
import io

class AddProductDialog(QDialog):
    def __init__(self, parent=None, product_data=None):
        super().__init__(parent)
        self.product_data = product_data
        self.is_edit = product_data is not None
        self.selected_image_path = None
        self.init_ui()
        
    def init_ui(self):
        self.setWindowTitle("✏️ Edit Produk" if self.is_edit else "➕ Tambah Produk")
        self.setFixedSize(600, 700)
        
        layout = QVBoxLayout()
        layout.setSpacing(0)
        
        # Title
        title = QLabel("Edit Produk" if self.is_edit else "Tambah Produk Baru")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        title.setStyleSheet("color: #2c3e50; margin-bottom: 20px;")
        layout.addWidget(title)
        
        # Image section
        image_section = self.create_image_section()
        layout.addLayout(image_section)
        
        # Form fields
        fields = [
            ("📝 Nama Produk", QLineEdit()),
            ("📂 Kategori", QComboBox()),
            ("📊 Stok", QSpinBox()),
            ("💰 Harga", QLineEdit()),
            ("🏷️ SKU", QLineEdit())
        ]
        
        self.name_input, self.category_combo, self.stock_spin, self.price_input, self.sku_input = [field[1] for field in fields]
        
        # Setup category combo
        self.category_combo.addItems(["Dress", "Kemeja", "Celana", "Aksesoris", "Sepatu", "Jaket"])
        self.category_combo.currentTextChanged.connect(self.suggest_image)
        
        # Setup spin box
        self.stock_spin.setRange(0, 1000)
        self.stock_spin.setSuffix(" pcs")
        
        # Setup price input
        self.price_input.setPlaceholderText("Contoh: 120000 (tanpa titik/koma)")
        
        # Add fields to layout
        for label_text, widget in fields:
            field_layout = QVBoxLayout()
            label = QLabel(label_text)
            label.setFont(QFont("Arial", 11, QFont.Bold))
            label.setStyleSheet("color: #2c3e50; margin-bottom: 5px;")
            
            widget.setStyleSheet("""
                QLineEdit, QComboBox, QSpinBox {
                    padding: 12px;
                    border: 2px solid #e0e0e0;
                    border-radius: 8px;
                    font-size: 14px;
                    background-color: white;
                }
                QLineEdit:focus, QComboBox:focus, QSpinBox:focus {
                    border-color: #3498db;
                }
            """)
            
            field_layout.addWidget(label)
            field_layout.addWidget(widget)
            layout.addLayout(field_layout)
        
        # Pre-fill data if editing
        if self.is_edit:
            self.name_input.setText(self.product_data[1])
            self.category_combo.setCurrentText(self.product_data[2])
            self.stock_spin.setValue(self.product_data[3])
            self.price_input.setText(str(self.product_data[4]))
            self.sku_input.setText(self.product_data[5])
            
            # Load existing image if any
            if len(self.product_data) > 8 and self.product_data[8]:
                self.load_image(self.product_data[8])
        else:
            # Untuk produk baru, tampilkan gambar sample berdasarkan kategori
            QTimer.singleShot(100, self.suggest_image)
        
        # Buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.setStyleSheet("""
            QPushButton {
                padding: 10px 20px;
                border: none;
                border-radius: 6px;
                font-weight: bold;
                min-width: 80px;
            }
            QPushButton[text="OK"] {
                background-color: #27ae60;
                color: white;
            }
            QPushButton[text="Cancel"] {
                background-color: #95a5a6;
                color: white;
            }
        """)
        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)
        
        layout.addWidget(button_box)
        self.setLayout(layout)
    
    def create_image_section(self):
        """Membuat section untuk upload gambar"""
        image_layout = QVBoxLayout()
        image_layout.setSpacing(10)
        
        # Title
        image_title = QLabel("🖼️ Gambar Produk")
        image_title.setFont(QFont("Arial", 11, QFont.Bold))
        image_title.setStyleSheet("color: #2c3e50; margin-bottom: 5px;")
        
        # Image display frame
        image_frame = QFrame()
        image_frame.setStyleSheet("""
            QFrame {
                background-color: #f8f9fa;
                border: 2px dashed #bdc3c7;
                border-radius: 8px;
                padding: 10px;
            }
        """)
        image_frame.setFixedSize(150, 150)
        
        frame_layout = QVBoxLayout(image_frame)
        frame_layout.setAlignment(Qt.AlignCenter)
        
        self.image_label = QLabel()
        self.image_label.setFixedSize(120, 120)
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setStyleSheet("background-color: transparent;")
        self.image_label.setText("📷\nLoading...")
        self.image_label.mousePressEvent = self.select_image
        
        frame_layout.addWidget(self.image_label)
        
        # Button
        image_btn_layout = QHBoxLayout()
        select_btn = QPushButton("Pilih Gambar")
        select_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                padding: 8px 12px;
                border: none;
                border-radius: 6px;
                font-size: 11px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        select_btn.clicked.connect(self.select_image)
        
        clear_btn = QPushButton("Hapus")
        clear_btn.setStyleSheet("""
            QPushButton {
                background-color: #e74c3c;
                color: white;
                padding: 8px 12px;
                border: none;
                border-radius: 6px;
                font-size: 11px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #c0392b;
            }
        """)
        clear_btn.clicked.connect(self.clear_image)
        
        auto_btn = QPushButton("Auto")
        auto_btn.setStyleSheet("""
            QPushButton {
                background-color: #f39c12;
                color: white;
                padding: 8px 12px;
                border: none;
                border-radius: 6px;
                font-size: 11px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #e67e22;
            }
        """)
        auto_btn.clicked.connect(self.generate_auto_image)
        
        image_btn_layout.addWidget(select_btn)
        image_btn_layout.addWidget(auto_btn)
        image_btn_layout.addWidget(clear_btn)
        
        image_layout.addWidget(image_title)
        image_layout.addWidget(image_frame, 0, Qt.AlignCenter)
        image_layout.addLayout(image_btn_layout)
        
        return image_layout
    
    def suggest_image(self):
        """Suggest gambar berdasarkan kategori"""
        if not self.is_edit and self.category_combo.currentText():
            category = self.category_combo.currentText()
            self.image_label.setText(f"📷\nKategori: {category}\nKlik 'Auto' untuk generate")
    
    def generate_auto_image(self):
        """Generate gambar otomatis berdasarkan kategori"""
        try:
            category = self.category_combo.currentText()
            product_name = self.name_input.text() or "Sample Product"
            
            if not category:
                QMessageBox.warning(self, "Peringatan", "Pilih kategori terlebih dahulu!")
                return
            
            # URL gambar sample berdasarkan kategori
            image_urls = {
                "Dress": [
                    "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop",
                    "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=400&h=400&fit=crop",
                    "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400&h=400&fit=crop"
                ],
                "Kemeja": [
                    "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=400&h=400&fit=crop",
                    "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&h=400&fit=crop",
                    "https://images.unsplash.com/photo-1501084817091-a4f3d1d19e07?w=400&h=400&fit=crop"
                ],
                "Celana": [
                    "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400&h=400&fit=crop",
                    "https://images.unsplash.com/photo-1582418702059-97ebafb35d09?w=400&h=400&fit=crop",
                    "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=400&h=400&fit=crop"
                ],
                "Aksesoris": [
                    "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400&h=400&fit=crop",
                    "https://images.unsplash.com/photo-1594223274512-ad4803739b7c?w=400&h=400&fit=crop",
                    "https://images.unsplash.com/photo-1582142306909-195724d1a6ec?w=400&h=400&fit=crop"
                ],
                "Sepatu": [
                    "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop",
                    "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=400&h=400&fit=crop",
                    "https://images.unsplash.com/photo-1560769624-7dc6f1a71d14?w=400&h=400&fit=crop"
                ],
                "Jaket": [
                    "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop",
                    "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400&h=400&fit=crop",
                    "https://images.unsplash.com/photo-1611312449408-fcece27cdbb7?w=400&h=400&fit=crop"
                ]
            }
            
            urls = image_urls.get(category, image_urls["Dress"])
            import random
            image_url = random.choice(urls)
            
            self.image_label.setText("🔄 Loading...")
            
            # Download gambar di thread terpisah (simplified)
            self.download_and_display_image(image_url, product_name)
            
        except Exception as e:
            self.image_label.setText("❌ Error\nGenerate")
            print(f"Error generating auto image: {e}")
    
    def download_and_display_image(self, image_url, product_name):
        """Download dan tampilkan gambar dari URL"""
        try:
            import tempfile
            
            response = requests.get(image_url, timeout=10)
            if response.status_code == 200:
                # Simpan ke temporary file
                with tempfile.NamedTemporaryFile(delete=False, suffix='.jpg') as tmp_file:
                    tmp_file.write(response.content)
                    self.selected_image_path = tmp_file.name
                
                # Tampilkan gambar
                self.load_image(self.selected_image_path)
                QMessageBox.information(self, "Sukses", f"✅ Gambar berhasil di-generate untuk {product_name}!")
            else:
                self.image_label.setText("❌ Gagal\nDownload")
                
        except Exception as e:
            self.image_label.setText("❌ Error\nNetwork")
            print(f"Error downloading image: {e}")
    
    def select_image(self, event=None):
        """Memilih gambar dari file dialog"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, 
            "Pilih Gambar Produk", 
            "", 
            "Image Files (*.png *.jpg *.jpeg *.bmp *.gif)"
        )
        
        if file_path:
            self.selected_image_path = file_path
            self.load_image(file_path)
    
    def load_image(self, image_path):
        """Load dan tampilkan gambar"""
        if os.path.exists(image_path):
            pixmap = QPixmap(image_path)
            # Scale image to fit display
            scaled_pixmap = pixmap.scaled(120, 120, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.image_label.setPixmap(scaled_pixmap)
            self.image_label.setText("")
        else:
            self.image_label.setText("❌\nGambar\ntidak ditemukan")
    
    def clear_image(self):
        """Hapus gambar yang dipilih"""
        self.selected_image_path = None
        self.image_label.clear()
        self.image_label.setText("📷\nKlik untuk\nmemilih gambar")
    
    def validate_and_accept(self):
        if not all([self.name_input.text(), self.sku_input.text(), self.price_input.text()]):
            QMessageBox.warning(self, "Error", "Harap isi semua field!")
            return
        
        try:
            price_text = self.price_input.text().replace('.', '').replace(',', '')
            price = int(price_text)
            if price <= 0:
                QMessageBox.warning(self, "Error", "Harga harus lebih dari 0!")
                return
        except ValueError:
            QMessageBox.warning(self, "Error", "Format harga tidak valid! Gunakan angka saja.")
            return
            
        self.accept()
    
    def get_data(self):
        price_text = self.price_input.text().replace('.', '').replace(',', '')
        
        return {
            'name': self.name_input.text(),
            'category': self.category_combo.currentText(),
            'stock': self.stock_spin.value(),
            'price': int(price_text),
            'sku': self.sku_input.text(),
            'image_path': self.selected_image_path
        }

class InventoryWindow(QWidget):
    back_clicked = pyqtSignal()
    sales_clicked = pyqtSignal()
    expenses_clicked = pyqtSignal()
    reports_clicked = pyqtSignal()
    settings_clicked = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.init_ui()
        
    def init_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Header - SEPERTI EXPENSES
        header = self.create_header()
        
        # Content dengan scroll area - SEPERTI EXPENSES
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setStyleSheet("""
            QScrollArea { 
                border: none; 
                background-color: #f8f9fa;
            }
            QScrollBar:vertical {
                background-color: #e0e0e0;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background-color: #bdc3c7;
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #95a5a6;
            }
        """)
        
        # Content widget utama - SEPERTI EXPENSES
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(20)
        
        # Page title - SEPERTI EXPENSES
        page_title = QLabel("Inventori")
        page_title.setFont(QFont("Arial", 24, QFont.Bold))
        page_title.setStyleSheet("color: #2c3e50; margin-bottom: 5px;")
        
        subtitle = QLabel("Kelola stok dan produk Anda")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7f8c8d;")
        
        content_layout.addWidget(page_title)
        content_layout.addWidget(subtitle)
        
        # Search and filter section - SEPERTI EXPENSES
        filter_section = QHBoxLayout()
        filter_section.setSpacing(15)
        
        # Search input
        search_input = QLineEdit()
        search_input.setPlaceholderText("🔍 Cari produk...")
        search_input.setFixedWidth(250)
        search_input.setStyleSheet("""
            QLineEdit {
                padding: 12px 15px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 14px;
                background-color: white;
            }
            QLineEdit:focus {
                border-color: #3498db;
            }
        """)
        
        # Category filter
        category_filter = QComboBox()
        category_filter.addItems(["Semua Kategori", "Dress", "Kemeja", "Celana", "Aksesoris", "Sepatu", "Jaket"])
        category_filter.setFixedWidth(180)
        category_filter.setStyleSheet("""
            QComboBox {
                padding: 12px 15px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 14px;
                background-color: white;
            }
        """)
        
        filter_section.addWidget(search_input)
        filter_section.addWidget(category_filter)
        filter_section.addStretch()
        
        content_layout.addLayout(filter_section)
        
        # Stats section - SEPERTI EXPENSES (satu baris horizontal)
        stats_layout = QHBoxLayout()
        stats_layout.setSpacing(20)

        stats_data = [
            ("Total Produk", "24", "+3 dari bulan lalu", "#3498db", "📦"),
            ("Stok Rendah", "3", "Perlu restock", "#e74c3c", "⚠️"),
            ("Nilai Inventori", "Rp 8.450.000", "+12% dari bulan lalu", "#27ae60", "💰"),
            ("Kategori Terbanyak", "Dress", "8 produk", "#9b59b6", "🏷️")
        ]

        for title, value, change, color, icon in stats_data:
            stat_card = self.create_stat_card_large(title, value, change, color, icon)
            stats_layout.addWidget(stat_card)

        stats_layout.addStretch()
        content_layout.addLayout(stats_layout)
        
        # Products table section - SEPERTI EXPENSES
        table_section = QFrame()
        table_section.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
                border: 1px solid #e0e0e0;
            }
        """)
        
        table_layout = QVBoxLayout(table_section)
        table_layout.setSpacing(15)
        
        # Table header
        table_header = QHBoxLayout()
        table_title = QLabel("Daftar Produk")
        table_title.setFont(QFont("Arial", 18, QFont.Bold))
        table_title.setStyleSheet("color: #2c3e50;")
        
        table_header.addWidget(table_title)
        table_header.addStretch()
        
        # Add product button
        add_btn = QPushButton("➕ Tambah Produk")
        add_btn.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                color: white;
                padding: 12px 20px;
                border: none;
                border-radius: 8px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2ecc71;
            }
        """)
        add_btn.clicked.connect(self.add_product)
        
        table_header.addWidget(add_btn)
        
        # Table - SEPERTI EXPENSES
        self.table = QTableWidget()
        self.table.setColumnCount(7)  # Ditambah 1 kolom untuk gambar
        self.table.setHorizontalHeaderLabels(["PRODUK", "KATEGORI", "STOK", "HARGA", "GAMBAR", "STATUS", "AKSI"])
        
        # Style table seperti expenses
        self.table.setStyleSheet("""
            QTableWidget {
                background-color: white;
                border: none;
                gridline-color: #e9ecef;
                font-size: 14px;
                border-radius: 8px;
                alternate-background-color: #f8f9fa;
            }
            QTableWidget::item {
                padding: 16px 12px;
                border-bottom: 1px solid #e9ecef;
                font-size: 13px;
            }
            QTableWidget::item:selected {
                background-color: #3498db;
                color: white;
            }
            QHeaderView::section {
                background-color: #2c3e50;
                color: white;
                padding: 16px 12px;
                border: none;
                border-bottom: 2px solid #e9ecef;
                font-weight: bold;
                font-size: 13px;
            }
        """)
        
        self.table.verticalHeader().setDefaultSectionSize(65)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setMinimumHeight(400)
        
        table_layout.addLayout(table_header)
        table_layout.addWidget(self.table)
        
        content_layout.addWidget(table_section)
        content_layout.addStretch()
        
        scroll_area.setWidget(content_widget)
        
        # Add to main layout
        main_layout.addWidget(header)
        main_layout.addWidget(scroll_area, 1)
        
        self.setLayout(main_layout)
        self.setStyleSheet("background-color: #f8f9fa;")
        self.load_data()

    def create_stat_card_large(self, title, value, change, color, icon):
        """Membuat stat card besar dengan icon seperti expenses"""
        stat_frame = QFrame()
        stat_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 25px;
                border: 1px solid #e0e0e0;
            }
        """)
        stat_frame.setMinimumHeight(350)
        stat_frame.setMinimumWidth(400)
        
        stat_layout = QVBoxLayout(stat_frame)
        stat_layout.setSpacing(8)
        
        # Header dengan icon
        header_layout = QHBoxLayout()
        icon_label = QLabel(icon)
        icon_label.setFont(QFont("Arial", 16))
        icon_label.setStyleSheet("color: %s;" % color)
        
        stat_title = QLabel(title)
        stat_title.setFont(QFont("Arial", 12))
        stat_title.setStyleSheet("color: #7f8c8d;")
        
        header_layout.addWidget(icon_label)
        header_layout.addWidget(stat_title)
        header_layout.addStretch()
        
        # Value
        value_label = QLabel(value)
        value_label.setFont(QFont("Arial", 18, QFont.Bold))
        value_label.setStyleSheet("color: %s; margin-top: 5px;" % color)
        
        # Change
        change_label = QLabel(change)
        change_label.setFont(QFont("Arial", 11))
        change_label.setStyleSheet("color: #7f8c8d; font-weight: bold;")
        
        stat_layout.addLayout(header_layout)
        stat_layout.addWidget(value_label)
        stat_layout.addWidget(change_label)
        stat_layout.addStretch()
        
        return stat_frame
    
    def create_header(self):
        header = QFrame()
        header.setFixedHeight(70)
        header.setStyleSheet("""
            QFrame {
                background-color: #2c3e50;
                color: white;
                border-bottom: 3px solid #3498db;
            }
        """)
        
        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(30, 15, 30, 15)
        
        title = QLabel("🏪 Fashion Finance - Sistem Manajemen Inventori")
        title.setFont(QFont("Arial", 18, QFont.Bold))
        title.setStyleSheet("color: white;")
        
        nav_layout = QHBoxLayout()
        nav_layout.setSpacing(8)
        
        # Navigation buttons
        dashboard_btn = QPushButton("📊 Dashboard")
        inventory_btn = QPushButton("📦 Inventori")
        sales_btn = QPushButton("💳 Penjualan")
        expenses_btn = QPushButton("📋 Pengeluaran")
        reports_btn = QPushButton("📈 Laporan")
        settings_btn = QPushButton("⚙️ Pengaturan")
        logout_btn = QPushButton("🚪 Logout")
        
        menu_style = """
            QPushButton {
                color: white;
                border: 2px solid transparent;
                padding: 10px 16px;
                background: rgba(255,255,255,0.1);
                font-size: 12px;
                font-weight: bold;
                border-radius: 8px;
                min-height: 25px;
            }
            QPushButton:hover {
                background-color: #34495e;
                border: 2px solid #5a6c7d;
            }
            QPushButton:disabled {
                background-color: #1abc9c;
                color: white;
                border: 2px solid #16a085;
                font-weight: bold;
            }
        """
        
        for btn in [dashboard_btn, inventory_btn, sales_btn, expenses_btn, reports_btn, settings_btn, logout_btn]:
            btn.setStyleSheet(menu_style)
            btn.setCursor(Qt.PointingHandCursor)
        
        inventory_btn.setEnabled(False)
        dashboard_btn.clicked.connect(self.back_clicked.emit)
        sales_btn.clicked.connect(self.sales_clicked.emit)
        expenses_btn.clicked.connect(self.expenses_clicked.emit)
        reports_btn.clicked.connect(self.reports_clicked.emit)
        settings_btn.clicked.connect(self.settings_clicked.emit)
        logout_btn.clicked.connect(self.back_to_login)
        
        nav_layout.addWidget(dashboard_btn)
        nav_layout.addWidget(inventory_btn)
        nav_layout.addWidget(sales_btn)
        nav_layout.addWidget(expenses_btn)
        nav_layout.addWidget(reports_btn)
        nav_layout.addWidget(settings_btn)
        nav_layout.addStretch()
        nav_layout.addWidget(logout_btn)
        
        header_layout.addWidget(title)
        header_layout.addStretch()
        header_layout.addLayout(nav_layout)
        header.setLayout(header_layout)
        
        return header
    
    def load_data(self):
        # Get products from controller
        products = ProductController.get_all_products(active_only=False)
        
        self.table.setRowCount(len(products))
        
        for row, product in enumerate(products):
            # Product name
            name_item = QTableWidgetItem(product['nama_produk'])
            name_item.setFont(QFont("Arial", 12))
            
            # Category dengan icon
            kategori = product.get('kategori', '')
            category_icon = ""
            if kategori == "Dress": category_icon = "👗"
            elif kategori == "Kemeja": category_icon = "👔"
            elif kategori == "Celana": category_icon = "👖"
            elif kategori == "Sepatu": category_icon = "👟"
            elif kategori == "Jaket": category_icon = "🧥"
            else: category_icon = "💎"
            
            category_item = QTableWidgetItem(f"{category_icon} {kategori}")
            category_item.setFont(QFont("Arial", 12))
            
            # Stock
            stok = product.get('stok', 0)
            stock_item = QTableWidgetItem(f"{stok} pcs")
            stock_item.setFont(QFont("Arial", 12, QFont.Bold))
            if stok < 10:
                stock_item.setForeground(QColor("#e74c3c"))
            elif stok < 20:
                stock_item.setForeground(QColor("#f39c12"))
            else:
                stock_item.setForeground(QColor("#27ae60"))
            
            # Price
            price = float(product.get('harga_jual', 0))
            price_item = QTableWidgetItem(format_currency(price))
            price_item.setFont(QFont("Arial", 12, QFont.Bold))
            price_item.setForeground(QColor("#2980b9"))
            
            # Gambar
            image_item = QTableWidgetItem()
            if product.get('gambar'):  # Jika ada path gambar
                image_item.setText("📷 Ada")
                image_item.setForeground(QColor("#27ae60"))
            else:
                image_item.setText("❌ Tidak Ada")
                image_item.setForeground(QColor("#95a5a6"))
            image_item.setFont(QFont("Arial", 11))
            
            # Status
            if stok > 15:
                status = "🟢 Tersedia"
                status_color = QColor("#27ae60")
            elif stok > 5:
                status = "🟡 Stok Menipis"
                status_color = QColor("#f39c12")
            elif stok > 0:
                status = "🟠 Stok Rendah"
                status_color = QColor("#e67e22")
            else:
                status = "🔴 Habis"
                status_color = QColor("#e74c3c")
                
            status_item = QTableWidgetItem(status)
            status_item.setFont(QFont("Arial", 11, QFont.Bold))
            status_item.setForeground(status_color)
            
            # Action buttons
            action_widget = QWidget()
            action_layout = QHBoxLayout(action_widget)
            action_layout.setContentsMargins(8, 5, 8, 5)
            action_layout.setSpacing(8)
            
            edit_btn = QPushButton("✏️ Edit")
            delete_btn = QPushButton("🗑️ Hapus")
            
            edit_btn.setStyleSheet("""
                QPushButton {
                    background-color: #3498db;
                    color: white;
                    border: none;
                    padding: 8px 12px;
                    border-radius: 6px;
                    font-size: 12px;
                    font-weight: bold;
                    min-width: 60px;
                }
                QPushButton:hover {
                    background-color: #2980b9;
                }
            """)
            
            delete_btn.setStyleSheet("""
                QPushButton {
                    background-color: #e74c3c;
                    color: white;
                    border: none;
                    padding: 8px 12px;
                    border-radius: 6px;
                    font-size: 12px;
                    font-weight: bold;
                    min-width: 60px;
                }
                QPushButton:hover {
                    background-color: #c0392b;
                }
            """)
            
            edit_btn.clicked.connect(lambda checked, p=product: self.edit_product(p))
            delete_btn.clicked.connect(lambda checked, p=product: self.delete_product(p))
            
            action_layout.addWidget(edit_btn)
            action_layout.addWidget(delete_btn)
            action_layout.addStretch()
            
            # Set items
            self.table.setItem(row, 0, name_item)
            self.table.setItem(row, 1, category_item)
            self.table.setItem(row, 2, stock_item)
            self.table.setItem(row, 3, price_item)
            self.table.setItem(row, 4, image_item)
            self.table.setItem(row, 5, status_item)
            self.table.setCellWidget(row, 6, action_widget)
        
        
        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(30, 15, 30, 15)
        
        title = QLabel("🏪 Fashion Finance - Sistem Manajemen Inventori")
        title.setFont(QFont("Arial", 18, QFont.Bold))
        title.setStyleSheet("color: white;")
        
        nav_layout = QHBoxLayout()
        nav_layout.setSpacing(8)
        
        # Navigation buttons
        dashboard_btn = QPushButton("📊 Dashboard")
        inventory_btn = QPushButton("📦 Inventori")
        sales_btn = QPushButton("💳 Penjualan")
        expenses_btn = QPushButton("📋 Pengeluaran")
        reports_btn = QPushButton("📈 Laporan")
        settings_btn = QPushButton("⚙️ Pengaturan")
        logout_btn = QPushButton("🚪 Logout")
        
        menu_style = """
            QPushButton {
                color: white;
                border: 2px solid transparent;
                padding: 10px 16px;
                background: rgba(255,255,255,0.1);
                font-size: 12px;
                font-weight: bold;
                border-radius: 8px;
                min-height: 25px;
            }
            QPushButton:hover {
                background-color: #34495e;
                border: 2px solid #5a6c7d;
            }
            QPushButton:disabled {
                background-color: #1abc9c;
                color: white;
                border: 2px solid #16a085;
                font-weight: bold;
            }
        """
        
        for btn in [dashboard_btn, inventory_btn, sales_btn, expenses_btn, reports_btn, settings_btn, logout_btn]:
            btn.setStyleSheet(menu_style)
            btn.setCursor(Qt.PointingHandCursor)
        
        inventory_btn.setEnabled(False)
        dashboard_btn.clicked.connect(self.back_clicked.emit)
        sales_btn.clicked.connect(self.sales_clicked.emit)
        expenses_btn.clicked.connect(self.expenses_clicked.emit)
        reports_btn.clicked.connect(self.reports_clicked.emit)
        settings_btn.clicked.connect(self.settings_clicked.emit)
        logout_btn.clicked.connect(self.back_to_login)
        
        nav_layout.addWidget(dashboard_btn)
        nav_layout.addWidget(inventory_btn)
        nav_layout.addWidget(sales_btn)
        nav_layout.addWidget(expenses_btn)
        nav_layout.addWidget(reports_btn)
        nav_layout.addWidget(settings_btn)
        nav_layout.addStretch()
        nav_layout.addWidget(logout_btn)
        
        header_layout.addWidget(title)
        header_layout.addStretch()
        header_layout.addLayout(nav_layout)
        header.setLayout(header_layout)
        
        return header
    
    def load_data(self):
        # Get products from controller
        products = ProductController.get_all_products(active_only=False)
        
        self.table.setRowCount(len(products))
        
        for row, product in enumerate(products):
            # Product name
            name_item = QTableWidgetItem(product['nama_produk'])
            name_item.setFont(QFont("Arial", 12))
            
            # Category dengan icon
            kategori = product.get('kategori', '')
            category_icon = ""
            if kategori == "Dress": category_icon = "👗"
            elif kategori == "Kemeja": category_icon = "👔"
            elif kategori == "Celana": category_icon = "👖"
            elif kategori == "Sepatu": category_icon = "👟"
            elif kategori == "Jaket": category_icon = "🧥"
            else: category_icon = "💎"
            
            category_item = QTableWidgetItem(f"{category_icon} {kategori}")
            category_item.setFont(QFont("Arial", 12))
            
            # Stock
            stok = product.get('stok', 0)
            stock_item = QTableWidgetItem(f"{stok} pcs")
            stock_item.setFont(QFont("Arial", 12, QFont.Bold))
            if stok < 10:
                stock_item.setForeground(QColor("#e74c3c"))
            elif stok < 20:
                stock_item.setForeground(QColor("#f39c12"))
            else:
                stock_item.setForeground(QColor("#27ae60"))
            
            # Price
            price = float(product.get('harga_jual', 0))
            price_item = QTableWidgetItem(format_currency(price))
            price_item.setFont(QFont("Arial", 12, QFont.Bold))
            price_item.setForeground(QColor("#2980b9"))
            
            # Gambar
            image_item = QTableWidgetItem()
            if product.get('gambar'):  # Jika ada path gambar
                image_item.setText("📷 Ada")
                image_item.setForeground(QColor("#27ae60"))
            else:
                image_item.setText("❌ Tidak Ada")
                image_item.setForeground(QColor("#95a5a6"))
            image_item.setFont(QFont("Arial", 11))
            
            # Status
            if stok > 15:
                status = "🟢 Tersedia"
                status_color = QColor("#27ae60")
            elif stok > 5:
                status = "🟡 Stok Menipis"
                status_color = QColor("#f39c12")
            elif stok > 0:
                status = "🟠 Stok Rendah"
                status_color = QColor("#e67e22")
            else:
                status = "🔴 Habis"
                status_color = QColor("#e74c3c")
                
            status_item = QTableWidgetItem(status)
            status_item.setFont(QFont("Arial", 11, QFont.Bold))
            status_item.setForeground(status_color)
            
            # Action buttons
            action_widget = QWidget()
            action_layout = QHBoxLayout(action_widget)
            action_layout.setContentsMargins(8, 5, 8, 5)
            action_layout.setSpacing(8)
            
            edit_btn = QPushButton("✏️ Edit")
            delete_btn = QPushButton("🗑️ Hapus")
            
            edit_btn.setStyleSheet("""
                QPushButton {
                    background-color: #3498db;
                    color: white;
                    border: none;
                    padding: 8px 12px;
                    border-radius: 6px;
                    font-size: 12px;
                    font-weight: bold;
                    min-width: 60px;
                }
                QPushButton:hover {
                    background-color: #2980b9;
                }
            """)
            
            delete_btn.setStyleSheet("""
                QPushButton {
                    background-color: #e74c3c;
                    color: white;
                    border: none;
                    padding: 8px 12px;
                    border-radius: 6px;
                    font-size: 12px;
                    font-weight: bold;
                    min-width: 60px;
                }
                QPushButton:hover {
                    background-color: #c0392b;
                }
            """)
            
            edit_btn.clicked.connect(lambda checked, p=product: self.edit_product(p))
            delete_btn.clicked.connect(lambda checked, p=product: self.delete_product(p))
            
            action_layout.addWidget(edit_btn)
            action_layout.addWidget(delete_btn)
            action_layout.addStretch()
            
            # Set items
            self.table.setItem(row, 0, name_item)
            self.table.setItem(row, 1, category_item)
            self.table.setItem(row, 2, stock_item)
            self.table.setItem(row, 3, price_item)
            self.table.setItem(row, 4, image_item)
            self.table.setItem(row, 5, status_item)
            self.table.setCellWidget(row, 6, action_widget)
    
    def add_product(self):
        dialog = AddProductDialog(self)
        if dialog.exec_():
            data = dialog.get_data()
            
            # Use controller to add product
            success, result = ProductController.create_product(
                kode_produk=data['sku'],
                nama_produk=data['name'],
                kategori=data['category'],
                harga_jual=data['price'],
                stok=data['stock'],
                user_id=1,  # Default user
                image_path=data.get('image_path')
            )
            
            if success:
                QMessageBox.information(self, "Sukses", "✅ Produk berhasil ditambahkan!")
                self.load_data()
            else:
                QMessageBox.warning(self, "Error", f"❌ Gagal menambah produk: {result}")
    
    def edit_product(self, product):
        # Convert product dict to tuple format for dialog compatibility
        # Dialog expects: (id, name, category, stock, price, sku, ..., image, status)
        product_tuple = (
            product.get('id'),
            str(product.get('nama_produk', '')),  # Index 1 - name (string)
            str(product.get('kategori', '')),  # Index 2 - category (string)
            int(product.get('stok', 0)),  # Index 3 - stock (int)
            float(product.get('harga_jual', 0)),  # Index 4 - price (float)
            str(product.get('kode_produk', '')),  # Index 5 - sku (string)
            product.get('user_id'),  # Index 6
            None,  # Index 7 - placeholder
            product.get('gambar', ''),  # Index 8 - image
            product.get('status', 'Aktif')  # Index 9 - status
        )
        dialog = AddProductDialog(self, product_tuple)
        if dialog.exec_():
            data = dialog.get_data()
            
            # Use controller to update product
            updates = {
                'nama_produk': data['name'],
                'harga_jual': data['price'],
                'stok': data['stock'],
                'kode_produk': data['sku'],
                'kategori': data['category']
            }
            if data.get('image_path'):
                updates['image_path'] = data['image_path']
            
            success, result = ProductController.update_product(product['id'], **updates)
            
            if success:
                QMessageBox.information(self, "Sukses", "✅ Produk berhasil diupdate!")
                self.load_data()
            else:
                QMessageBox.warning(self, "Error", f"❌ Gagal update produk: {result}")
    
    def delete_product(self, product):
        reply = QMessageBox.question(self, "Konfirmasi", 
                                   f"Apakah Anda yakin ingin menghapus {product.get('nama_produk', 'produk ini')}?",
                                   QMessageBox.Yes | QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            # Use controller to delete product (soft delete)
            success, result = ProductController.delete_product(product['id'])
            
            if success:
                QMessageBox.information(self, "Sukses", "✅ Produk berhasil dihapus!")
                self.load_data()
            else:
                QMessageBox.warning(self, "Error", f"❌ Gagal menghapus produk: {result}")
    
    def back_to_login(self):
        reply = QMessageBox.question(self, "Konfirmasi", 
                                   "Apakah Anda yakin ingin logout?",
                                   QMessageBox.Yes | QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            self.back_clicked.emit()