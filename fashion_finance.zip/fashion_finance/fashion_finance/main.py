"""Main application entry point - Fashion Finance"""
import sys
import logging
import io
from PyQt5.QtWidgets import QApplication, QMainWindow, QStackedWidget, QMessageBox
from PyQt5.QtCore import Qt

# Fix Windows console encoding for Unicode characters
if sys.platform == 'win32':
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    except:
        pass  # If already wrapped or not available, continue

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Import MVC components
from app.models.database import db
from app.controllers.auth_controller import AuthController

# Import UI components from views
try:
    from app.views.ui_login import LoginView
    from app.views.ui_dashboard import DashboardWindow
    from app.views.ui_inventory import InventoryWindow
    from app.views.ui_sales import SalesWindow
    from app.views.ui_expenses import ExpensesWindow
    from app.views.ui_reports import ReportsWindow
    from app.views.ui_settings import SettingsWindow
    from app.views.profile import ProfileView
except ImportError as e:
    logger.error(f"Error importing UI modules: {e}")
    print(f"❌ Error importing UI modules: {e}")
    print("Pastikan semua file UI sudah ada di app/views/ folder")
    sys.exit(1)


def check_database_connection():
    """Check database connection and initialize tables"""
    try:
        # Test connection
        if not db.test_connection():
            return False, {'status': 'error', 'error': 'Koneksi database gagal. Periksa konfigurasi di app/config/database.py'}
        
        # Create tables if they don't exist
        try:
            db.create_tables()
        except Exception as e:
            logger.warning(f"Could not create tables: {e}")
            # Continue anyway - tables might already exist
        
        # Get connection info
        conn = db.get_connection()
        cursor = conn.cursor(buffered=True)  # Use buffered cursor
        
        # Get database info
        cursor.execute("SELECT DATABASE()")
        db_name = cursor.fetchone()[0]
        
        cursor.execute("SELECT VERSION()")
        mysql_version = cursor.fetchone()[0]
        
        cursor.execute("SHOW TABLES")
        tables = cursor.fetchall()
        
        # Count data in tables
        total_data = 0
        table_details = {}
        
        for table in tables:
            table_name = table[0]
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            count = cursor.fetchone()[0]
            total_data += count
            table_details[table_name] = count
            
            # Get sample data for users and products
            if table_name == 'users':
                cursor.execute(f"SELECT username, role FROM {table_name} LIMIT 3")
                sample_data = cursor.fetchall()
                table_details[f'{table_name}_sample'] = sample_data
            elif table_name == 'products':
                cursor.execute(f"SELECT nama_produk, harga_jual FROM {table_name} LIMIT 2")
                sample_data = cursor.fetchall()
                table_details[f'{table_name}_sample'] = sample_data
        
        cursor.close()
        conn.close()
        
        connection_info = {
            'status': 'connected',
            'database': db_name,
            'mysql_version': mysql_version,
            'total_tables': len(tables),
            'total_data': total_data,
            'table_details': table_details
        }
        
        return True, connection_info
        
    except Exception as e:
        logger.error(f"Database connection error: {e}")
        return False, {'status': 'error', 'error': str(e)}


def show_connection_status():
    """Display database connection status"""
    success, info = check_database_connection()
    
    if success:
        message = f"""
🎉 KONEKSI DATABASE BERHASIL!

📊 INFORMASI DATABASE:
   • Database: {info['database']}
   • MySQL Version: {info['mysql_version']}
   • Total Tabel: {info['total_tables']}
   • Total Data: {info['total_data']}

📋 DETAIL TABEL:
"""
        for table_name, count in info['table_details'].items():
            if not table_name.endswith('_sample'):
                message += f"   • {table_name}: {count} records\n"
        
        # Show sample data
        if 'users_sample' in info['table_details']:
            message += "\n👥 SAMPLE USER DATA:\n"
            for user in info['table_details']['users_sample']:
                message += f"   • Username: {user[0]}, Role: {user[1]}\n"
        
        if 'products_sample' in info['table_details']:
            message += "\n📦 SAMPLE PRODUCT DATA:\n"
            for product in info['table_details']['products_sample']:
                message += f"   • Produk: {product[0]}, Harga: Rp {product[1]:,.0f}\n"
        
        message += f"\n✅ Status: Database siap digunakan!"
        
        print("=" * 60)
        print("DATABASE CONNECTION STATUS: SUCCESS")
        print("=" * 60)
        print(message)
        return True
        
    else:
        error_message = f"""
❌ KONEKSI DATABASE GAGAL!

ERROR DETAIL:
• Status: {info['status']}
• Error: {info['error']}

PERIKSA:
1. Pastikan MySQL/XAMPP berjalan
2. Cek username dan password MySQL
3. Pastikan database 'fashion_finance' ada
4. Periksa koneksi jaringan

SOLUSI:
• Jalankan XAMPP dan start MySQL
• Buat database jika belum ada
• Periksa configurasi koneksi di app/config/database.py
"""
        print("=" * 60)
        print("DATABASE CONNECTION STATUS: FAILED")
        print("=" * 60)
        print(error_message)
        
        # Show error dialog
        app = QApplication(sys.argv)
        QMessageBox.critical(
            None, 
            "Database Connection - FAILED", 
            f"❌ Gagal terhubung ke database!\n\nError: {info['error']}\n\nPeriksa apakah MySQL berjalan dan database 'fashion_finance' sudah dibuat."
        )
        return False


class MainApp(QMainWindow):
    """Main application window"""
    
    def __init__(self):
        super().__init__()
        self.auth_controller = AuthController()
        self.current_user_role = None
        self.current_username = None
        self.init_ui()
        
    def init_ui(self):
        """Initialize UI"""
        self.setWindowTitle("Fashion Finance - Database Connected ✓")
        self.setGeometry(100, 100, 1200, 800)
        
        # Central widget with stacked widget
        self.stacked_widget = QStackedWidget()
        self.setCentralWidget(self.stacked_widget)
        
        # Initialize windows
        try:
            from app.views.ui_login import LoginView as _LoginClass
        except Exception:
            try:
                from app.views.ui_login import LoginWindow as _LoginClass
            except Exception:
                import importlib
                mod = importlib.import_module('app.views.ui_login')
                _LoginClass = getattr(mod, 'LoginView', getattr(mod, 'LoginWindow', None))
        
        if _LoginClass is None:
            raise ImportError('No login class found in app.views.ui_login')
        
        self.login_window = _LoginClass()
        self.dashboard_window = DashboardWindow()
        self.inventory_window = InventoryWindow()
        self.sales_window = SalesWindow()
        self.expenses_window = ExpensesWindow()
        self.reports_window = ReportsWindow()
        self.settings_window = SettingsWindow()
        self.profile_window = ProfileView()
        
        # Add windows to stacked widget
        self.stacked_widget.addWidget(self.login_window)
        self.stacked_widget.addWidget(self.dashboard_window)
        self.stacked_widget.addWidget(self.inventory_window)
        self.stacked_widget.addWidget(self.sales_window)
        self.stacked_widget.addWidget(self.expenses_window)
        self.stacked_widget.addWidget(self.reports_window)
        self.stacked_widget.addWidget(self.settings_window)
        self.stacked_widget.addWidget(self.profile_window)
        
        # Connect signals
        self.connect_signals()
        
        # Show login window first
        self.stacked_widget.setCurrentWidget(self.login_window)
        
        logger.info("Application initialized")
        print("\n🚀 APLIKASI FASHION FINANCE DIMULAI")
        print("📍 Current window: Login")
        
    def connect_signals(self):
        """Connect UI signals"""
        # Login window signals
        def _login_adapter(*args):
            username = None
            role = None
            if len(args) == 1:
                role = args[0]
            elif len(args) >= 2:
                username = args[0]
                role = args[1]
            
            # Apply login handling
            self.current_user_role = role
            self.current_username = username
            
            # Update window title
            self.setWindowTitle(f"Fashion Finance - {username} ({role}) ✓")
            
            # Log login success
            logger.info(f"User logged in: {username} ({role})")
            print(f"\n🔐 LOGIN BERHASIL")
            print(f"   👤 User: {username}")
            print(f"   🎯 Role: {role}")
            print(f"   📍 Current window: Dashboard")
            
            self.dashboard_window.set_user_role(role)
            self.reports_window.set_user_role(role)
            
            # Pass to settings window
            if hasattr(self.settings_window, 'set_user_info'):
                if username is not None:
                    try:
                        self.settings_window.set_user_info(role, username)
                    except TypeError:
                        try:
                            self.settings_window.set_user_info(username, role)
                        except Exception:
                            self.settings_window.set_user_role(role)
                else:
                    self.settings_window.set_user_role(role)
            self.show_dashboard()
        
        # Connect known signal names
        if hasattr(self.login_window, 'login_success'):
            try:
                self.login_window.login_success.connect(_login_adapter)
            except Exception:
                pass
        if hasattr(self.login_window, 'loginSuccessful'):
            try:
                self.login_window.loginSuccessful.connect(_login_adapter)
            except Exception:
                pass
        
        # Dashboard signals
        self.dashboard_window.inventory_clicked.connect(self.show_inventory)
        self.dashboard_window.sales_clicked.connect(self.show_sales)
        self.dashboard_window.expenses_clicked.connect(self.show_expenses)
        self.dashboard_window.reports_clicked.connect(self.show_reports)
        self.dashboard_window.settings_clicked.connect(self.show_settings)
        self.dashboard_window.logout_clicked.connect(self.logout)
        
        # Inventory signals
        self.inventory_window.back_clicked.connect(self.show_dashboard)
        self.inventory_window.sales_clicked.connect(self.show_sales)
        self.inventory_window.expenses_clicked.connect(self.show_expenses)
        self.inventory_window.reports_clicked.connect(self.show_reports)
        self.inventory_window.settings_clicked.connect(self.show_settings)
        
        # Sales signals
        self.sales_window.back_clicked.connect(self.show_dashboard)
        self.sales_window.inventory_clicked.connect(self.show_inventory)
        self.sales_window.expenses_clicked.connect(self.show_expenses)
        self.sales_window.reports_clicked.connect(self.show_reports)
        self.sales_window.settings_clicked.connect(self.show_settings)
        
        # Expenses signals
        self.expenses_window.back_clicked.connect(self.show_dashboard)
        self.expenses_window.inventory_clicked.connect(self.show_inventory)
        self.expenses_window.sales_clicked.connect(self.show_sales)
        self.expenses_window.reports_clicked.connect(self.show_reports)
        self.expenses_window.settings_clicked.connect(self.show_settings)
        
        # Reports signals
        self.reports_window.dashboard_clicked.connect(self.show_dashboard)
        self.reports_window.inventory_clicked.connect(self.show_inventory)
        self.reports_window.sales_clicked.connect(self.show_sales)
        self.reports_window.expenses_clicked.connect(self.show_expenses)
        self.reports_window.settings_clicked.connect(self.show_settings)
        self.reports_window.logout_clicked.connect(self.logout)
        
        # Settings signals
        self.settings_window.dashboard_clicked.connect(self.show_dashboard)
        self.settings_window.inventory_clicked.connect(self.show_inventory)
        self.settings_window.sales_clicked.connect(self.show_sales)
        self.settings_window.expenses_clicked.connect(self.show_expenses)
        self.settings_window.reports_clicked.connect(self.show_reports)
        self.settings_window.profile_clicked.connect(self.show_profile)
        self.settings_window.logout_clicked.connect(self.logout)
        
        # Profile signals
        self.profile_window.back_clicked.connect(self.show_settings)
    
    def show_dashboard(self):
        """Show dashboard window"""
        logger.info("Showing dashboard")
        print(f"📍 Current window: Dashboard")
        self.dashboard_window.load_data()
        self.stacked_widget.setCurrentWidget(self.dashboard_window)
    
    def show_inventory(self):
        """Show inventory window"""
        if self.current_user_role == "kasir":
            print("❌ Akses ditolak: Kasir tidak bisa akses Inventory")
            QMessageBox.warning(self, "Akses Ditolak", "Anda tidak memiliki akses ke menu Inventori!")
            return
        logger.info("Showing inventory")
        print(f"📍 Current window: Inventory")
        self.inventory_window.load_data()
        self.stacked_widget.setCurrentWidget(self.inventory_window)
    
    def show_sales(self):
        """Show sales window"""
        logger.info("Showing sales")
        print(f"📍 Current window: Sales")
        self.sales_window.load_data()
        self.stacked_widget.setCurrentWidget(self.sales_window)
    
    def show_expenses(self):
        """Show expenses window"""
        logger.info("Showing expenses")
        print(f"📍 Current window: Expenses")
        self.expenses_window.load_data()
        self.stacked_widget.setCurrentWidget(self.expenses_window)
    
    def show_reports(self):
        """Show reports window"""
        if self.current_user_role == "kasir":
            print("❌ Akses ditolak: Kasir tidak bisa akses Reports")
            QMessageBox.warning(self, "Akses Ditolak", "Anda tidak memiliki akses ke menu Laporan!")
            return
        logger.info("Showing reports")
        print(f"📍 Current window: Reports")
        self.reports_window.load_data()
        self.stacked_widget.setCurrentWidget(self.reports_window)
    
    def show_settings(self):
        """Show settings window"""
        if self.current_user_role == "kasir":
            print("❌ Akses ditolak: Kasir tidak bisa akses Settings")
            QMessageBox.warning(self, "Akses Ditolak", "Anda tidak memiliki akses ke menu Pengaturan!")
            return
        logger.info("Showing settings")
        print(f"📍 Current window: Settings")
        self.settings_window.load_data()
        self.stacked_widget.setCurrentWidget(self.settings_window)
    
    def show_profile(self):
        """Show profile window"""
        logger.info("Showing profile")
        print(f"📍 Current window: Profile")
        self.stacked_widget.setCurrentWidget(self.profile_window)
    
    def logout(self):
        """Logout user"""
        reply = QMessageBox.question(
            self, 
            "Konfirmasi Logout", 
            "Apakah Anda yakin ingin logout?",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            logger.info(f"User logged out: {self.current_username}")
            print(f"\n🚪 LOGOUT: User {self.current_username}")
            self.auth_controller.logout()
            self.current_user_role = None
            self.current_username = None
            self.setWindowTitle("Fashion Finance - Database Connected ✓")
            self.stacked_widget.setCurrentWidget(self.login_window)
            print("📍 Current window: Login")


if __name__ == "__main__":
    # Check database connection before running application
    print("CHECKING DATABASE CONNECTION...")
    
    if not show_connection_status():
        # If connection fails, ask user if they want to continue
        app = QApplication(sys.argv)
        reply = QMessageBox.question(
            None, 
            "Database Connection Failed", 
            "Koneksi database gagal! Apakah Anda tetap ingin menjalankan aplikasi?",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.No:
            sys.exit(1)
    
    # If connection successful or user chose to continue, run application
    app = QApplication(sys.argv)
    
    # Set application style
    app.setStyleSheet("""
        QMainWindow {
            background-color: #f8f9fa;
        }
        QStatusBar {
            background-color: #2c3e50;
            color: white;
            padding: 5px;
        }
    """)
    
    main_app = MainApp()
    main_app.show()
    
    # Add status bar info
    main_app.statusBar().showMessage("✅ Database Connected - Fashion Finance Ready")
    
    print("\n🎯 APLIKASI GUI DIMULAI...")
    print("💡 Tips: Lihat console untuk info koneksi dan log aktivitas")
    
    sys.exit(app.exec_())
