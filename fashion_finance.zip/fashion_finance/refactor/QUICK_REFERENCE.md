# AddProductDialog - Quick Reference

## Quick Start

### Using the Dialog

```python
from app.views.add_product_dialog import AddProductDialog

# Create new product
dialog = AddProductDialog(parent=self)
if dialog.exec_():
    data = dialog.get_data()
    # data = {
    #     'name': str,
    #     'category': str,
    #     'stock': int,
    #     'price': int,
    #     'sku': str,
    #     'image_path': str or None
    # }

# Edit existing product  
product_tuple = (id, name, category, stock, price, sku, user_id, None, image_path, status)
dialog = AddProductDialog(parent=self, product_data=product_tuple)
if dialog.exec_():
    data = dialog.get_data()
```

## File Locations

| Component | File | Line Count |
|-----------|------|-----------|
| ProductImageSection | `app/views/add_product_dialog.py` | ~180 lines |
| AddProductDialog | `app/views/add_product_dialog.py` | ~170 lines |
| InventoryWindow | `app/views/ui_inventory.py` | ~570 lines |

## Class Reference

### ProductImageSection

```python
class ProductImageSection(QFrame):
    # Public Methods
    select_image()                      # User picks file
    load_image(path: str)               # Display image
    clear_image()                       # Reset state
    generate_auto_image(category: str)  # Auto-generate by category
    download_and_display_image(url: str)  # Download from URL
    get_image_path() -> str or None     # Get selected path
    set_image_path(path: str)           # Set and display
```

### AddProductDialog

```python
class AddProductDialog(FormDialog):
    # Public Methods
    get_data() -> dict                  # Return form data
    validate_and_accept()               # Validate & close
    
    # Inherited from FormDialog
    show_error(msg: str)                # Show error dialog
    show_success(msg: str)              # Show success dialog
```

## Field Configuration

```python
# Fields are configured via:
fields_config = [
    {
        'name': 'name',
        'label': '📝 Nama Produk',
        'type': 'text',
        'placeholder': 'Nama produk',
        'required': True
    },
    {
        'name': 'category',
        'label': '📂 Kategori',
        'type': 'combo',
        'items': ['Dress', 'Kemeja', 'Celana', 'Aksesoris', 'Sepatu', 'Jaket'],
        'required': True
    },
    {
        'name': 'stock',
        'label': '📊 Stok',
        'type': 'number',
        'min': 0,
        'max': 1000,
        'required': True
    },
    {
        'name': 'price',
        'label': '💰 Harga',
        'type': 'text',
        'placeholder': 'Contoh: 120000 (tanpa titik/koma)',
        'required': True
    },
    {
        'name': 'sku',
        'label': '🏷️ SKU',
        'type': 'text',
        'placeholder': 'SKU/Kode Produk',
        'required': True
    }
]
```

## Data Return Format

```python
# get_data() returns dictionary:
{
    'name': 'Dress Casual',              # str
    'category': 'Dress',                 # str
    'stock': 15,                         # int
    'price': 250000,                     # int (converted from string)
    'sku': 'DRS001',                     # str
    'image_path': '/path/to/image.jpg'   # str or None
}
```

## Image Categories & URLs

| Category | Count | Source |
|----------|-------|--------|
| Dress | 3 | Unsplash |
| Kemeja | 3 | Unsplash |
| Celana | 3 | Unsplash |
| Aksesoris | 3 | Unsplash |
| Sepatu | 3 | Unsplash |
| Jaket | 3 | Unsplash |

Each category has 3 random URLs, one is selected on auto-generate.

## Common Usage Patterns

### Pattern 1: Add New Product
```python
def add_product(self):
    dialog = AddProductDialog(self)
    if dialog.exec_():
        data = dialog.get_data()
        success, msg = ProductController.create_product(
            kode_produk=data['sku'],
            nama_produk=data['name'],
            kategori=data['category'],
            harga_jual=data['price'],
            stok=data['stock'],
            user_id=1,
            image_path=data['image_path']
        )
        if success:
            self.load_data()
```

### Pattern 2: Edit Existing Product
```python
def edit_product(self, product):
    product_tuple = (
        product['id'],
        product['nama_produk'],
        product['kategori'],
        product['stok'],
        product['harga_jual'],
        product['kode_produk'],
        product['user_id'],
        None,
        product.get('gambar'),
        product.get('status')
    )
    dialog = AddProductDialog(self, product_tuple)
    if dialog.exec_():
        data = dialog.get_data()
        success, msg = ProductController.update_product(
            product['id'],
            nama_produk=data['name'],
            kategori=data['category'],
            stok=data['stock'],
            harga_jual=data['price'],
            kode_produk=data['sku'],
            image_path=data['image_path']
        )
        if success:
            self.load_data()
```

## Validation Rules

| Field | Type | Rules |
|-------|------|-------|
| name | text | Required, non-empty |
| category | combo | Required, one of 6 options |
| stock | number | Required, 0-1000 range |
| price | text | Required, positive integer |
| sku | text | Required, non-empty |
| image | file | Optional, jpg/png/bmp/gif |

## Error Messages

```
"[Field] harus diisi!"                    # Empty required field
"Format harga tidak valid! Gunakan angka saja."  # Non-numeric price
"Harga harus lebih dari 0!"               # Price <= 0
"Pilih kategori terlebih dahulu!"         # No category selected
```

## Component Dependencies

```
add_product_dialog.py
├── app.components.dialogs (FormDialog)
├── app.components.inputs (Styled*Input)
├── PyQt5.QtWidgets
├── PyQt5.QtCore
├── PyQt5.QtGui
├── requests (for image download)
├── tempfile (for temp image storage)
└── os (for path operations)
```

## Testing Checklist

- [ ] Create new product with custom image
- [ ] Create new product with auto-generated image
- [ ] Create new product without image
- [ ] Edit existing product
- [ ] Validate empty field error
- [ ] Validate price format error
- [ ] Validate price > 0 error
- [ ] Test category change image suggestion
- [ ] Test image download from URL
- [ ] Test image clear button
- [ ] Test dialog cancel/close
- [ ] Test data persistence after edit

## Known Limitations

1. **Synchronous Image Download**: Image download blocks UI during network request
2. **No Image Compression**: Downloaded images not compressed
3. **Temp File Cleanup**: Temp files persist until ProductController saves
4. **No Image Validation**: No checks for file format or size before save
5. **Single Image**: Only one image per product supported

## Future Enhancements

1. Async image download with progress indicator
2. Image size/format validation
3. Image compression before save
4. Automatic temp file cleanup
5. Image gallery/preview
6. Batch image upload
7. Image editing tools
8. Watermark support

## Related Files

- `app/views/ui_inventory.py` - Uses AddProductDialog
- `app/controllers/product_controller.py` - Processes data
- `app/components/dialogs.py` - FormDialog base class
- `app/components/inputs.py` - Styled input components

## Support & Debugging

### Issue: Image not saving
**Solution**: Check ProductController._save_product_image() handles path correctly

### Issue: Form fields not validating
**Solution**: Ensure field 'required' flag is set to True in config

### Issue: Price validation failing
**Solution**: Ensure price format is numeric (123000, not 123.000 or 123,000)

### Issue: Dialog not appearing
**Solution**: Check parent widget is passed correctly in __init__()

---

**Last Updated**: 2025-11-24
**Status**: Production Ready ✅
