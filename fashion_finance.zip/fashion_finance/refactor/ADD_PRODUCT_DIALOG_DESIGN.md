# AddProductDialog - Architecture & Design

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                  InventoryWindow (QWidget)                   │
│                                                               │
│  - Displays product list in table                            │
│  - Handles add/edit/delete operations                        │
│  - Manages navigation                                        │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       │ Creates
                       ▼
┌─────────────────────────────────────────────────────────────┐
│            AddProductDialog (FormDialog)                     │
│                                                               │
│  - Manages form fields configuration                         │
│  - Handles form validation                                   │
│  - Integrates ProductImageSection                           │
│  - Returns product data on accept                            │
│                                                               │
│  Fields:                                                      │
│  ├── Name (text)                                             │
│  ├── Category (combo)                                        │
│  ├── Stock (number)                                          │
│  ├── Price (text with validation)                            │
│  └── SKU (text)                                              │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       │ Contains
                       ▼
┌─────────────────────────────────────────────────────────────┐
│         ProductImageSection (QFrame)                         │
│                                                               │
│  - Image preview display                                     │
│  - File selection button                                     │
│  - Auto-generate button                                      │
│  - Clear button                                              │
│                                                               │
│  Features:                                                   │
│  ├── Select image from file system                           │
│  ├── Auto-generate by category                               │
│  ├── Download from URL                                       │
│  └── Display preview                                         │
└─────────────────────────────────────────────────────────────┘
```

---

## Class Hierarchy

```
QWidget
  └── QFrame
        └── ProductImageSection
              ├── select_image()
              ├── load_image()
              ├── clear_image()
              ├── generate_auto_image()
              ├── download_and_display_image()
              ├── get_image_path()
              └── set_image_path()

QDialog
  └── BaseDialog
        └── FormDialog
              └── AddProductDialog
                    ├── _prepare_product_data()
                    ├── _setup_image_section()
                    ├── validate_and_accept()
                    └── get_data()
```

---

## Data Flow

### Creating a New Product

```
1. User clicks "Tambah Produk" button in InventoryWindow
   │
   ├─► AddProductDialog.__init__(parent=self, product_data=None)
   │   └─► FormDialog.__init__() - Sets up form fields
   │       └─► ProductImageSection initialized
   │
2. Form displayed to user
   │
   ├─► User enters: name, category, stock, price, SKU
   ├─► User selects/generates image (optional)
   │
3. User clicks OK
   │
   ├─► validate_and_accept()
   │   ├─► super().validate_and_accept()  # Required fields check
   │   └─► Custom validation (price format, price > 0)
   │
4. If valid: Dialog accepted
   │
   ├─► data = dialog.get_data()
   │   └─► Returns:
   │       {
   │           'name': 'Product Name',
   │           'category': 'Dress',
   │           'stock': 10,
   │           'price': 120000,
   │           'sku': 'SKU123',
   │           'image_path': '/temp/image.jpg'
   │       }
   │
5. InventoryWindow processes data
   │
   └─► ProductController.create_product()
       └─► Database + Image saved
```

### Editing an Existing Product

```
1. User clicks "Edit" button for existing product
   │
   ├─► product_tuple = (id, name, category, stock, price, sku, user_id, None, image_path, status)
   │
2. AddProductDialog.__init__(parent=self, product_data=product_tuple)
   │
   ├─► _prepare_product_data()  # Extract fields from tuple
   │   └─► Pre-populate form with existing data
   │
   ├─► _setup_image_section()
   │   └─► Load existing image if available
   │
3. User modifies fields (optional)
   │
4. User clicks OK
   │
   ├─► validate_and_accept()  # Same validation
   │
5. Data returned with modifications
   │
   └─► ProductController.update_product()
```

---

## Component Responsibilities

### ProductImageSection

**Purpose**: Encapsulate all image-related operations

**Responsibilities**:
- Display image preview
- Handle file selection
- Manage image download
- Cache temporary images
- Generate placeholder images

**Methods**:
```python
public:
    select_image()              # Open file dialog
    load_image(path)            # Load from file system
    clear_image()               # Clear selection
    generate_auto_image(cat)    # Auto-generate by category
    download_and_display(url)   # Download from URL
    get_image_path()            # Get selected path
    set_image_path(path)        # Set and display

private:
    _create_button(text, bg, hover)  # Button factory
    init_ui()                   # Initialize UI
```

### AddProductDialog

**Purpose**: Manage product form and validation

**Responsibilities**:
- Configuration-driven form generation (from base class)
- Product data preparation
- Form validation (custom logic)
- Image section integration
- Data formatting on return

**Methods**:
```python
public:
    get_data()                  # Return form data
    validate_and_accept()       # Custom validation

private:
    _prepare_product_data()     # Extract from tuple
    _setup_image_section()      # Setup image component
    init_ui()                   # Inherited from FormDialog
```

### InventoryWindow

**Purpose**: Manage inventory operations

**Responsibilities**:
- Display product list
- Handle CRUD operations
- Show dialogs
- Refresh data
- Navigate

**Methods**:
```python
public:
    load_data()                 # Load from database
    add_product()               # Create new
    edit_product(product)       # Update existing
    delete_product(product)     # Remove product
    back_to_login()             # Logout
```

---

## Integration with ProductController

```
AddProductDialog
    │
    ├─► Collects: name, category, stock, price, SKU, image_path
    │
    └─► InventoryWindow calls:
        
        ProductController.create_product(
            kode_produk=data['sku'],
            nama_produk=data['name'],
            kategori=data['category'],
            harga_jual=data['price'],
            stok=data['stock'],
            user_id=1,
            image_path=data['image_path']
        )
        
        # Controller handles:
        ├─► Validate SKU uniqueness
        ├─► Save image to images/products/
        ├─► Insert into database
        └─► Return success/error
```

---

## Styling Consistency

All components use project's color scheme:

```
Primary Colors:
  - Dark Blue: #2c3e50
  - Light Blue: #3498db
  - Darker Blue: #2980b9

Accent Colors:
  - Green (Success): #27ae60
  - Red (Error): #e74c3c
  - Orange (Warning): #f39c12
  - Purple: #9b59b6

Backgrounds:
  - Light Gray: #f8f9fa
  - White: #ffffff
  - Border Gray: #e0e0e0
```
