# Fashion Finance - Architecture Documentation

## Overview

This project has been refactored from a monolithic SQLite-based application to a modular, maintainable MVC architecture using MySQL.

## Architecture Pattern: MVC (Model-View-Controller)

### Model Layer (`app/models/`)
**Responsibility**: Data access and database operations

- **`database.py`**: MySQL connection pool manager
- **`user_model.py`**: User authentication and management
- **`product_model.py`**: Product/inventory operations
- **`transaction_model.py`**: Sales transaction operations
- **`customer_model.py`**: Customer management
- **`expense_model.py`**: Expense tracking
- **`report_model.py`**: Analytics and reporting

**Key Features**:
- Connection pooling for performance
- Error handling and logging
- Transaction support
- Dictionary-based results (easier to work with)

### Controller Layer (`app/controllers/`)
**Responsibility**: Business logic and coordination

- **`auth_controller.py`**: Authentication and authorization
- **`product_controller.py`**: Product business logic
- **`transaction_controller.py`**: Transaction processing
- **`expense_controller.py`**: Expense management
- **`report_controller.py`**: Report generation

**Key Features**:
- Input validation
- Business rule enforcement
- Error handling
- Coordinates between models and views

### View Layer (`ui_*.py`)
**Responsibility**: User interface

- `ui_login.py`: Login screen
- `ui_dashboard.py`: Main dashboard
- `ui_inventory.py`: Product management
- `ui_sales.py`: Sales interface
- `ui_expenses.py`: Expense tracking
- `ui_reports.py`: Reports and analytics
- `ui_settings.py`: Settings
- `profile.py`: User profile

**Current State**: Uses compatibility layer (`database.py`) for backward compatibility. Can be gradually migrated to use controllers directly.

## Database Migration

### From SQLite to MySQL

The project has been migrated from SQLite to MySQL:

**Old Schema (SQLite)**:
- `owners`, `kasir` → **New**: `users` (unified with role)
- `barang` → **New**: `products`
- `pembeli` → **New**: `customers`
- `transaksi`, `detail_transaksi` → **New**: `sales`, `sales_details`
- `expenses` → **New**: `expenses` (similar structure)

**Key Improvements**:
- Unified user table with role-based access
- Better foreign key constraints
- Proper indexing for performance
- UTF8MB4 charset for full Unicode support

## Compatibility Layer

The `database.py` file provides a compatibility wrapper that:
- Maintains the old interface (`get_barang()`, `add_barang()`, etc.)
- Wraps new MySQL models
- Allows existing UI code to work without changes
- Enables gradual migration

## Configuration

### Database Configuration (`app/config/database.py`)

```python
HOST = 'localhost'
USER = 'root'
PASSWORD = ''
DATABASE = 'fashion_finance'
PORT = 3306
```

Can be overridden with environment variables:
- `DB_HOST`
- `DB_USER`
- `DB_PASSWORD`
- `DB_NAME`
- `DB_PORT`

## Data Flow

```
User Action (View)
    ↓
Controller (Business Logic)
    ↓
Model (Data Access)
    ↓
MySQL Database
```

## Example: Adding a Product

1. **View** (`ui_inventory.py`): User fills form and clicks "Add"
2. **Controller** (`product_controller.py`): 
   - Validates input
   - Handles image upload
   - Checks for duplicate codes
3. **Model** (`product_model.py`): 
   - Executes SQL INSERT
   - Returns product ID
4. **View**: Updates UI with new product

## Benefits of This Architecture

1. **Separation of Concerns**: Each layer has a clear responsibility
2. **Maintainability**: Easy to locate and fix bugs
3. **Testability**: Each layer can be tested independently
4. **Scalability**: Easy to add new features
5. **Database Independence**: Can switch databases by changing models
6. **Code Reusability**: Controllers can be reused across views

## Migration Path

### Phase 1: ✅ Complete
- Created MVC structure
- Migrated to MySQL
- Created compatibility layer
- Updated main.py

### Phase 2: Future (Optional)
- Migrate UI files to use controllers directly
- Remove compatibility layer
- Add unit tests
- Add API layer for future web interface

## Best Practices

### When Adding New Features:

1. **Start with Model**: Define database operations
   ```python
   # app/models/new_feature_model.py
   class NewFeatureModel:
       @staticmethod
       def create(data):
           # Database operation
   ```

2. **Add Controller**: Implement business logic
   ```python
   # app/controllers/new_feature_controller.py
   class NewFeatureController:
       @staticmethod
       def create_feature(data):
           # Validate
           # Call model
           # Return result
   ```

3. **Update View**: Use controller
   ```python
   # ui_new_feature.py
   from app.controllers.new_feature_controller import NewFeatureController
   result = NewFeatureController.create_feature(data)
   ```

## Performance Considerations

- **Connection Pooling**: Reuses database connections
- **Indexed Queries**: All foreign keys and common search fields are indexed
- **Lazy Loading**: Data loaded only when needed
- **Transaction Management**: Proper commit/rollback handling

## Security

- **Password Hashing**: SHA256 (consider upgrading to bcrypt)
- **SQL Injection Prevention**: Parameterized queries
- **Role-Based Access**: Admin/Kasir roles enforced
- **Input Validation**: Controllers validate all inputs

## Future Enhancements

- [ ] Add bcrypt for password hashing
- [ ] Implement API layer
- [ ] Add comprehensive unit tests
- [ ] Add logging to file
- [ ] Implement caching layer
- [ ] Add data export/import features
- [ ] Web interface option

