# setup_database.py
import mysql.connector
from mysql.connector import Error
import os

def create_database_schema():
    """Membuat database dan tabel-tabel yang diperlukan"""
    try:
        # Koneksi ke MySQL tanpa database spesifik
        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password=''  # Sesuaikan dengan password MySQL Anda
        )
        
        if connection.is_connected():
            cursor = connection.cursor()
            
            # Buat database jika belum ada
            cursor.execute("CREATE DATABASE IF NOT EXISTS fashion_finance")
            cursor.execute("USE fashion_finance")
            
            # Tabel users
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(50) UNIQUE NOT NULL,
                    password VARCHAR(255) NOT NULL,
                    role ENUM('admin', 'kasir') DEFAULT 'kasir',
                    nama_lengkap VARCHAR(100),
                    email VARCHAR(100),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Tabel categories
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS categories (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    nama_kategori VARCHAR(100) NOT NULL,
                    deskripsi TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Tabel products
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS products (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    kode_produk VARCHAR(50) UNIQUE NOT NULL,
                    nama_produk VARCHAR(255) NOT NULL,
                    kategori_id INT,
                    harga_beli DECIMAL(15,2),
                    harga_jual DECIMAL(15,2),
                    stok INT DEFAULT 0,
                    satuan VARCHAR(50),
                    deskripsi TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (kategori_id) REFERENCES categories(id)
                )
            """)
            
            # Tabel sales
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS sales (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    kode_transaksi VARCHAR(100) UNIQUE NOT NULL,
                    tanggal_transaksi DATE,
                    total DECIMAL(15,2),
                    bayar DECIMAL(15,2),
                    kembalian DECIMAL(15,2),
                    user_id INT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            # Tabel sale_items
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS sale_items (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    sale_id INT,
                    product_id INT,
                    quantity INT,
                    harga_satuan DECIMAL(15,2),
                    subtotal DECIMAL(15,2),
                    FOREIGN KEY (sale_id) REFERENCES sales(id),
                    FOREIGN KEY (product_id) REFERENCES products(id)
                )
            """)
            
            # Tabel expenses
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS expenses (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    kategori VARCHAR(100) NOT NULL,
                    deskripsi TEXT,
                    jumlah DECIMAL(15,2),
                    tanggal DATE,
                    user_id INT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            print("✅ Skema database berhasil dibuat!")
            
    except Error as e:
        print(f"❌ Error membuat skema database: {e}")
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()