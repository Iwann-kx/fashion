"""
Script to add manual refresh button to all view files
"""
import re

files_to_update = [
    ('c:/laragon/fashion_finance/app/views/ui_dashboard.py', 'Dashboard'),
    ('c:/laragon/fashion_finance/app/views/ui_inventory.py', 'Inventory'),
    ('c:/laragon/fashion_finance/app/views/ui_sales.py', 'Sales'),
    ('c:/laragon/fashion_finance/app/views/ui_expenses.py', 'Expenses'),
    ('c:/laragon/fashion_finance/app/views/ui_reports.py', 'Reports')
]

refresh_button_code = '''
        # Refresh button
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.setFixedHeight(40)
        refresh_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                padding: 10px 20px;
                border: none;
                border-radius: 8px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        refresh_btn.setCursor(Qt.PointingHandCursor)
        refresh_btn.clicked.connect(self.load_data)
        '''

for filepath, view_name in files_to_update:
    print(f"\n📝 Processing: {view_name}")
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Check if already has refresh button
        if '🔄 Refresh' in content or 'refresh_btn' in content:
            print(f"   ✅ Already has refresh button - skipping")
            continue
        
        # Find the page title section and add refresh button after subtitle
        # Look for pattern: subtitle = QLabel(...)
        pattern = r'(subtitle\.setStyleSheet\([^)]+\)\s*\n\s*layout\.addWidget\(page_title\)\s*\n\s*layout\.addWidget\(subtitle\))'
        
        if re.search(pattern, content):
            replacement = r'\1' + refresh_button_code + '\n        layout.addWidget(refresh_btn)'
            content = re.sub(pattern, replacement, content)
            
            # Write back
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            print(f"   ✅ Refresh button added successfully!")
        else:
            print(f"   ⚠️  Could not find suitable location for refresh button")
            
    except Exception as e:
        print(f"   ❌ Error: {e}")

print("\n🎉 Done! Refresh buttons added to all views.")
print("\nSekarang setiap halaman punya tombol '🔄 Refresh' untuk update data manual.")
