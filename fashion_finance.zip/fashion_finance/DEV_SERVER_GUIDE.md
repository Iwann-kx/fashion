# Development Server - Auto Reload

This file provides instructions for using the development server with auto-reload functionality.

## What is it?

The development server (`dev_server.py`) automatically monitors your Python files and restarts the application whenever you save changes. This is similar to how live servers work for web development.

## How to Use

### 1. Start the Development Server

Instead of running `python main.py`, run:

```bash
python dev_server.py
```

### 2. Make Changes to Your Code

- Edit any `.py` file in your project
- Save the file
- The application will automatically restart with your changes

### 3. Stop the Server

Press `Ctrl+C` to stop the development server.

## Features

✅ **Auto-reload** - Automatically restarts when code changes  
✅ **Real-time output** - See application logs in real-time  
✅ **Debouncing** - Prevents multiple restarts from rapid saves  
✅ **Recursive watching** - Monitors all subdirectories  

## What Files Are Watched?

The server monitors:
- All `.py` files in the root directory
- All `.py` files in the `app/` directory
- Subdirectories recursively

The server ignores:
- `__pycache__` directories
- `.git` directory
- `venv` or `env` directories
- `images` directory

## Configuration

You can modify `dev_server.py` to customize:
- Which directories to watch
- Which file types to monitor
- Debounce delay (default: 1 second)

## Requirements

The development server requires the `watchdog` package:

```bash
pip install watchdog
```

Or install all requirements:

```bash
pip install -r requirements.txt
```

## Example Output

```
============================================================
FASHION FINANCE - DEVELOPMENT SERVER
============================================================
[INFO] Auto-reload enabled
[INFO] Watching .py files for changes
============================================================

[WATCH] Monitoring: D:\Project\fashion_finance
[WATCH] Monitoring: D:\Project\fashion_finance\app
[INFO] File watcher started
[INFO] Press Ctrl+C to stop

============================================================
[STARTING] Fashion Finance Application...
============================================================
[OK] Application started (PID: 12345)
[INFO] Watching for file changes...
============================================================

[Application output appears here...]

[CHANGE DETECTED] app\views\products_view.py

============================================================
[RESTARTING] Reloading application...
============================================================
```

## Troubleshooting

### "watchdog package is not installed"
Run: `pip install watchdog`

### "main.py not found"
Make sure you're in the project directory: `d:\Project\fashion_finance`

### Application doesn't restart
- Check if the file you edited is a `.py` file
- Check if the file is in a watched directory
- Try saving the file again

## Normal Development vs Dev Server

**Normal way (manual restart):**
```bash
python main.py
# Make changes
# Stop with Ctrl+C
# Run again: python main.py
```

**With dev server (auto restart):**
```bash
python dev_server.py
# Make changes
# Save file
# Automatically restarts!
```
