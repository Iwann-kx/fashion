# monitor_connection.py
import mysql.connector
import time
from datetime import datetime

class DatabaseMonitor:
    def __init__(self):
        self.connection_config = {
            'host': 'localhost',
            'user': 'root',
            'password': '',
            'database': 'fashion_finance'
        }
        self.connection = None
    
    def connect(self):
        """Membuat koneksi ke database"""
        try:
            self.connection = mysql.connector.connect(**self.connection_config)
            if self.connection.is_connected():
                print(f"[{datetime.now().strftime('%H:%M:%S')}] ✅ Connected to database")
                return True
        except Exception as e:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] ❌ Connection failed: {e}")
            return False
    
    def get_database_stats(self):
        """Mendapatkan statistik database"""
        if not self.connection or not self.connection.is_connected():
            if not self.connect():
                return None
        
        try:
            cursor = self.connection.cursor()
            
            # Get basic info
            cursor.execute("SELECT DATABASE(), VERSION()")
            db_info = cursor.fetchone()
            
            # Get table counts
            cursor.execute("SHOW TABLES")
            tables = cursor.fetchall()
            
            stats = {
                'database': db_info[0],
                'version': db_info[1],
                'total_tables': len(tables),
                'tables': {}
            }
            
            # Get row count for each table
            for table in tables:
                table_name = table[0]
                cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                count = cursor.fetchone()[0]
                stats['tables'][table_name] = count
            
            cursor.close()
            return stats
            
        except Exception as e:
            print(f"Error getting stats: {e}")
            return None
    
    def monitor(self, interval=5):
        """Monitor database secara real-time"""
        print("🚀 Starting Database Monitor...")
        print("Press Ctrl+C to stop\n")
        
        try:
            while True:
                stats = self.get_database_stats()
                
                if stats:
                    print(f"[{datetime.now().strftime('%H:%M:%S')}] 📊 Database Stats:")
                    print(f"   📁 Database: {stats['database']}")
                    print(f"   🔧 MySQL Version: {stats['version']}")
                    print(f"   📋 Total Tables: {stats['total_tables']}")
                    print("   📈 Table Records:")
                    
                    for table, count in stats['tables'].items():
                        print(f"      • {table}: {count} records")
                    
                    print("-" * 50)
                else:
                    print(f"[{datetime.now().strftime('%H:%M:%S')}] ❌ Cannot get database stats")
                
                time.sleep(interval)
                
        except KeyboardInterrupt:
            print("\n🛑 Monitor stopped by user")
        finally:
            if self.connection and self.connection.is_connected():
                self.connection.close()
                print("🔌 Database connection closed")

if __name__ == "__main__":
    monitor = DatabaseMonitor()
    monitor.monitor(interval=10)  # Update setiap 10 detik