# reset_database.py
import sqlite3
import os
from datetime import datetime, timedelta
import shutil
import requests

def reset_database():
    print("🔄 Memulai reset database...")
    
    # Hapus database lama jika ada
    if os.path.exists('fashion_finance.db'):
        os.remove('fashion_finance.db')
        print("✅ Database lama dihapus")
    
    # Hapus folder images lama
    if os.path.exists('images'):
        shutil.rmtree('images')
        print("✅ Folder images lama dihapus")
    
    # Buat folder images
    os.makedirs('images/products', exist_ok=True)
    print("✅ Folder images/products dibuat")
    
    # Buat koneksi baru
    conn = sqlite3.connect('fashion_finance.db')
    cursor = conn.cursor()
    
    # Buat tabel dengan struktur yang benar
    print("📊 Membuat tabel database...")
    
    # Owners table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS owners (
            id_owner INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_owner VARCHAR(100),
            username VARCHAR(50),
            password VARCHAR(255),
            email VARCHAR(100)
        )
    ''')
    
    # Kasir table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS kasir (
            id_kasir INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_kasir VARCHAR(100),
            username VARCHAR(50),
            password VARCHAR(255),
            no_hp VARCHAR(20),
            alamat TEXT,
            tanggal_bergabung DATETIME,
            id_owner INTEGER,
            FOREIGN KEY (id_owner) REFERENCES owners(id_owner)
        )
    ''')
    
    # Barang table - DENGAN KOLOM GAMBAR
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS barang (
            id_barang INTEGER PRIMARY KEY AUTOINCREMENT,
            id_kasir INTEGER,
            nama_barang VARCHAR(100),
            harga INTEGER,
            stok INTEGER,
            kode_barang VARCHAR(45) UNIQUE,
            kategori VARCHAR(50),
            gambar TEXT,
            status VARCHAR(20) DEFAULT 'Aktif',
            FOREIGN KEY (id_kasir) REFERENCES kasir(id_kasir)
        )
    ''')
    
    # Tabel lainnya
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS pembeli (
            id_pembeli INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_pembeli VARCHAR(100),
            no_hp VARCHAR(20),
            alamat TEXT
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS transaksi (
            id_transaksi INTEGER PRIMARY KEY AUTOINCREMENT,
            id_kasir INTEGER,
            id_pembeli INTEGER,
            tanggal_transaksi DATETIME,
            total_harga INTEGER,
            metode_pembayaran VARCHAR(50),
            status VARCHAR(20) DEFAULT 'Selesai',
            FOREIGN KEY (id_kasir) REFERENCES kasir(id_kasir),
            FOREIGN KEY (id_pembeli) REFERENCES pembeli(id_pembeli)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS detail_transaksi (
            id_detail INTEGER PRIMARY KEY AUTOINCREMENT,
            id_transaksi INTEGER,
            id_barang INTEGER,
            jumlah INTEGER,
            subtotal INTEGER,
            FOREIGN KEY (id_transaksi) REFERENCES transaksi(id_transaksi),
            FOREIGN KEY (id_barang) REFERENCES barang(id_barang)
        )
    ''')
    
    # Insert sample data
    print("📝 Insert data sample...")
    
    # Insert owner
    import hashlib
    cursor.execute('''
        INSERT INTO owners (nama_owner, username, password, email)
        VALUES (?, ?, ?, ?)
    ''', ("Admin Fashion", "admin", 
          hashlib.sha256("admin".encode()).hexdigest(), 
          "admin@fashion.com"))
    
    owner_id = cursor.lastrowid
    
    # Insert kasir
    cursor.execute('''
        INSERT INTO kasir (nama_kasir, username, password, no_hp, alamat, tanggal_bergabung, id_owner)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', ("Kasir Utama", "kasir", 
          hashlib.sha256("kasir".encode()).hexdigest(),
          "08123456789", "Jl. Kasir No. 123", datetime.now(), owner_id))
    
    kasir_id = cursor.lastrowid
    
    # Insert sample barang dengan gambar
    sample_barang = [
        ("Dress Floral Summer", 450000, 25, "BRG001", "Dress"),
        ("Kemeja Formal Putih", 275000, 15, "BRG002", "Kemeja"),
        ("Celana Jeans Slim", 320000, 30, "BRG003", "Celana"),
        ("Tas Handbag Leather", 650000, 10, "BRG004", "Aksesoris"),
        ("Sepatu Sneakers Sport", 420000, 20, "BRG005", "Sepatu"),
        ("Blouse Silk Pink", 380000, 18, "BRG006", "Kemeja"),
        ("Rok Plisket Hitam", 320000, 12, "BRG007", "Dress"),
        ("Jaket Denim", 550000, 8, "BRG008", "Jaket")
    ]
    
    for i, barang in enumerate(sample_barang, 1):
        # Generate gambar otomatis
        image_path = generate_sample_image(barang[0], barang[4], i)
        
        cursor.execute('''
            INSERT INTO barang (nama_barang, harga, stok, kode_barang, kategori, gambar, id_kasir)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (barang[0], barang[1], barang[2], barang[3], barang[4], image_path, kasir_id))
        print(f"✅ Produk {barang[0]} ditambahkan")
    
    # Insert sample pembeli
    sample_pembeli = [
        ("Budi Santoso", "081234567890", "Jl. Merdeka No. 123"),
        ("Sari Dewi", "081298765432", "Jl. Sudirman No. 456"),
        ("Ahmad Fauzi", "081277788899", "Jl. Thamrin No. 789")
    ]
    
    for pembeli in sample_pembeli:
        cursor.execute('''
            INSERT INTO pembeli (nama_pembeli, no_hp, alamat)
            VALUES (?, ?, ?)
        ''', pembeli)
    
    conn.commit()
    conn.close()
    
    print("🎉 Database berhasil direset dengan struktur yang benar!")
    print("🚀 Sekarang jalankan: python main.py")

def generate_sample_image(product_name, category, product_id):
    """Generate gambar sample otomatis"""
    try:
        # URL gambar sample berdasarkan kategori
        image_urls = {
            "Dress": [
                "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop",
                "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=400&h=400&fit=crop",
            ],
            "Kemeja": [
                "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=400&h=400&fit=crop",
                "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&h=400&fit=crop",
            ],
            "Celana": [
                "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400&h=400&fit=crop",
                "https://images.unsplash.com/photo-1582418702059-97ebafb35d09?w=400&h=400&fit=crop",
            ],
            "Aksesoris": [
                "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400&h=400&fit=crop",
                "https://images.unsplash.com/photo-1594223274512-ad4803739b7c?w=400&h=400&fit=crop",
            ],
            "Sepatu": [
                "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop",
                "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=400&h=400&fit=crop",
            ],
            "Jaket": [
                "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop",
                "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400&h=400&fit=crop",
            ]
        }
        
        urls = image_urls.get(category, image_urls["Dress"])
        url_index = (product_id - 1) % len(urls)
        image_url = urls[url_index]
        
        # Download gambar
        response = requests.get(image_url, timeout=10)
        if response.status_code == 200:
            # Generate filename
            safe_name = product_name.lower().replace(' ', '_')
            filename = f"{safe_name}_{product_id}.jpg"
            filepath = os.path.join('images', 'products', filename)
            
            # Save image
            with open(filepath, 'wb') as f:
                f.write(response.content)
            
            print(f"📷 Gambar berhasil di-download: {filename}")
            return filepath
        else:
            print(f"❌ Gagal download gambar: {image_url}")
            return None
            
    except Exception as e:
        print(f"❌ Error generating sample image: {e}")
        return None

if __name__ == "__main__":
    reset_database()