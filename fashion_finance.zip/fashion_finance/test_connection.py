# test_connection.py
import mysql.connector
from mysql.connector import Error

def test_connection():
    try:
        # Konfigurasi koneksi
        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',  # Sesuaikan dengan password MySQL Anda
            database='fashion_finance'  # Ganti dengan nama database Anda
        )
        
        if connection.is_connected():
            print("✅ BERHASIL TERHUBUNG KE DATABASE!")
            
            # Dapatkan info server
            db_info = connection.get_server_info()
            print(f"✅ Versi MySQL Server: {db_info}")
            
            # Eksekusi query sederhana
            cursor = connection.cursor()
            cursor.execute("SELECT DATABASE()")
            database_name = cursor.fetchone()
            print(f"✅ Database yang digunakan: {database_name[0]}")
            
            # Cek tabel yang ada
            cursor.execute("SHOW TABLES")
            tables = cursor.fetchall()
            print(f"✅ Jumlah tabel: {len(tables)}")
            
            if tables:
                print("📊 Daftar tabel:")
                for table in tables:
                    print(f"   - {table[0]}")
            
            cursor.close()
            connection.close()
            print("✅ Koneksi ditutup dengan aman")
            return True
            
    except Error as e:
        print(f"❌ GAGAL TERHUBUNG: {e}")
        return False

if __name__ == "__main__":
    test_connection()