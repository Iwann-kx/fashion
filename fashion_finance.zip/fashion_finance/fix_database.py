# fix_database.py
import sqlite3
import os

def fix_database():
    print("🔧 Memperbaiki struktur database...")
    
    # Backup database lama
    if os.path.exists('fashion_finance.db'):
        os.rename('fashion_finance.db', 'fashion_finance_backup.db')
        print("✅ Database lama di-backup")
    
    # Import database baru dari reset_database
    from reset_database import reset_database
    reset_database()
    
    print("🎉 Database berhasil diperbaiki!")

if __name__ == "__main__":
    fix_database()