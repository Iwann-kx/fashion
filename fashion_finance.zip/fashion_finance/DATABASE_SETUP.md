# Database Setup Guide

## Quick Fix for Connection Error

If you're getting `Access denied for user 'root'@'localhost'`, you need to configure your MySQL password.

### Option 1: Set Password in Config File

Edit `app/config/database.py` and set your MySQL password:

```python
PASSWORD = os.getenv('DB_PASSWORD', 'your_mysql_password_here')
```

### Option 2: Use Environment Variable

Set the environment variable before running:

**Windows (PowerShell):**
```powershell
$env:DB_PASSWORD="your_mysql_password"
python main.py
```

**Windows (CMD):**
```cmd
set DB_PASSWORD=your_mysql_password
python main.py
```

**Linux/Mac:**
```bash
export DB_PASSWORD="your_mysql_password"
python main.py
```

### Option 3: If MySQL Has No Password

If your MySQL root user truly has no password, make sure MySQL allows passwordless connections:

1. Check MySQL configuration
2. Or set an empty password explicitly in the config

## Create Database

Make sure the database exists:

```sql
CREATE DATABASE IF NOT EXISTS fashion_finance;
```

## Test Connection

You can test the connection with:

```python
python -c "from app.models.database import db; print('Connected!' if db.test_connection() else 'Failed')"
```

## Common Issues

1. **MySQL not running**: Start MySQL service (XAMPP or standalone)
2. **Wrong password**: Update password in `app/config/database.py`
3. **Database doesn't exist**: Create it with SQL command above
4. **Port mismatch**: Default is 3306, change in config if different

