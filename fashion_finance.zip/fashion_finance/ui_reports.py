from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QFrame, QGridLayout, QScrollArea, QMessageBox)
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QFont
from database import db

class ReportsWindow(QWidget):
    back_clicked = pyqtSignal()
    inventory_clicked = pyqtSignal()
    sales_clicked = pyqtSignal()
    expenses_clicked = pyqtSignal()
    dashboard_clicked = pyqtSignal()
    settings_clicked = pyqtSignal()
    logout_clicked = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.user_role = "kasir"  # Default role
        self.init_ui()
        
    def init_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Header - SEPERTI DASHBOARD
        header = self.create_header()
        
        # Content dengan scroll area - SEPERTI DASHBOARD
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setStyleSheet("""
            QScrollArea { 
                border: none; 
                background-color: #f8f9fa;
            }
            QScrollBar:vertical {
                background-color: #e0e0e0;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background-color: #bdc3c7;
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #95a5a6;
            }
        """)
        
        # Content widget utama - SEPERTI DASHBOARD
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(20)
        
        # Page title - SEPERTI DASHBOARD
        page_title = QLabel("Laporan")
        page_title.setFont(QFont("Arial", 24, QFont.Bold))
        page_title.setStyleSheet("color: #2c3e50; margin-bottom: 5px;")
        
        subtitle = QLabel("Analisis kinerja bisnis dan laporan keuangan")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7f8c8d;")
        
        content_layout.addWidget(page_title)
        content_layout.addWidget(subtitle)
        
        # Report cards section - SEPERTI DASHBOARD STATS
        reports_layout = QHBoxLayout()
        reports_layout.setSpacing(20)

        reports_data = [
            ("Laporan Laba Rugi", "Rp 7.500.000", "+12% dari bulan lalu", "#27ae60", "📊"),
            ("Laporan Penjualan", "245 transaksi", "+8% dari bulan lalu", "#3498db", "💳"), 
            ("Laporan Inventori", "45 produk", "+5 produk baru", "#f39c12", "📦"),
            ("Laporan Pengeluaran", "Rp 8.250.000", "+5% dari bulan lalu", "#e74c3c", "📋")
        ]

        for title, value, change, color, icon in reports_data:
            report_card = self.create_report_card(title, value, change, color, icon)
            reports_layout.addWidget(report_card)

        reports_layout.addStretch()
        content_layout.addLayout(reports_layout)
        
        # Bottom sections - SEPERTI DASHBOARD
        bottom_layout = QHBoxLayout()
        bottom_layout.setSpacing(20)
        
        # Monthly performance - SEPERTI DASHBOARD
        performance_frame = QFrame()
        performance_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
                border: 1px solid #e0e0e0;
            }
        """)
        performance_frame.setMinimumWidth(500)
        performance_frame.setMinimumHeight(400)
        
        performance_layout = QVBoxLayout(performance_frame)
        performance_layout.setSpacing(15)
        
        performance_title = QLabel("📈 Performa Bulanan")
        performance_title.setFont(QFont("Arial", 18, QFont.Bold))
        performance_title.setStyleSheet("color: #2c3e50; margin-bottom: 10px;")
        
        self.performance_content = QVBoxLayout()
        self.performance_content.setSpacing(12)
        
        performance_layout.addWidget(performance_title)
        performance_layout.addLayout(self.performance_content)
        performance_layout.addStretch()
        
        # Sales trend - SEPERTI DASHBOARD
        trend_frame = QFrame()
        trend_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
                border: 1px solid #e0e0e0;
            }
        """)
        trend_frame.setMinimumWidth(1000)
        trend_frame.setMinimumHeight(1250)
        
        trend_layout = QVBoxLayout(trend_frame)
        trend_layout.setSpacing(15)
        
        trend_title = QLabel("📊 Tren Penjualan")
        trend_title.setFont(QFont("Arial", 18, QFont.Bold))
        trend_title.setStyleSheet("color: #2c3e50; margin-bottom: 10px;")
        
        self.trend_content = QVBoxLayout()
        self.trend_content.setSpacing(12)
        
        trend_layout.addWidget(trend_title)
        trend_layout.addLayout(self.trend_content)
        trend_layout.addStretch()
        
        bottom_layout.addWidget(performance_frame)
        bottom_layout.addWidget(trend_frame)
        
        # Add all to content layout
        content_layout.addSpacing(20)
        content_layout.addLayout(bottom_layout)
        content_layout.addStretch()
        
        # Set content widget to scroll area
        scroll_area.setWidget(content_widget)
        
        # Add to main layout
        main_layout.addWidget(header)
        main_layout.addWidget(scroll_area, 1)
        
        self.setLayout(main_layout)
        self.setStyleSheet("background-color: #f8f9fa;")
        self.load_data()

    def create_report_card(self, title, value, change, color, icon):
        """Membuat report card seperti stat card di dashboard"""
        report_frame = QFrame()
        report_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 25px;
                border: 1px solid #e0e0e0;
            }
        """)
        report_frame.setMinimumHeight(350)
        report_frame.setMinimumWidth(400)
        
        report_layout = QVBoxLayout(report_frame)
        report_layout.setSpacing(8)
        
        # Header dengan icon
        header_layout = QHBoxLayout()
        icon_label = QLabel(icon)
        icon_label.setFont(QFont("Arial", 16))
        icon_label.setStyleSheet("color: %s;" % color)
        
        report_title = QLabel(title)
        report_title.setFont(QFont("Arial", 12))
        report_title.setStyleSheet("color: #7f8c8d;")
        
        header_layout.addWidget(icon_label)
        header_layout.addWidget(report_title)
        header_layout.addStretch()
        
        # Value
        value_label = QLabel(value)
        value_label.setFont(QFont("Arial", 18, QFont.Bold))
        value_label.setStyleSheet("color: %s; margin-top: 5px;" % color)
        
        # Change
        change_label = QLabel(change)
        change_label.setFont(QFont("Arial", 11))
        change_label.setStyleSheet("color: #7f8c8d; font-weight: bold;")
        
        report_layout.addLayout(header_layout)
        report_layout.addWidget(value_label)
        report_layout.addWidget(change_label)
        report_layout.addStretch()
        
        return report_frame
    
    def create_header(self):
        header = QFrame()
        header.setFixedHeight(70)
        header.setStyleSheet("""
            QFrame {
                background-color: #2c3e50;
                color: white;
                border-bottom: 3px solid #3498db;
            }
        """)
        
        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(30, 15, 30, 15)
        
        title = QLabel("🏪 Fashion Finance - Sistem Manajemen Laporan")
        title.setFont(QFont("Arial", 18, QFont.Bold))
        title.setStyleSheet("color: white;")
        
        nav_layout = QHBoxLayout()
        nav_layout.setSpacing(8)
        
        # Navigation buttons - SEPERTI DASHBOARD
        dashboard_btn = QPushButton("📊 Dashboard")
        inventory_btn = QPushButton("📦 Inventori")
        sales_btn = QPushButton("💳 Penjualan")
        expenses_btn = QPushButton("📋 Pengeluaran")
        reports_btn = QPushButton("📈 Laporan")
        settings_btn = QPushButton("⚙️ Pengaturan")
        logout_btn = QPushButton("🚪 Logout")
        
        menu_style = """
            QPushButton {
                color: white;
                border: 2px solid transparent;
                padding: 10px 16px;
                background: rgba(255,255,255,0.1);
                font-size: 12px;
                font-weight: bold;
                border-radius: 8px;
                min-height: 25px;
            }
            QPushButton:hover {
                background-color: #34495e;
                border: 2px solid #5a6c7d;
            }
            QPushButton:disabled {
                background-color: #1abc9c;
                color: white;
                border: 2px solid #16a085;
                font-weight: bold;
            }
        """
        
        for btn in [dashboard_btn, inventory_btn, sales_btn, expenses_btn, reports_btn, settings_btn, logout_btn]:
            btn.setStyleSheet(menu_style)
            btn.setCursor(Qt.PointingHandCursor)
        
        reports_btn.setEnabled(False)
        dashboard_btn.clicked.connect(self.dashboard_clicked.emit)
        inventory_btn.clicked.connect(self.inventory_clicked.emit)
        sales_btn.clicked.connect(self.sales_clicked.emit)
        expenses_btn.clicked.connect(self.expenses_clicked.emit)
        settings_btn.clicked.connect(self.settings_clicked.emit)
        logout_btn.clicked.connect(self.logout_clicked.emit)
        
        # Apply role-based restrictions
        self.apply_role_restrictions(inventory_btn, reports_btn, settings_btn)
        
        nav_layout.addWidget(dashboard_btn)
        nav_layout.addWidget(inventory_btn)
        nav_layout.addWidget(sales_btn)
        nav_layout.addWidget(expenses_btn)
        nav_layout.addWidget(reports_btn)
        nav_layout.addWidget(settings_btn)
        nav_layout.addStretch()
        nav_layout.addWidget(logout_btn)
        
        header_layout.addWidget(title)
        header_layout.addStretch()
        header_layout.addLayout(nav_layout)
        header.setLayout(header_layout)
        
        return header
    
    def set_user_role(self, role):
        """Set user role and update UI accordingly"""
        self.user_role = role
        self.update_ui_for_role()
    
    def apply_role_restrictions(self, inventory_btn, reports_btn, settings_btn):
        """Apply restrictions based on user role"""
        if self.user_role == "kasir":
            inventory_btn.setEnabled(False)
            inventory_btn.setToolTip("Akses terbatas untuk kasir")
            reports_btn.setEnabled(False)
            reports_btn.setToolTip("Akses terbatas untuk kasir")
            settings_btn.setEnabled(False)
            settings_btn.setToolTip("Akses terbatas untuk kasir")
    
    def update_ui_for_role(self):
        """Update UI elements based on user role"""
        pass
    
    def load_data(self):
        # Update performance data
        self.clear_layout(self.performance_content)
        performance_data = [
            ("Total Penjualan", "Rp 15.750.000", "+8%"),
            ("Total Pengeluaran", "Rp 8.250.000", "+5%"),
            ("Keuntungan Bersih", "Rp 7.500.000", "+12%"),
            ("Margin Keuntungan", "47.6%", "+2.1%"),
            ("Rata-rata Transaksi", "Rp 320.000", "+5.2%")
        ]
        
        for title, value, change in performance_data:
            perf_frame = QFrame()
            perf_frame.setStyleSheet("""
                QFrame { 
                    background-color: #f8f9fa; 
                    border-radius: 10px; 
                    padding: 15px; 
                    border: 1px solid #e9ecef;
                }
                QFrame:hover {
                    background-color: #e9ecef;
                }
            """)
            perf_layout = QHBoxLayout()
            perf_layout.setSpacing(15)
            
            # Text content
            text_layout = QVBoxLayout()
            text_layout.setSpacing(4)
            
            title_label = QLabel(title)
            title_label.setFont(QFont("Arial", 12, QFont.Bold))
            title_label.setStyleSheet("color: #2c3e50;")
            
            value_label = QLabel(value)
            value_label.setFont(QFont("Arial", 14, QFont.Bold))
            value_label.setStyleSheet("color: #27ae60;")
            
            text_layout.addWidget(title_label)
            text_layout.addWidget(value_label)
            
            # Change indicator
            change_label = QLabel(change)
            change_label.setFont(QFont("Arial", 11, QFont.Bold))
            change_label.setStyleSheet("""
                color: white; 
                background-color: #27ae60; 
                padding: 4px 8px; 
                border-radius: 4px;
            """)
            change_label.setAlignment(Qt.AlignCenter)
            
            perf_layout.addLayout(text_layout)
            perf_layout.addStretch()
            perf_layout.addWidget(change_label)
            perf_frame.setLayout(perf_layout)
            
            self.performance_content.addWidget(perf_frame)
        
        # Update trend data
        self.clear_layout(self.trend_content)
        trend_data = [
            ("Minggu 1", "Rp 3.200.000", "📈"),
            ("Minggu 2", "Rp 3.850.000", "📈"), 
            ("Minggu 3", "Rp 4.100.000", "📈"),
            ("Minggu 4", "Rp 4.600.000", "📈")
        ]
        
        for week, amount, trend in trend_data:
            trend_frame = QFrame()
            trend_frame.setStyleSheet("""
                QFrame { 
                    background-color: #f8f9fa; 
                    border-radius: 10px; 
                    padding: 15px; 
                    border: 1px solid #e9ecef;
                }
                QFrame:hover {
                    background-color: #e9ecef;
                }
            """)
            trend_layout = QHBoxLayout()
            trend_layout.setSpacing(15)
            
            # Week info
            week_label = QLabel(week)
            week_label.setFont(QFont("Arial", 12, QFont.Bold))
            week_label.setStyleSheet("color: #2c3e50;")
            week_label.setFixedWidth(80)
            
            # Amount
            amount_label = QLabel(amount)
            amount_label.setFont(QFont("Arial", 12, QFont.Bold))
            amount_label.setStyleSheet("color: #2980b9;")
            
            # Trend icon
            trend_label = QLabel(trend)
            trend_label.setFont(QFont("Arial", 14))
            
            trend_layout.addWidget(week_label)
            trend_layout.addWidget(amount_label)
            trend_layout.addStretch()
            trend_layout.addWidget(trend_label)
            trend_frame.setLayout(trend_layout)
            
            self.trend_content.addWidget(trend_frame)
    
    def clear_layout(self, layout):
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
    
    def back_to_login(self):
        reply = QMessageBox.question(self, "Konfirmasi", 
                                   "Apakah Anda yakin ingin logout?",
                                   QMessageBox.Yes | QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            self.back_clicked.emit()