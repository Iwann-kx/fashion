# insert_sample_data.py
import mysql.connector
from mysql.connector import Error
from datetime import datetime, date

def insert_sample_data():
    """Memasukkan data sample ke database"""
    try:
        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='fashion_finance'
        )
        
        if connection.is_connected():
            cursor = connection.cursor()
            
            # Insert sample users
            users_data = [
                ('admin', 'admin123', 'admin', 'Administrator', 'admin@toko.com'),
                ('kasir1', 'kasir123', 'kasir', 'Kasir Pertama', 'kasir1@toko.com')
            ]
            
            cursor.executemany("""
                INSERT IGNORE INTO users (username, password, role, nama_lengkap, email) 
                VALUES (%s, %s, %s, %s, %s)
            """, users_data)
            
            # Insert sample categories
            categories_data = [
                ('Pakaian Pria', 'Pakaian untuk laki-laki'),
                ('Pakaian Wanita', 'Pakaian untuk perempuan'),
                ('Aksesoris', 'Aksesoris fashion'),
                ('Sepatu', 'Sepatu dan sandal')
            ]
            
            cursor.executemany("""
                INSERT IGNORE INTO categories (nama_kategori, deskripsi) 
                VALUES (%s, %s)
            """, categories_data)
            
            # Insert sample products
            products_data = [
                ('PRD001', 'Kemeja Lengan Panjang Pria', 1, 120000, 180000, 50, 'pcs', 'Kemeja katun lengan panjang'),
                ('PRD002', 'Blouse Wanita Modern', 2, 95000, 150000, 35, 'pcs', 'Blouse wanita bahan sutra'),
                ('PRD003', 'Celana Jeans Pria', 1, 150000, 220000, 25, 'pcs', 'Celana jeans slim fit'),
                ('PRD004', 'Tas Wanita Kulit', 3, 200000, 350000, 15, 'pcs', 'Tas kulit sintetis'),
                ('PRD005', 'Sepatu Sneakers Pria', 4, 180000, 280000, 30, 'pcs', 'Sepatu sneakers casual')
            ]
            
            cursor.executemany("""
                INSERT IGNORE INTO products (kode_produk, nama_produk, kategori_id, harga_beli, harga_jual, stok, satuan, deskripsi) 
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, products_data)
            
            # Insert sample sales
            sales_data = [
                ('TRX001', date(2024, 1, 15), 430000, 500000, 70000, 2),
                ('TRX002', date(2024, 1, 16), 780000, 800000, 20000, 2)
            ]
            
            cursor.executemany("""
                INSERT IGNORE INTO sales (kode_transaksi, tanggal_transaksi, total, bayar, kembalian, user_id) 
                VALUES (%s, %s, %s, %s, %s, %s)
            """, sales_data)
            
            # Insert sample sale items
            sale_items_data = [
                (1, 1, 2, 180000, 360000),
                (1, 4, 1, 70000, 70000),
                (2, 2, 3, 150000, 450000),
                (2, 5, 1, 280000, 280000),
                (2, 3, 1, 50000, 50000)
            ]
            
            cursor.executemany("""
                INSERT IGNORE INTO sale_items (sale_id, product_id, quantity, harga_satuan, subtotal) 
                VALUES (%s, %s, %s, %s, %s)
            """, sale_items_data)
            
            # Insert sample expenses
            expenses_data = [
                ('Operasional', 'Biaya listrik bulanan', 350000, date(2024, 1, 5), 1),
                ('Gaji', 'Gaji karyawan', 2500000, date(2024, 1, 10), 1),
                ('Transportasi', 'Biaya pengiriman barang', 120000, date(2024, 1, 12), 1)
            ]
            
            cursor.executemany("""
                INSERT IGNORE INTO expenses (kategori, deskripsi, jumlah, tanggal, user_id) 
                VALUES (%s, %s, %s, %s, %s)
            """, expenses_data)
            
            connection.commit()
            print("✅ Data sample berhasil dimasukkan!")
            
    except Error as e:
        print(f"❌ Error memasukkan data sample: {e}")
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()