import mysql.connector
from app.config.database import DatabaseConfig
import hashlib

def reset_data():
    print("🔄 MEMULAI RESET DATA...")
    
    try:
        # Connect to database
        conn = mysql.connector.connect(**DatabaseConfig.get_connection_params())
        cursor = conn.cursor()
        
        # Disable foreign key checks to allow truncation
        cursor.execute("SET FOREIGN_KEY_CHECKS = 0")
        
        # List of tables to truncate
        tables = ['sales_details', 'sales', 'expenses', 'products', 'customers', 'users']
        
        for table in tables:
            print(f"🗑️  Mengosongkan tabel {table}...")
            cursor.execute(f"TRUNCATE TABLE {table}")
            
        # Re-enable foreign key checks
        cursor.execute("SET FOREIGN_KEY_CHECKS = 1")
        
        print("✅ Semua data berhasil dihapus.")
        
        # Insert default users
        print("👤 Membuat user default...")
        
        # Admin
        admin_pass = hashlib.sha256("admin123".encode()).hexdigest()
        # Kasir
        kasir_pass = hashlib.sha256("kasir123".encode()).hexdigest()
        
        users_sql = """
            INSERT INTO users (username, password, role, nama, email) 
            VALUES (%s, %s, %s, %s, %s)
        """
        
        users_data = [
            ('admin', admin_pass, 'admin', 'Administrator', 'admin@fashionfinance.com'),
            ('kasir', kasir_pass, 'kasir', 'Kasir Utama', 'kasir@fashionfinance.com')
        ]
        
        cursor.executemany(users_sql, users_data)
        
        conn.commit()
        cursor.close()
        conn.close()
        
        print("\n🎉 RESET SELESAI!")
        print("===========================================")
        print("Data telah dikembalikan ke pengaturan awal (0).")
        print("User Default:")
        print("1. Admin -> User: admin, Pass: admin123")
        print("2. Kasir -> User: kasir, Pass: kasir123")
        print("===========================================")
        
    except Exception as e:
        print(f"❌ TERJADI ERROR: {e}")

if __name__ == "__main__":
    # Ask for confirmation
    print("⚠️  PERINGATAN: Script ini akan MENGHAPUS SEMUA DATA (Produk, Penjualan, User, dll)!")
    response = input("Apakah Anda yakin ingin melanjutkan? (y/n): ")
    
    if response.lower() == 'y':
        reset_data()
    else:
        print("❌ Reset dibatalkan.")
