"""
Script to add auto-refresh functionality to all view files
"""
import re

files_to_update = [
    'c:/laragon/fashion_finance/app/views/ui_inventory.py',
    'c:/laragon/fashion_finance/app/views/ui_sales.py',
    'c:/laragon/fashion_finance/app/views/ui_expenses.py',
    'c:/laragon/fashion_finance/app/views/ui_reports.py'
]

for filepath in files_to_update:
    print(f"\n📝 Processing: {filepath}")
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Check if already has QTimer
        if 'QTimer' in content:
            print(f"   ✅ Already has QTimer - skipping")
            continue
        
        # 1. Add QTimer to imports
        content = re.sub(
            r'from PyQt5\.QtCore import ([^)]+)',
            r'from PyQt5.QtCore import \1, QTimer',
            content
        )
        
        # 2. Add refresh_timer to __init__
        content = re.sub(
            r'(def __init__\(self\):.*?)(self\.init_ui\(\))',
            r'\1self.refresh_timer = None  # Auto-refresh timer\n        \2',
            content,
            flags=re.DOTALL
        )
        
        # 3. Add timer setup after load_data() call
        # Find the last occurrence of self.load_data()
        pattern = r'(self\.load_data\(\))'
        matches = list(re.finditer(pattern, content))
        
        if matches:
            last_match = matches[-1]
            insert_pos = last_match.end()
            
            timer_code = """
        
        # Setup auto-refresh timer (5 seconds)
        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self.load_data)
        self.refresh_timer.start(5000)  # Refresh every 5 seconds"""
            
            content = content[:insert_pos] + timer_code + content[insert_pos:]
            
            # Write back
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            print(f"   ✅ Auto-refresh added successfully!")
        else:
            print(f"   ⚠️  Could not find load_data() call")
            
    except Exception as e:
        print(f"   ❌ Error: {e}")

print("\n🎉 Done!")
