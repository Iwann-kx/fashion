"""Card Components - Reusable card widgets for displaying information"""

from PyQt5.QtWidgets import QFrame, QVBoxLayout, QHBoxLayout, QLabel
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont


class StatCard(QFrame):
    """
    Reusable stat card component with icon, title, value, and change indicator.
    
    Args:
        title (str): Card title
        value (str): Main value to display
        change (str): Change indicator text
        color (str): Hex color code for styling
        icon (str): Emoji or icon to display
        parent: Parent widget
    """
    
    def __init__(self, title, value, change, color, icon, parent=None):
        super().__init__(parent)
        self.title = title
        self.value = value
        self.change = change
        self.color = color
        self.icon = icon
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 25px;
                border: 1px solid #e0e0e0;
            }
            QFrame:hover {
                border: 1px solid #bdc3c7;
            }
        """)
        self.setMinimumHeight(350)
        self.setMinimumWidth(400)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        
        # Header with icon
        header_layout = QHBoxLayout()
        icon_label = QLabel(self.icon)
        icon_label.setFont(QFont("Arial", 16))
        icon_label.setStyleSheet(f"color: {self.color};")
        
        title_label = QLabel(self.title)
        title_label.setFont(QFont("Arial", 12))
        title_label.setStyleSheet("color: #7f8c8d;")
        
        header_layout.addWidget(icon_label)
        header_layout.addWidget(title_label)
        header_layout.addStretch()
        
        # Value
        value_label = QLabel(self.value)
        value_label.setFont(QFont("Arial", 18, QFont.Bold))
        value_label.setStyleSheet(f"color: {self.color}; margin-top: 5px;")
        
        # Change indicator
        change_label = QLabel(self.change)
        change_label.setFont(QFont("Arial", 11))
        change_label.setStyleSheet("color: #7f8c8d; font-weight: bold;")
        
        layout.addLayout(header_layout)
        layout.addWidget(value_label)
        layout.addWidget(change_label)
        layout.addStretch()
    
    def update_value(self, value, change=None):
        """Update the card value and optionally the change indicator"""
        self.value = value
        if change:
            self.change = change
        self._init_ui()


class InfoCard(QFrame):
    """
    Generic information card with consistent styling.
    
    Args:
        parent: Parent widget
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
                border: 1px solid #e0e0e0;
            }
        """)
        self.setMinimumWidth(500)
        self.setMinimumHeight(400)
        
        # Create main layout
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setSpacing(15)
    
    def set_title(self, title, icon=""):
        """Set the card title with optional icon"""
        title_label = QLabel(f"{icon} {title}" if icon else title)
        title_label.setFont(QFont("Arial", 18, QFont.Bold))
        title_label.setStyleSheet("color: #2c3e50; margin-bottom: 10px;")
        self.main_layout.insertWidget(0, title_label)
    
    def add_content(self, widget):
        """Add content widget to the card"""
        self.main_layout.addWidget(widget)
    
    def add_layout(self, layout):
        """Add layout to the card"""
        self.main_layout.addLayout(layout)


class ItemCard(QFrame):
    """
    Card for displaying individual items in a list (e.g., recent sales, best sellers).
    
    Args:
        parent: Parent widget
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        self.setStyleSheet("""
            QFrame {
                background-color: #f8f9fa;
                border-radius: 10px;
                padding: 15px;
                border: 1px solid #e9ecef;
            }
            QFrame:hover {
                background-color: #e9ecef;
            }
        """)
        
        self.main_layout = QHBoxLayout(self)
        self.main_layout.setSpacing(15)
    
    def add_icon(self, icon, background_color="#27ae60"):
        """Add an icon with colored background"""
        icon_frame = QFrame()
        icon_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {background_color};
                border-radius: 8px;
                padding: 8px;
            }}
        """)
        icon_frame.setFixedSize(40, 40)
        icon_layout = QVBoxLayout(icon_frame)
        icon_label = QLabel(icon)
        icon_label.setFont(QFont("Arial", 14))
        icon_label.setAlignment(Qt.AlignCenter)
        icon_layout.addWidget(icon_label)
        self.main_layout.addWidget(icon_frame)
        return icon_frame
    
    def add_text_content(self, title, subtitle):
        """Add title and subtitle text"""
        text_layout = QVBoxLayout()
        text_layout.setSpacing(4)
        
        title_label = QLabel(title)
        title_label.setFont(QFont("Arial", 12, QFont.Bold))
        title_label.setStyleSheet("color: #2c3e50;")
        title_label.setWordWrap(True)
        
        subtitle_label = QLabel(subtitle)
        subtitle_label.setFont(QFont("Arial", 10))
        subtitle_label.setStyleSheet("color: #7f8c8d;")
        
        text_layout.addWidget(title_label)
        text_layout.addWidget(subtitle_label)
        
        self.main_layout.addLayout(text_layout)
        return text_layout
    
    def add_value(self, value, color="#27ae60"):
        """Add a value label (e.g., price, count)"""
        self.main_layout.addStretch()
        value_label = QLabel(value)
        value_label.setFont(QFont("Arial", 13, QFont.Bold))
        value_label.setStyleSheet(f"color: {color};")
        value_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.main_layout.addWidget(value_label)
        return value_label
