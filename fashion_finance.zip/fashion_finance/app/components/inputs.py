"""Input Components - Reusable styled input widgets"""

from PyQt5.QtWidgets import QLineEdit, QComboBox, QDateEdit, QSpinBox
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from datetime import datetime


class StyledLineEdit(QLineEdit):
    """
    Styled line edit with consistent appearance.
    
    Args:
        placeholder (str): Placeholder text
        parent: Parent widget
    """
    
    def __init__(self, placeholder="", parent=None):
        super().__init__(parent)
        if placeholder:
            self.setPlaceholderText(placeholder)
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        self.setStyleSheet("""
            QLineEdit {
                padding: 12px 15px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 14px;
                background-color: white;
            }
            QLineEdit:focus {
                border-color: #3498db;
            }
            QLineEdit:disabled {
                background-color: #f5f5f5;
                color: #95a5a6;
            }
        """)
        self.setFont(QFont("Arial", 11))
    
    def set_error(self, error=True):
        """Set error state styling"""
        if error:
            self.setStyleSheet("""
                QLineEdit {
                    padding: 12px 15px;
                    border: 2px solid #e74c3c;
                    border-radius: 8px;
                    font-size: 14px;
                    background-color: #ffe6e6;
                }
                QLineEdit:focus {
                    border-color: #c0392b;
                }
            """)
        else:
            self._init_ui()
    
    def set_success(self, success=True):
        """Set success state styling"""
        if success:
            self.setStyleSheet("""
                QLineEdit {
                    padding: 12px 15px;
                    border: 2px solid #27ae60;
                    border-radius: 8px;
                    font-size: 14px;
                    background-color: #e6ffe6;
                }
                QLineEdit:focus {
                    border-color: #229954;
                }
            """)
        else:
            self._init_ui()


class StyledComboBox(QComboBox):
    """
    Styled combo box with consistent appearance.
    
    Args:
        items (list): List of items to add
        parent: Parent widget
    """
    
    def __init__(self, items=None, parent=None):
        super().__init__(parent)
        if items:
            self.addItems(items)
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        self.setStyleSheet("""
            QComboBox {
                padding: 12px 15px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 14px;
                background-color: white;
            }
            QComboBox:focus {
                border-color: #3498db;
            }
            QComboBox::drop-down {
                border: none;
                padding-right: 10px;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 5px solid #7f8c8d;
                margin-right: 5px;
            }
            QComboBox QAbstractItemView {
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                background-color: white;
                selection-background-color: #3498db;
                selection-color: white;
                padding: 5px;
            }
        """)
        self.setFont(QFont("Arial", 11))


class StyledDateEdit(QDateEdit):
    """
    Styled date edit with consistent appearance.
    
    Args:
        parent: Parent widget
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setDate(datetime.now().date())
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        self.setCalendarPopup(True)
        self.setStyleSheet("""
            QDateEdit {
                padding: 12px 15px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 14px;
                background-color: white;
            }
            QDateEdit:focus {
                border-color: #3498db;
            }
            QDateEdit::drop-down {
                border: none;
                padding-right: 10px;
            }
            QDateEdit::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 5px solid #7f8c8d;
                margin-right: 5px;
            }
        """)
        self.setFont(QFont("Arial", 11))


class StyledSpinBox(QSpinBox):
    """
    Styled spin box with consistent appearance.
    
    Args:
        min_val (int): Minimum value
        max_val (int): Maximum value
        parent: Parent widget
    """
    
    def __init__(self, min_val=0, max_val=999999, parent=None):
        super().__init__(parent)
        self.setMinimum(min_val)
        self.setMaximum(max_val)
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        self.setStyleSheet("""
            QSpinBox {
                padding: 12px 15px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 14px;
                background-color: white;
            }
            QSpinBox:focus {
                border-color: #3498db;
            }
            QSpinBox::up-button, QSpinBox::down-button {
                border: none;
                background-color: #f8f9fa;
                width: 20px;
            }
            QSpinBox::up-button:hover, QSpinBox::down-button:hover {
                background-color: #e9ecef;
            }
            QSpinBox::up-arrow {
                image: none;
                border-left: 4px solid transparent;
                border-right: 4px solid transparent;
                border-bottom: 4px solid #7f8c8d;
            }
            QSpinBox::down-arrow {
                image: none;
                border-left: 4px solid transparent;
                border-right: 4px solid transparent;
                border-top: 4px solid #7f8c8d;
            }
        """)
        self.setFont(QFont("Arial", 11))


class SearchInput(StyledLineEdit):
    """
    Specialized search input with search icon placeholder.
    
    Args:
        placeholder (str): Placeholder text
        parent: Parent widget
    """
    
    def __init__(self, placeholder="🔍 Cari...", parent=None):
        super().__init__(placeholder, parent)
        self.setFixedWidth(250)
