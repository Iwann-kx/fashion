"""Table Components - Reusable data table with action buttons"""

from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from .buttons import ActionButtonGroup


class DataTable(QTableWidget):
    """
    Reusable data table with consistent styling and action buttons.
    
    Args:
        columns (list): List of column headers
        parent: Parent widget
    """
    
    def __init__(self, columns, parent=None):
        super().__init__(parent)
        self.columns = columns
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        self.setColumnCount(len(self.columns))
        self.setHorizontalHeaderLabels(self.columns)
        
        # Apply consistent styling
        self.setStyleSheet("""
            QTableWidget {
                background-color: white;
                border: none;
                gridline-color: #e9ecef;
                font-size: 14px;
                border-radius: 8px;
                alternate-background-color: #f8f9fa;
            }
            QTableWidget::item {
                padding: 16px 12px;
                border-bottom: 1px solid #e9ecef;
                font-size: 13px;
            }
            QTableWidget::item:selected {
                background-color: #3498db;
                color: white;
            }
            QHeaderView::section {
                background-color: #2c3e50;
                color: white;
                padding: 16px 12px;
                border: none;
                border-bottom: 2px solid #e9ecef;
                font-weight: bold;
                font-size: 13px;
            }
        """)
        
        # Configure table properties
        self.verticalHeader().setDefaultSectionSize(65)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.verticalHeader().setVisible(False)
        self.setAlternatingRowColors(True)
        self.setMinimumHeight(400)
        self.setEditTriggers(QTableWidget.NoEditTriggers)
        self.setSelectionBehavior(QTableWidget.SelectRows)
        self.setSelectionMode(QTableWidget.SingleSelection)
    
    def add_row(self, data, action_callbacks=None):
        """
        Add a row to the table.
        
        Args:
            data (list): List of cell values (excluding action column)
            action_callbacks (dict): Optional dict with 'edit' and 'delete' callbacks
        
        Returns:
            int: Row index
        """
        row = self.rowCount()
        self.insertRow(row)
        
        # Add data cells
        for col, value in enumerate(data):
            item = QTableWidgetItem(str(value))
            self.setItem(row, col, item)
        
        # Add action buttons if callbacks provided
        if action_callbacks and len(data) < len(self.columns):
            action_group = ActionButtonGroup()
            if 'edit' in action_callbacks:
                action_group.connect_edit(action_callbacks['edit'])
            if 'delete' in action_callbacks:
                action_group.connect_delete(action_callbacks['delete'])
            self.setCellWidget(row, len(self.columns) - 1, action_group)
        
        return row
    
    def clear_data(self):
        """Clear all rows from the table"""
        self.setRowCount(0)
    
    def set_column_widths(self, widths):
        """
        Set specific column widths.
        
        Args:
            widths (dict): Dictionary of column_index: width
        """
        for col, width in widths.items():
            self.horizontalHeader().setSectionResizeMode(col, QHeaderView.Fixed)
            self.setColumnWidth(col, width)
    
    def style_cell(self, row, col, color=None, bold=False):
        """
        Apply custom styling to a specific cell.
        
        Args:
            row (int): Row index
            col (int): Column index
            color: QColor or Qt color constant
            bold (bool): Whether to make text bold
        """
        item = self.item(row, col)
        if item:
            if color:
                item.setForeground(color)
            if bold:
                font = item.font()
                font.setBold(True)
                item.setFont(font)
