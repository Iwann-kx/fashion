"""Dialog Components - Reusable dialog windows with consistent styling"""

from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                             QDialogButtonBox, QMessageBox, QFormLayout)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from .inputs import StyledLineEdit, StyledComboBox, StyledDateEdit, StyledSpinBox


class BaseDialog(QDialog):
    """
    Base dialog with consistent styling and standard buttons.
    
    Args:
        title (str): Dialog title
        width (int): Dialog width
        height (int): Dialog height
        parent: Parent widget
    """
    
    def __init__(self, title="Dialog", width=600, height=400, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setFixedSize(width, height)
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setSpacing(20)
        self.main_layout.setContentsMargins(30, 30, 30, 30)
        
        # Content layout (to be filled by subclasses)
        self.content_layout = QVBoxLayout()
        self.content_layout.setSpacing(15)
        
        self.main_layout.addLayout(self.content_layout)
        self.main_layout.addStretch()
    
    def add_title(self, title):
        """Add a title to the dialog"""
        title_label = QLabel(title)
        title_label.setFont(QFont("Arial", 16, QFont.Bold))
        title_label.setStyleSheet("color: #2c3e50; margin-bottom: 10px;")
        self.content_layout.insertWidget(0, title_label)
    
    def add_buttons(self, ok_text="OK", cancel_text="Batal"):
        """Add standard OK/Cancel buttons"""
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.setStyleSheet("""
            QPushButton {
                padding: 10px 20px;
                border: none;
                border-radius: 6px;
                font-weight: bold;
                min-width: 80px;
            }
            QPushButton[text="OK"] {
                background-color: #27ae60;
                color: white;
            }
            QPushButton[text="OK"]:hover {
                background-color: #2ecc71;
            }
            QPushButton[text="Batal"] {
                background-color: #95a5a6;
                color: white;
            }
            QPushButton[text="Batal"]:hover {
                background-color: #7f8c8d;
            }
        """)
        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)
        
        self.main_layout.addWidget(button_box)
        return button_box
    
    def validate_and_accept(self):
        """Override this method to add validation logic"""
        self.accept()
    
    def show_error(self, message):
        """Show error message"""
        QMessageBox.warning(self, "Error", message)
    
    def show_success(self, message):
        """Show success message"""
        QMessageBox.information(self, "Sukses", message)


class FormDialog(BaseDialog):
    """
    Dialog with form fields generated from configuration.
    
    Args:
        title (str): Dialog title
        fields_config (list): List of field configurations
        data (dict): Optional data to pre-fill fields
        parent: Parent widget
    
    Field config format:
        {
            'name': 'field_name',
            'label': 'Field Label',
            'type': 'text'|'combo'|'date'|'number',
            'items': [...],  # For combo boxes
            'placeholder': 'Placeholder text',  # For text fields
            'required': True|False
        }
    """
    
    def __init__(self, title, fields_config, data=None, parent=None):
        self.fields_config = fields_config
        self.data = data or {}
        self.fields = {}
        super().__init__(title, 800, 800, parent)
        self._build_form()
    
    def _build_form(self):
        """Build form from configuration"""
        form_layout = QFormLayout()
        form_layout.setSpacing(15)
        form_layout.setLabelAlignment(Qt.AlignRight)
        
        for field_config in self.fields_config:
            name = field_config['name']
            label = field_config.get('label', name)
            field_type = field_config.get('type', 'text')
            required = field_config.get('required', False)
            
            # Create label
            label_text = f"{label}{'*' if required else ''}"
            label_widget = QLabel(label_text)
            label_widget.setFont(QFont("Arial", 11, QFont.Bold))
            label_widget.setStyleSheet("color: #2c3e50;")
            
            # Create input widget based on type
            if field_type == 'text':
                widget = StyledLineEdit(field_config.get('placeholder', ''))
                if name in self.data:
                    widget.setText(str(self.data[name]))
            
            elif field_type == 'combo':
                items = field_config.get('items', [])
                widget = StyledComboBox(items)
                if name in self.data:
                    widget.setCurrentText(str(self.data[name]))
            
            elif field_type == 'date':
                widget = StyledDateEdit()
                if name in self.data:
                    # Assuming data[name] is a date string or date object
                    pass  # Set date if needed
            
            elif field_type == 'number':
                min_val = field_config.get('min', 0)
                max_val = field_config.get('max', 999999)
                widget = StyledSpinBox(min_val, max_val)
                if name in self.data:
                    widget.setValue(int(self.data[name]))
            
            else:
                widget = StyledLineEdit()
            
            self.fields[name] = widget
            form_layout.addRow(label_widget, widget)
        
        self.content_layout.addLayout(form_layout)
        self.add_buttons()
    
    def validate_and_accept(self):
        """Validate required fields"""
        for field_config in self.fields_config:
            if field_config.get('required', False):
                name = field_config['name']
                widget = self.fields[name]
                
                # Check if field is empty
                if isinstance(widget, StyledLineEdit):
                    if not widget.text().strip():
                        self.show_error(f"{field_config.get('label', name)} harus diisi!")
                        widget.set_error(True)
                        return
                elif isinstance(widget, StyledComboBox):
                    if widget.currentIndex() < 0:
                        self.show_error(f"{field_config.get('label', name)} harus dipilih!")
                        return
        
        self.accept()
    
    def get_data(self):
        """Get form data as dictionary"""
        data = {}
        for name, widget in self.fields.items():
            if isinstance(widget, StyledLineEdit):
                data[name] = widget.text()
            elif isinstance(widget, StyledComboBox):
                data[name] = widget.currentText()
            elif isinstance(widget, StyledDateEdit):
                data[name] = widget.date().toString('yyyy-MM-dd')
            elif isinstance(widget, StyledSpinBox):
                data[name] = widget.value()
        return data
