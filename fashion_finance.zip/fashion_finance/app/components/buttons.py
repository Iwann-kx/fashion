"""Button Components - Reusable button widgets with consistent styling"""

from PyQt5.QtWidgets import QPushButton, QHBoxLayout, QWidget
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QCursor


class PrimaryButton(QPushButton):
    """
    Primary action button with green styling.
    
    Args:
        text (str): Button text
        icon (str): Optional emoji/icon
        parent: Parent widget
    """
    
    def __init__(self, text, icon="", parent=None):
        display_text = f"{icon} {text}" if icon else text
        super().__init__(display_text, parent)
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        self.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                color: white;
                padding: 12px 20px;
                border: none;
                border-radius: 8px;
                font-size: 14px;
                font-weight: bold;
                min-width: 100px;
            }
            QPushButton:hover {
                background-color: #2ecc71;
            }
            QPushButton:pressed {
                background-color: #229954;
            }
            QPushButton:disabled {
                background-color: #95a5a6;
            }
        """)
        self.setCursor(QCursor(Qt.PointingHandCursor))


class SecondaryButton(QPushButton):
    """
    Secondary action button with blue styling.
    
    Args:
        text (str): Button text
        icon (str): Optional emoji/icon
        parent: Parent widget
    """
    
    def __init__(self, text, icon="", parent=None):
        display_text = f"{icon} {text}" if icon else text
        super().__init__(display_text, parent)
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        self.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                padding: 12px 20px;
                border: none;
                border-radius: 8px;
                font-size: 14px;
                font-weight: bold;
                min-width: 100px;
            }
            QPushButton:hover {
                background-color: #5dade2;
            }
            QPushButton:pressed {
                background-color: #2980b9;
            }
            QPushButton:disabled {
                background-color: #95a5a6;
            }
        """)
        self.setCursor(QCursor(Qt.PointingHandCursor))


class DangerButton(QPushButton):
    """
    Danger/delete action button with red styling.
    
    Args:
        text (str): Button text
        icon (str): Optional emoji/icon
        parent: Parent widget
    """
    
    def __init__(self, text, icon="", parent=None):
        display_text = f"{icon} {text}" if icon else text
        super().__init__(display_text, parent)
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        self.setStyleSheet("""
            QPushButton {
                background-color: #e74c3c;
                color: white;
                padding: 12px 20px;
                border: none;
                border-radius: 8px;
                font-size: 14px;
                font-weight: bold;
                min-width: 100px;
            }
            QPushButton:hover {
                background-color: #ec7063;
            }
            QPushButton:pressed {
                background-color: #c0392b;
            }
            QPushButton:disabled {
                background-color: #95a5a6;
            }
        """)
        self.setCursor(QCursor(Qt.PointingHandCursor))


class ActionButton(QPushButton):
    """
    Small action button for table rows (edit, delete, view).
    
    Args:
        text (str): Button text
        button_type (str): 'edit', 'delete', or 'view'
        parent: Parent widget
    """
    
    def __init__(self, text, button_type='edit', parent=None):
        super().__init__(text, parent)
        self.button_type = button_type
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        colors = {
            'edit': ('#3498db', '#2980b9'),
            'delete': ('#e74c3c', '#c0392b'),
            'view': ('#9b59b6', '#8e44ad')
        }
        
        bg_color, hover_color = colors.get(self.button_type, colors['edit'])
        
        self.setStyleSheet(f"""
            QPushButton {{
                background-color: {bg_color};
                color: white;
                border: none;
                padding: 8px 12px;
                border-radius: 6px;
                font-size: 12px;
                font-weight: bold;
                min-width: 60px;
            }}
            QPushButton:hover {{
                background-color: {hover_color};
            }}
        """)
        self.setCursor(QCursor(Qt.PointingHandCursor))


class ActionButtonGroup(QWidget):
    """
    Pre-configured group of action buttons (edit + delete).
    
    Args:
        parent: Parent widget
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.edit_btn = None
        self.delete_btn = None
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 5, 8, 5)
        layout.setSpacing(8)
        
        self.edit_btn = ActionButton("✏️ Edit", 'edit')
        self.delete_btn = ActionButton("🗑️ Hapus", 'delete')
        
        layout.addWidget(self.edit_btn)
        layout.addWidget(self.delete_btn)
        layout.addStretch()
    
    def connect_edit(self, callback):
        """Connect edit button to callback"""
        self.edit_btn.clicked.connect(callback)
    
    def connect_delete(self, callback):
        """Connect delete button to callback"""
        self.delete_btn.clicked.connect(callback)


class NavButton(QPushButton):
    """
    Navigation button for header menu.
    
    Args:
        text (str): Button text
        parent: Parent widget
    """
    
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self._init_ui()
    
    def _init_ui(self):
        """Initialize the UI"""
        self.setStyleSheet("""
            QPushButton {
                color: white;
                border: none;
                padding: 12px 18px;
                background: transparent;
                font-size: 14px;
                font-weight: bold;
                border-radius: 6px;
                min-height: 25px;
            }
            QPushButton:hover {
                background-color: #34495e;
                border: 1px solid #5a6c7d;
            }
            QPushButton:disabled {
                background-color: #1abc9c;
                color: white;
                border: 1px solid #16a085;
            }
        """)
        self.setCursor(QCursor(Qt.PointingHandCursor))
