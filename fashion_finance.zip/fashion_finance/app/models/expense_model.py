"""Expense model"""
from app.models.database import db

class ExpenseModel:
    """Expense model"""
    
    @staticmethod
    def get_all(limit=None):
        """Get all expenses"""
        query = "SELECT * FROM expenses ORDER BY tanggal DESC"
        if limit:
            query += f" LIMIT {limit}"
        return db.execute_query(query, fetch_all=True)
    
    @staticmethod
    def get_by_id(expense_id):
        """Get expense by ID"""
        query = "SELECT * FROM expenses WHERE id = %s"
        return db.execute_query(query, (expense_id,), fetch_one=True)
    
    @staticmethod
    def create(tanggal, deskripsi, kategori, jumlah, status='Lunas'):
        """Create new expense"""
        query = """
            INSERT INTO expenses (tanggal, deskripsi, kategori, jumlah, status)
            VALUES (%s, %s, %s, %s, %s)
        """
        return db.execute_query(query, (tanggal, deskripsi, kategori, jumlah, status))
    
    @staticmethod
    def update(expense_id, **kwargs):
        """Update expense"""
        allowed_fields = ['tanggal', 'deskripsi', 'kategori', 'jumlah', 'status']
        updates = []
        values = []
        
        for field, value in kwargs.items():
            if field in allowed_fields and value is not None:
                updates.append(f"{field} = %s")
                values.append(value)
        
        if not updates:
            return False
        
        values.append(expense_id)
        query = f"UPDATE expenses SET {', '.join(updates)} WHERE id = %s"
        db.execute_query(query, tuple(values))
        return True
    
    @staticmethod
    def delete(expense_id):
        """Delete expense"""
        query = "DELETE FROM expenses WHERE id = %s"
        db.execute_query(query, (expense_id,))
        return True
    
    @staticmethod
    def get_total():
        """Get total expenses"""
        query = "SELECT COALESCE(SUM(jumlah), 0) as total FROM expenses"
        result = db.execute_query(query, fetch_one=True)
        return result['total'] if result else 0
    
    @staticmethod
    def get_by_date_range(start_date, end_date):
        """Get expenses by date range"""
        query = """
            SELECT * FROM expenses
            WHERE tanggal BETWEEN %s AND %s
            ORDER BY tanggal DESC
        """
        return db.execute_query(query, (start_date, end_date), fetch_all=True)
    
    @staticmethod
    def get_monthly_total(year, month):
        """Get monthly total expenses"""
        query = """
            SELECT COALESCE(SUM(jumlah), 0) as total
            FROM expenses
            WHERE YEAR(tanggal) = %s AND MONTH(tanggal) = %s
        """
        result = db.execute_query(query, (year, month), fetch_one=True)
        return result['total'] if result else 0

