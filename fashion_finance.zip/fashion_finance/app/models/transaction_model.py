"""Transaction/Sales model"""
from app.models.database import db
from datetime import datetime
import uuid

class TransactionModel:
    """Transaction model for sales management"""
    
    @staticmethod
    def generate_transaction_code():
        """Generate unique transaction code"""
        return f"TRX-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"
    
    @staticmethod
    def create(user_id, customer_id=None, items=None, total=0, metode_pembayaran='Tunai'):
        """Create new transaction with details"""
        conn = db.get_connection()
        cursor = conn.cursor()
        
        try:
            # Generate transaction code
            kode_transaksi = TransactionModel.generate_transaction_code()
            
            # Insert transaction
            insert_sale_query = """
                INSERT INTO sales (kode_transaksi, user_id, customer_id, tanggal_transaksi, total, metode_pembayaran)
                VALUES (%s, %s, %s, %s, %s, %s)
            """
            cursor.execute(insert_sale_query, (
                kode_transaksi, user_id, customer_id, datetime.now(), total, metode_pembayaran
            ))
            sale_id = cursor.lastrowid
            
            # Insert transaction details and update stock
            if items:
                insert_detail_query = """
                    INSERT INTO sales_details (sale_id, product_id, quantity, harga_satuan, subtotal)
                    VALUES (%s, %s, %s, %s, %s)
                """
                update_stock_query = "UPDATE products SET stok = stok - %s WHERE id = %s"
                
                for item in items:
                    cursor.execute(insert_detail_query, (
                        sale_id, item['product_id'], item['quantity'], 
                        item['harga_satuan'], item['subtotal']
                    ))
                    cursor.execute(update_stock_query, (item['quantity'], item['product_id']))
            
            conn.commit()
            cursor.close()
            conn.close()
            return sale_id
        except Exception as e:
            conn.rollback()
            cursor.close()
            conn.close()
            raise e
    
    @staticmethod
    def get_all(limit=None):
        """Get all transactions"""
        query = """
            SELECT s.*, u.nama as user_nama, c.nama_pembeli as customer_nama
            FROM sales s
            LEFT JOIN users u ON s.user_id = u.id
            LEFT JOIN customers c ON s.customer_id = c.id
            ORDER BY s.tanggal_transaksi DESC
        """
        if limit:
            query += f" LIMIT {limit}"
        return db.execute_query(query, fetch_all=True)
    
    @staticmethod
    def get_by_id(sale_id):
        """Get transaction by ID"""
        query = """
            SELECT s.*, u.nama as user_nama, c.nama_pembeli as customer_nama
            FROM sales s
            LEFT JOIN users u ON s.user_id = u.id
            LEFT JOIN customers c ON s.customer_id = c.id
            WHERE s.id = %s
        """
        return db.execute_query(query, (sale_id,), fetch_one=True)
    
    @staticmethod
    def get_details(sale_id):
        """Get transaction details"""
        query = """
            SELECT sd.*, p.nama_produk, p.kode_produk
            FROM sales_details sd
            JOIN products p ON sd.product_id = p.id
            WHERE sd.sale_id = %s
        """
        return db.execute_query(query, (sale_id,), fetch_all=True)
    
    @staticmethod
    def get_today_sales():
        """Get today's sales statistics"""
        query = """
            SELECT 
                COUNT(*) as total_transactions,
                COALESCE(SUM(total), 0) as total_sales
            FROM sales
            WHERE DATE(tanggal_transaksi) = CURDATE() AND status = 'Selesai'
        """
        return db.execute_query(query, fetch_one=True)
    
    @staticmethod
    def get_by_date_range(start_date, end_date):
        """Get transactions by date range"""
        query = """
            SELECT s.*, u.nama as user_nama, c.nama_pembeli as customer_nama
            FROM sales s
            LEFT JOIN users u ON s.user_id = u.id
            LEFT JOIN customers c ON s.customer_id = c.id
            WHERE DATE(s.tanggal_transaksi) BETWEEN %s AND %s
            ORDER BY s.tanggal_transaksi DESC
        """
        return db.execute_query(query, (start_date, end_date), fetch_all=True)
    
    @staticmethod
    def update_status(sale_id, status):
        """Update transaction status"""
        query = "UPDATE sales SET status = %s WHERE id = %s"
        db.execute_query(query, (status, sale_id))
        return True

