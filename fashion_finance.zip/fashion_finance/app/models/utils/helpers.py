"""Helper utility functions"""
import os

def format_currency(amount):
    """Format amount as Indonesian Rupiah"""
    return f"Rp {amount:,.0f}".replace(',', '.')

def ensure_directory(path):
    """Ensure directory exists"""
    os.makedirs(path, exist_ok=True)

def get_image_path(relative_path):
    """Get absolute path for image"""
    if not relative_path:
        return None
    if os.path.isabs(relative_path):
        return relative_path
    return os.path.join(os.getcwd(), relative_path)

