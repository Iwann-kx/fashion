"""User model"""
import hashlib
from app.models.database import db
from datetime import datetime

class UserModel:
    """User model for authentication and user management"""
    
    @staticmethod
    def hash_password(password):
        """Hash password using SHA256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    @staticmethod
    def authenticate(username, password):
        """Authenticate user and return user data"""
        hashed_password = UserModel.hash_password(password)
        query = """
            SELECT id, username, email, nama, role, no_hp, alamat
            FROM users
            WHERE username = %s AND password = %s
        """
        result = db.execute_query(query, (username, hashed_password), fetch_one=True)
        return result
    
    @staticmethod
    def get_by_id(user_id):
        """Get user by ID"""
        query = """
            SELECT id, username, email, nama, role, no_hp, alamat, tanggal_bergabung
            FROM users
            WHERE id = %s
        """
        return db.execute_query(query, (user_id,), fetch_one=True)
    
    @staticmethod
    def get_all():
        """Get all users"""
        query = """
            SELECT id, username, email, nama, role, no_hp, alamat, tanggal_bergabung
            FROM users
            ORDER BY nama
        """
        return db.execute_query(query, fetch_all=True)
    
    @staticmethod
    def create(username, password, email, nama, role='kasir', no_hp=None, alamat=None):
        """Create new user"""
        hashed_password = UserModel.hash_password(password)
        query = """
            INSERT INTO users (username, password, email, nama, role, no_hp, alamat)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        return db.execute_query(query, (username, hashed_password, email, nama, role, no_hp, alamat))
    
    @staticmethod
    def update(user_id, **kwargs):
        """Update user information"""
        allowed_fields = ['username', 'email', 'nama', 'role', 'no_hp', 'alamat']
        updates = []
        values = []
        
        for field, value in kwargs.items():
            if field in allowed_fields and value is not None:
                if field == 'password':
                    value = UserModel.hash_password(value)
                updates.append(f"{field} = %s")
                values.append(value)
        
        if not updates:
            return False
        
        values.append(user_id)
        query = f"UPDATE users SET {', '.join(updates)} WHERE id = %s"
        db.execute_query(query, tuple(values))
        return True
    
    @staticmethod
    def delete(user_id):
        """Delete user"""
        query = "DELETE FROM users WHERE id = %s"
        db.execute_query(query, (user_id,))
        return True

