"""Report model"""
from app.models.database import db
from datetime import datetime

class ReportModel:
    """Report model for analytics and reporting"""
    
    @staticmethod
    def get_dashboard_stats():
        """Get dashboard statistics"""
        query = """
            SELECT 
                (SELECT COUNT(*) FROM products WHERE status = 'Aktif') as total_products,
                (SELECT COALESCE(SUM(stok), 0) FROM products WHERE status = 'Aktif') as total_stock,
                (SELECT COUNT(*) FROM sales WHERE status = 'Selesai') as total_transactions,
                (SELECT COALESCE(SUM(total), 0) FROM sales WHERE status = 'Selesai') as total_sales
        """
        return db.execute_query(query, fetch_one=True)
    
    @staticmethod
    def get_recent_sales(limit=5):
        """Get recent sales"""
        query = """
            SELECT s.*, u.nama as user_nama, c.nama_pembeli as customer_nama
            FROM sales s
            LEFT JOIN users u ON s.user_id = u.id
            LEFT JOIN customers c ON s.customer_id = c.id
            WHERE s.status = 'Selesai'
            ORDER BY s.tanggal_transaksi DESC
            LIMIT %s
        """
        return db.execute_query(query, (limit,), fetch_all=True)
    
    @staticmethod
    def get_best_selling_products(limit=5):
        """Get best selling products"""
        query = """
            SELECT 
                p.nama_produk,
                p.kode_produk,
                SUM(sd.quantity) as total_terjual,
                SUM(sd.subtotal) as total_pendapatan
            FROM sales_details sd
            JOIN products p ON sd.product_id = p.id
            JOIN sales s ON sd.sale_id = s.id
            WHERE s.status = 'Selesai'
            GROUP BY p.id, p.nama_produk, p.kode_produk
            ORDER BY total_terjual DESC
            LIMIT %s
        """
        return db.execute_query(query, (limit,), fetch_all=True)
    
    @staticmethod
    def get_monthly_performance(year, month):
        """Get monthly performance"""
        query = """
            SELECT 
                (SELECT COALESCE(SUM(total), 0) FROM sales 
                 WHERE YEAR(tanggal_transaksi) = %s AND MONTH(tanggal_transaksi) = %s 
                 AND status = 'Selesai') as monthly_sales,
                (SELECT COALESCE(SUM(jumlah), 0) FROM expenses 
                 WHERE YEAR(tanggal) = %s AND MONTH(tanggal) = %s) as monthly_expenses
        """
        result = db.execute_query(query, (year, month, year, month), fetch_one=True)
        if result:
            monthly_sales = result['monthly_sales'] or 0
            monthly_expenses = result['monthly_expenses'] or 0
            monthly_profit = monthly_sales - monthly_expenses
            margin = (monthly_profit / monthly_sales * 100) if monthly_sales > 0 else 0
            
            return {
                'monthly_sales': monthly_sales,
                'monthly_expenses': monthly_expenses,
                'monthly_profit': monthly_profit,
                'margin': margin
            }
        return {
            'monthly_sales': 0,
            'monthly_expenses': 0,
            'monthly_profit': 0,
            'margin': 0
        }
    
    @staticmethod
    def get_sales_by_category():
        """Get sales grouped by category"""
        query = """
            SELECT 
                p.kategori,
                COUNT(DISTINCT s.id) as total_transactions,
                SUM(sd.quantity) as total_quantity,
                SUM(sd.subtotal) as total_revenue
            FROM sales_details sd
            JOIN products p ON sd.product_id = p.id
            JOIN sales s ON sd.sale_id = s.id
            WHERE s.status = 'Selesai'
            GROUP BY p.kategori
            ORDER BY total_revenue DESC
        """
        return db.execute_query(query, fetch_all=True)

