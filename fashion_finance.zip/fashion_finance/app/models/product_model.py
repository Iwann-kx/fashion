"""Product model"""
from app.models.database import db

class ProductModel:
    """Product model for inventory management"""
    
    @staticmethod
    def get_all(active_only=True):
        """Get all products"""
        if active_only:
            query = """
                SELECT p.*, u.nama as user_nama
                FROM products p
                LEFT JOIN users u ON p.user_id = u.id
                WHERE p.status = 'Aktif'
                ORDER BY p.nama_produk
            """
        else:
            query = """
                SELECT p.*, u.nama as user_nama
                FROM products p
                LEFT JOIN users u ON p.user_id = u.id
                ORDER BY p.nama_produk
            """
        return db.execute_query(query, fetch_all=True)
    
    @staticmethod
    def get_by_id(product_id):
        """Get product by ID"""
        query = """
            SELECT p.*, u.nama as user_nama
            FROM products p
            LEFT JOIN users u ON p.user_id = u.id
            WHERE p.id = %s
        """
        return db.execute_query(query, (product_id,), fetch_one=True)
    
    @staticmethod
    def get_by_code(kode_produk):
        """Get product by code"""
        query = "SELECT * FROM products WHERE kode_produk = %s"
        return db.execute_query(query, (kode_produk,), fetch_one=True)
    
    @staticmethod
    def create(kode_produk, nama_produk, kategori, harga_jual, stok, user_id=None, gambar=None):
        """Create new product"""
        query = """
            INSERT INTO products (kode_produk, nama_produk, kategori, harga_jual, stok, user_id, gambar)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        return db.execute_query(query, (kode_produk, nama_produk, kategori, harga_jual, stok, user_id, gambar))
    
    @staticmethod
    def update(product_id, **kwargs):
        """Update product"""
        allowed_fields = ['kode_produk', 'nama_produk', 'kategori', 'harga_jual', 'stok', 'gambar', 'status']
        updates = []
        values = []
        
        for field, value in kwargs.items():
            if field in allowed_fields and value is not None:
                updates.append(f"{field} = %s")
                values.append(value)
        
        if not updates:
            return False
        
        values.append(product_id)
        query = f"UPDATE products SET {', '.join(updates)} WHERE id = %s"
        db.execute_query(query, tuple(values))
        return True
    
    @staticmethod
    def update_stock(product_id, quantity_change):
        """Update product stock (positive to add, negative to subtract)"""
        query = "UPDATE products SET stok = stok + %s WHERE id = %s"
        db.execute_query(query, (quantity_change, product_id))
        return True
    
    @staticmethod
    def delete(product_id):
        """Soft delete product (set status to Nonaktif)"""
        query = "UPDATE products SET status = 'Nonaktif' WHERE id = %s"
        db.execute_query(query, (product_id,))
        return True
    
    @staticmethod
    def get_low_stock(threshold=10):
        """Get products with low stock"""
        query = """
            SELECT * FROM products
            WHERE stok <= %s AND status = 'Aktif'
            ORDER BY stok ASC
        """
        return db.execute_query(query, (threshold,), fetch_all=True)
    
    @staticmethod
    def search(search_term):
        """Search products by name or code"""
        query = """
            SELECT * FROM products
            WHERE (nama_produk LIKE %s OR kode_produk LIKE %s) AND status = 'Aktif'
            ORDER BY nama_produk
        """
        search_pattern = f"%{search_term}%"
        return db.execute_query(query, (search_pattern, search_pattern), fetch_all=True)

