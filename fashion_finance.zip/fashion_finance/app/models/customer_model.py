"""Customer model"""
from app.models.database import db

class CustomerModel:
    """Customer model"""
    
    @staticmethod
    def get_all():
        """Get all customers"""
        query = "SELECT * FROM customers ORDER BY nama_pembeli"
        return db.execute_query(query, fetch_all=True)
    
    @staticmethod
    def get_by_id(customer_id):
        """Get customer by ID"""
        query = "SELECT * FROM customers WHERE id = %s"
        return db.execute_query(query, (customer_id,), fetch_one=True)
    
    @staticmethod
    def create(nama_pembeli, no_hp=None, alamat=None):
        """Create new customer"""
        query = """
            INSERT INTO customers (nama_pembeli, no_hp, alamat)
            VALUES (%s, %s, %s)
        """
        return db.execute_query(query, (nama_pembeli, no_hp, alamat))
    
    @staticmethod
    def update(customer_id, **kwargs):
        """Update customer"""
        allowed_fields = ['nama_pembeli', 'no_hp', 'alamat']
        updates = []
        values = []
        
        for field, value in kwargs.items():
            if field in allowed_fields and value is not None:
                updates.append(f"{field} = %s")
                values.append(value)
        
        if not updates:
            return False
        
        values.append(customer_id)
        query = f"UPDATE customers SET {', '.join(updates)} WHERE id = %s"
        db.execute_query(query, tuple(values))
        return True
    
    @staticmethod
    def delete(customer_id):
        """Delete customer"""
        query = "DELETE FROM customers WHERE id = %s"
        db.execute_query(query, (customer_id,))
        return True
    
    @staticmethod
    def get_or_create_default():
        """Get or create default customer (Pembeli Umum)"""
        query = "SELECT id FROM customers WHERE nama_pembeli = 'Pembeli Umum'"
        result = db.execute_query(query, fetch_one=True)
        
        if result:
            return result['id']
        else:
            return CustomerModel.create('Pembeli Umum', '-', '-')

