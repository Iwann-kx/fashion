"""Database connection and management"""
import mysql.connector
from mysql.connector import Error
from mysql.connector import pooling
from app.config.database import DatabaseConfig
import logging

logger = logging.getLogger(__name__)

class Database:
    """MySQL database connection manager"""
    
    _instance = None
    _pool = None
    _pool_creation_attempted = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Database, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        # Don't create pool at initialization - make it lazy
        pass
    
    def _create_connection_pool(self):
        """Create MySQL connection pool"""
        if self._pool is not None:
            return  # Pool already exists
        
        if self._pool_creation_attempted:
            raise Error("Connection pool creation failed previously. Please check database configuration.")
        
        try:
            config = DatabaseConfig.get_connection_params()
            pool_config = {
                **config,
                'pool_name': 'fashion_finance_pool',
                'pool_size': DatabaseConfig.POOL_SIZE,
                'pool_reset_session': True
            }
            
            self._pool = pooling.MySQLConnectionPool(**pool_config)
            logger.info("Database connection pool created successfully")
            self._pool_creation_attempted = True
        except Error as e:
            self._pool_creation_attempted = True
            logger.error(f"Error creating connection pool: {e}")
            raise
    
    def get_connection(self):
        """Get a connection from the pool"""
        try:
            if self._pool is None:
                self._create_connection_pool()
            return self._pool.get_connection()
        except Error as e:
            logger.error(f"Error getting connection from pool: {e}")
            raise
    
    def test_connection(self):
        """Test database connection"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor(buffered=True)  # Use buffered cursor to avoid unread result issues
            cursor.execute("SELECT 1")
            result = cursor.fetchone()  # Fetch the result to avoid "Unread result" error
            cursor.close()
            conn.close()
            return True
        except Error as e:
            logger.error(f"Connection test failed: {e}")
            return False
        except Exception as e:
            logger.error(f"Connection test failed with unexpected error: {e}")
            return False
    
    def execute_query(self, query, params=None, fetch_one=False, fetch_all=False):
        """Execute a query and return results"""
        conn = None
        cursor = None
        try:
            conn = self.get_connection()
            cursor = conn.cursor(dictionary=True, buffered=True)  # Use buffered cursor
            cursor.execute(query, params or ())
            
            if fetch_one:
                result = cursor.fetchone()
            elif fetch_all:
                result = cursor.fetchall()
            else:
                conn.commit()
                result = cursor.lastrowid
            
            cursor.close()
            conn.close()
            return result
        except Error as e:
            if conn:
                conn.rollback()
                conn.close()
            logger.error(f"Query execution error: {e}")
            raise
    
    def execute_many(self, query, params_list):
        """Execute a query multiple times with different parameters"""
        conn = None
        cursor = None
        try:
            conn = self.get_connection()
            cursor = conn.cursor(buffered=True)  # Use buffered cursor
            cursor.executemany(query, params_list)
            conn.commit()
            cursor.close()
            conn.close()
            return True
        except Error as e:
            if conn:
                conn.rollback()
                conn.close()
            logger.error(f"Batch execution error: {e}")
            raise
    
    def create_tables(self):
        """Create all database tables if they don't exist"""
        conn = None
        cursor = None
        try:
            conn = self.get_connection()
            cursor = conn.cursor(buffered=True)  # Use buffered cursor
            
            # Users table (combining owners and kasir into users with role)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(50) UNIQUE NOT NULL,
                    password VARCHAR(255) NOT NULL,
                    email VARCHAR(100),
                    nama VARCHAR(100) NOT NULL,
                    role ENUM('admin', 'kasir') NOT NULL DEFAULT 'kasir',
                    no_hp VARCHAR(20),
                    alamat TEXT,
                    tanggal_bergabung DATETIME DEFAULT CURRENT_TIMESTAMP,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_username (username),
                    INDEX idx_role (role)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            # Products table (barang)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS products (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    kode_produk VARCHAR(45) UNIQUE NOT NULL,
                    nama_produk VARCHAR(100) NOT NULL,
                    kategori VARCHAR(50) NOT NULL,
                    harga_jual DECIMAL(12, 2) NOT NULL,
                    stok INT NOT NULL DEFAULT 0,
                    gambar TEXT,
                    status ENUM('Aktif', 'Nonaktif') DEFAULT 'Aktif',
                    user_id INT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
                    INDEX idx_kode_produk (kode_produk),
                    INDEX idx_kategori (kategori),
                    INDEX idx_status (status)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            # Customers table (pembeli)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS customers (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    nama_pembeli VARCHAR(100) NOT NULL,
                    no_hp VARCHAR(20),
                    alamat TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_nama (nama_pembeli)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            # Sales table (transaksi)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS sales (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    kode_transaksi VARCHAR(50) UNIQUE NOT NULL,
                    user_id INT NOT NULL,
                    customer_id INT,
                    tanggal_transaksi DATETIME NOT NULL,
                    total DECIMAL(12, 2) NOT NULL,
                    metode_pembayaran VARCHAR(50) DEFAULT 'Tunai',
                    status ENUM('Selesai', 'Pending', 'Batal') DEFAULT 'Selesai',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
                    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
                    INDEX idx_kode_transaksi (kode_transaksi),
                    INDEX idx_tanggal (tanggal_transaksi),
                    INDEX idx_user (user_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            # Sales details table (detail_transaksi)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS sales_details (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    sale_id INT NOT NULL,
                    product_id INT NOT NULL,
                    quantity INT NOT NULL,
                    harga_satuan DECIMAL(12, 2) NOT NULL,
                    subtotal DECIMAL(12, 2) NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
                    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT,
                    INDEX idx_sale (sale_id),
                    INDEX idx_product (product_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            # Expenses table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS expenses (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    tanggal DATE NOT NULL,
                    deskripsi TEXT NOT NULL,
                    kategori VARCHAR(50) NOT NULL,
                    jumlah DECIMAL(12, 2) NOT NULL,
                    status ENUM('Lunas', 'Belum Lunas') DEFAULT 'Lunas',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_tanggal (tanggal),
                    INDEX idx_kategori (kategori)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            conn.commit()
            cursor.close()
            conn.close()
            logger.info("Database tables created successfully")
            return True
        except Error as e:
            if conn:
                conn.rollback()
                conn.close()
            logger.error(f"Error creating tables: {e}")
            raise

# Global database instance
db = Database()

