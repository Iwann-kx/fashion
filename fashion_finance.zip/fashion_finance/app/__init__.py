"""
Fashion Finance Application
A modular MVC-based fashion business management system
"""

__version__ = "1.0.0"

