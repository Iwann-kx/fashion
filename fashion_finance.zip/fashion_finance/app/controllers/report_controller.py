"""Report controller"""
from app.models.report_model import ReportModel
from datetime import datetime

class ReportController:
    """Controller for report operations"""
    
    @staticmethod
    def get_dashboard_stats():
        """Get dashboard statistics"""
        return ReportModel.get_dashboard_stats()
    
    @staticmethod
    def get_recent_sales(limit=5):
        """Get recent sales"""
        return ReportModel.get_recent_sales(limit)
    
    @staticmethod
    def get_best_selling_products(limit=5):
        """Get best selling products"""
        return ReportModel.get_best_selling_products(limit)
    
    @staticmethod
    def get_monthly_performance(year=None, month=None):
        """Get monthly performance"""
        if not year or not month:
            now = datetime.now()
            year = now.year
            month = now.month
        return ReportModel.get_monthly_performance(year, month)

    @staticmethod
    def get_summary_report(months=6):
        """Return a summary report for the last `months` months.

        Each item contains: periode (YYYY-MM), penjualan, pengeluaran, keuntungan, margin
        """
        now = datetime.now()
        results = []
        for i in range(months):
            # compute year/month going backwards
            y = now.year
            m = now.month - i
            while m <= 0:
                m += 12
                y -= 1

            perf = ReportModel.get_monthly_performance(y, m)
            periode = f"{y}-{m:02d}"
            results.append({
                'periode': periode,
                'penjualan': perf.get('monthly_sales', 0),
                'pengeluaran': perf.get('monthly_expenses', 0),
                'keuntungan': perf.get('monthly_profit', 0),
                'margin': round(perf.get('margin', 0), 2)
            })

        return results
    
    @staticmethod
    def get_sales_by_category():
        """Get sales grouped by category"""
        return ReportModel.get_sales_by_category()

