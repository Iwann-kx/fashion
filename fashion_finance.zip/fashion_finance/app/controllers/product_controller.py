"""Product controller"""
from app.models.product_model import ProductModel
import os
import shutil

class ProductController:
    """Controller for product operations"""
    
    @staticmethod
    def get_all_products(active_only=True):
        """Get all products"""
        return ProductModel.get_all(active_only)
    
    @staticmethod
    def get_product(product_id):
        """Get product by ID"""
        return ProductModel.get_by_id(product_id)
    
    @staticmethod
    def create_product(kode_produk, nama_produk, kategori, harga_jual, stok, user_id=None, image_path=None):
        """Create new product"""
        # Handle image upload
        gambar = None
        if image_path and os.path.exists(image_path):
            gambar = ProductController._save_product_image(image_path, kode_produk, nama_produk)
        
        # Check if product code already exists
        existing = ProductModel.get_by_code(kode_produk)
        if existing:
            return False, "Kode produk sudah digunakan"
        
        try:
            product_id = ProductModel.create(
                kode_produk, nama_produk, kategori, harga_jual, stok, user_id, gambar
            )
            return True, product_id
        except Exception as e:
            return False, str(e)
    
    @staticmethod
    def update_product(product_id, **kwargs):
        """Update product"""
        # Handle image update
        if 'image_path' in kwargs:
            image_path = kwargs.pop('image_path')
            if image_path and os.path.exists(image_path):
                product = ProductModel.get_by_id(product_id)
                if product:
                    gambar = ProductController._save_product_image(
                        image_path, product['kode_produk'], product['nama_produk']
                    )
                    kwargs['gambar'] = gambar
        
        try:
            ProductModel.update(product_id, **kwargs)
            return True, "Produk berhasil diperbarui"
        except Exception as e:
            return False, str(e)
    
    @staticmethod
    def delete_product(product_id):
        """Delete product (soft delete)"""
        try:
            ProductModel.delete(product_id)
            return True, "Produk berhasil dihapus"
        except Exception as e:
            return False, str(e)
    
    @staticmethod
    def update_stock(product_id, quantity_change):
        """Update product stock"""
        try:
            ProductModel.update_stock(product_id, quantity_change)
            return True, "Stok berhasil diperbarui"
        except Exception as e:
            return False, str(e)
    
    @staticmethod
    def search_products(search_term):
        """Search products"""
        return ProductModel.search(search_term)
    
    @staticmethod
    def get_low_stock_products(threshold=10):
        """Get products with low stock"""
        return ProductModel.get_low_stock(threshold)
    
    @staticmethod
    def _save_product_image(source_path, kode_produk, product_name):
        """Save product image to images/products folder"""
        try:
            os.makedirs('images/products', exist_ok=True)
            
            # Generate safe filename
            safe_name = "".join(c for c in product_name if c.isalnum() or c in (' ', '-', '_')).rstrip()
            safe_name = safe_name.replace(' ', '_').lower()
            file_extension = os.path.splitext(source_path)[1].lower()
            new_filename = f"{safe_name}_{kode_produk}{file_extension}"
            new_path = os.path.join('images', 'products', new_filename)
            
            # Copy file
            shutil.copy2(source_path, new_path)
            return new_path
        except Exception as e:
            print(f"Error saving image: {e}")
            return None

