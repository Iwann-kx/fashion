"""Authentication controller"""
from app.models.user_model import UserModel

class AuthController:
    """Controller for authentication operations"""
    
    def __init__(self):
        self.current_user = None
        self.current_user_role = None
    
    def login(self, username, password):
        """Authenticate user"""
        user = UserModel.authenticate(username, password)
        if user:
            self.current_user = user
            self.current_user_role = user['role']
            return True, user
        return False, None
    
    def logout(self):
        """Logout current user"""
        self.current_user = None
        self.current_user_role = None
    
    def is_authenticated(self):
        """Check if user is authenticated"""
        return self.current_user is not None
    
    def has_permission(self, required_role):
        """Check if user has required permission"""
        if not self.is_authenticated():
            return False
        return self.current_user_role == required_role or self.current_user_role == 'admin'
    
    def get_current_user(self):
        """Get current user data"""
        return self.current_user
    
    def get_current_role(self):
        """Get current user role"""
        return self.current_user_role

