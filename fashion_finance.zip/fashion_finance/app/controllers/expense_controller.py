"""Expense controller"""
from app.models.expense_model import ExpenseModel

class ExpenseController:
    """Controller for expense operations"""
    
    @staticmethod
    def get_all_expenses(limit=None):
        """Get all expenses"""
        return ExpenseModel.get_all(limit)
    
    @staticmethod
    def get_expense(expense_id):
        """Get expense by ID"""
        return ExpenseModel.get_by_id(expense_id)
    
    @staticmethod
    def create_expense(tanggal, deskripsi, kategori, jumlah, status='Lunas'):
        """Create new expense"""
        try:
            expense_id = ExpenseModel.create(tanggal, deskripsi, kategori, jumlah, status)
            return True, expense_id
        except Exception as e:
            return False, str(e)
    
    @staticmethod
    def update_expense(expense_id, **kwargs):
        """Update expense"""
        try:
            ExpenseModel.update(expense_id, **kwargs)
            return True, "Pengeluaran berhasil diperbarui"
        except Exception as e:
            return False, str(e)
    
    @staticmethod
    def delete_expense(expense_id):
        """Delete expense"""
        try:
            ExpenseModel.delete(expense_id)
            return True, "Pengeluaran berhasil dihapus"
        except Exception as e:
            return False, str(e)
    
    @staticmethod
    def get_total_expenses():
        """Get total expenses"""
        return ExpenseModel.get_total()
    
    @staticmethod
    def get_expenses_by_date_range(start_date, end_date):
        """Get expenses by date range"""
        return ExpenseModel.get_by_date_range(start_date, end_date)
    
    @staticmethod
    def get_monthly_total(year, month):
        """Get monthly total expenses"""
        return ExpenseModel.get_monthly_total(year, month)

