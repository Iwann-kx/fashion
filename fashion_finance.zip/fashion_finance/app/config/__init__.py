"""Configuration module"""

