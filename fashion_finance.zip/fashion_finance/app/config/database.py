"""Database configuration"""
import os

class DatabaseConfig:
    """Database configuration settings"""
    
    # MySQL Configuration
    # Set these values or use environment variables
    HOST = os.getenv('DB_HOST', 'localhost')
    USER = os.getenv('DB_USER', 'root')
    # IMPORTANT: Set your MySQL password here or via DB_PASSWORD environment variable
    # If MySQL has no password, leave as empty string ''
    PASSWORD = os.getenv('DB_PASSWORD', '')
    DATABASE = os.getenv('DB_NAME', 'fashion_finance')
    PORT = int(os.getenv('DB_PORT', 3306))
    
    # Connection pool settings
    POOL_SIZE = 5
    MAX_OVERFLOW = 10
    POOL_RECYCLE = 3600
    
    @classmethod
    def get_connection_params(cls):
        """Get connection parameters as dictionary"""
        return {
            'host': cls.HOST,
            'user': cls.USER,
            'password': cls.PASSWORD,
            'database': cls.DATABASE,
            'port': cls.PORT,
            'charset': 'utf8mb4',
            'collation': 'utf8mb4_unicode_ci',
            'autocommit': False
        }
