"""Helper utilities used across views and components.

Currently provides:
- `format_currency` : format numeric values as Indonesian Rupiah strings.
"""

def format_currency(value, symbol='Rp ', decimals=0):
    """Format `value` as a currency string.

    - `value` may be int/float/str. Non-numeric values return a zero-value string.
    - `symbol` is prefixed (default 'Rp ').
    - `decimals` controls number of decimal places.
    Examples:
        format_currency(1500000) -> 'Rp 1.500.000'
        format_currency(1234.56, decimals=2) -> 'Rp 1.234,56'
    """
    try:
        amount = float(value)
    except Exception:
        return f"{symbol}0"

    # Handle decimals and separators (thousands '.' and decimal ',')
    if decimals <= 0:
        rounded = int(round(amount))
        formatted = f"{rounded:,}".replace(",", ".")
    else:
        # Format with standard US separators then swap
        fmt = f"{amount:,.{decimals}f}"
        # fmt uses ',' for thousands and '.' for decimal; swap to Indonesian style
        formatted = fmt.replace(',', 'X').replace('.', ',').replace('X', '.')

    return f"{symbol}{formatted}"
