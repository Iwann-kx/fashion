﻿"""Sales View - Complete with all features for transaction management"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QScrollArea, QMessageBox, QFrame, QDialog,
                             QComboBox, QSpinBox, QDialogButtonBox, QTableWidget, QTableWidgetItem, QPushButton,
                             QLineEdit, QHeaderView, QDateEdit, QDoubleSpinBox)
from PyQt5.QtCore import pyqtSignal, Qt, QDate, QTimer
from PyQt5.QtGui import QFont, QPixmap
from app.components import NavigationHeader, StatCard
from app.components.tables import DataTable
from app.components.buttons import PrimaryButton
from app.components.inputs import SearchInput, StyledComboBox
from app.controllers.product_controller import ProductController
from app.controllers.transaction_controller import TransactionController
from app.utils.helpers import format_currency
from datetime import datetime
import os


class AddSaleDialog(QDialog):
    """Dialog for adding new sales transactions with product selection"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.products_data = []
        self.init_ui()
    
    def init_ui(self):
        """Initialize the dialog UI"""
        self.setWindowTitle('💳 Tambah Transaksi Penjualan')
        self.setFixedSize(750, 600)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Title section
        title = QLabel('Tambah Transaksi Penjualan Baru')
        title.setFont(QFont('Arial', 16, QFont.Bold))
        title.setStyleSheet('color: #2c3e50; background-color: #ecf0f1; padding: 15px; border-radius: 8px;')
        layout.addWidget(title)
        
        # Product selection section
        product_layout = QHBoxLayout()
        product_layout.setSpacing(20)
        
        # Left side - product selector
        left_layout = QVBoxLayout()
        product_label = QLabel('🛍️ PILIH PRODUK')
        product_label.setFont(QFont('Arial', 12, QFont.Bold))
        product_label.setStyleSheet('color: #2c3e50; background-color: #f8f9fa; padding: 8px; border-radius: 4px;')
        
        self.product_combo = QComboBox()
        self.product_combo.setStyleSheet('''
            QComboBox {
                padding: 10px;
                border: 2px solid #e0e0e0;
                border-radius: 6px;
                font-size: 11pt;
            }
            QComboBox:hover { border-color: #3498db; }
            QComboBox:focus { border-color: #3498db; background-color: #fff; }
        ''')
        self.load_products()
        self.product_combo.currentIndexChanged.connect(self.on_product_changed)
        
        left_layout.addWidget(product_label)
        left_layout.addWidget(self.product_combo)
        
        # Right side - product image
        right_layout = QVBoxLayout()
        image_label = QLabel('🖼️ GAMBAR PRODUK')
        image_label.setFont(QFont('Arial', 12, QFont.Bold))
        image_label.setStyleSheet('color: #2c3e50; background-color: #f8f9fa; padding: 8px; border-radius: 4px;')
        
        self.product_image = QLabel()
        self.product_image.setFixedSize(180, 180)
        self.product_image.setStyleSheet('''
            QLabel {
                border: 3px solid #e0e0e0;
                border-radius: 8px;
                background-color: #f8f9fa;
                font-weight: bold;
                color: #7f8c8d;
            }
        ''')
        self.product_image.setAlignment(Qt.AlignCenter)
        self.product_image.setText('📷\nPilih Produk\nuntuk melihat\nGambar')
        self.product_image.setWordWrap(True)
        
        right_layout.addWidget(image_label)
        right_layout.addWidget(self.product_image, 0, Qt.AlignCenter)
        
        product_layout.addLayout(left_layout, 2)
        product_layout.addLayout(right_layout, 1)
        layout.addLayout(product_layout)
        
        # Stock info
        stock_label = QLabel('📦 STOK TERSEDIA')
        stock_label.setFont(QFont('Arial', 12, QFont.Bold))
        stock_label.setStyleSheet('color: #2c3e50; background-color: #f8f9fa; padding: 8px; border-radius: 4px;')
        self.stock_info = QLabel('Stok: 0')
        self.stock_info.setFont(QFont('Arial', 11))
        self.stock_info.setStyleSheet('color: #27ae60; padding: 5px;')
        
        stock_h_layout = QHBoxLayout()
        stock_h_layout.addWidget(stock_label)
        stock_h_layout.addWidget(self.stock_info)
        stock_h_layout.addStretch()
        layout.addLayout(stock_h_layout)
        
        # Quantity section
        quantity_label = QLabel('📊 JUMLAH PEMBELIAN')
        quantity_label.setFont(QFont('Arial', 12, QFont.Bold))
        quantity_label.setStyleSheet('color: #2c3e50; background-color: #f8f9fa; padding: 8px; border-radius: 4px;')
        
        self.quantity_spin = QSpinBox()
        self.quantity_spin.setRange(1, 1000)
        self.quantity_spin.setValue(1)
        self.quantity_spin.setStyleSheet('''
            QSpinBox {
                padding: 10px;
                border: 2px solid #e0e0e0;
                border-radius: 6px;
                font-size: 12pt;
            }
            QSpinBox:focus { border-color: #3498db; }
        ''')
        self.quantity_spin.valueChanged.connect(self.on_quantity_changed)
        
        layout.addWidget(quantity_label)
        layout.addWidget(self.quantity_spin)
        
        # Price breakdown
        breakdown_frame = QFrame()
        breakdown_frame.setStyleSheet('QFrame { background-color: #ecf0f1; border-radius: 8px; padding: 12px; }')
        breakdown_layout = QVBoxLayout(breakdown_frame)
        breakdown_layout.setSpacing(8)
        
        price_h_layout = QHBoxLayout()
        price_label = QLabel('💰 HARGA SATUAN:')
        price_label.setFont(QFont('Arial', 11, QFont.Bold))
        self.price_display = QLabel('Rp 0')
        self.price_display.setFont(QFont('Arial', 12, QFont.Bold))
        self.price_display.setStyleSheet('color: #27ae60;')
        price_h_layout.addWidget(price_label)
        price_h_layout.addStretch()
        price_h_layout.addWidget(self.price_display)
        
        total_h_layout = QHBoxLayout()
        total_label = QLabel('💵 TOTAL HARGA:')
        total_label.setFont(QFont('Arial', 13, QFont.Bold))
        self.total_display = QLabel('Rp 0')
        self.total_display.setFont(QFont('Arial', 14, QFont.Bold))
        self.total_display.setStyleSheet('color: #27ae60; background-color: #d5f4e6; padding: 8px 12px; border-radius: 6px; border: 2px solid #27ae60;')
        total_h_layout.addWidget(total_label)
        total_h_layout.addStretch()
        total_h_layout.addWidget(self.total_display)
        
        breakdown_layout.addLayout(price_h_layout)
        breakdown_layout.addLayout(total_h_layout)
        layout.addWidget(breakdown_frame)
        
        # Customer info section (optional)
        customer_label = QLabel('👤 NAMA PEMBELI (OPSIONAL)')
        customer_label.setFont(QFont('Arial', 12, QFont.Bold))
        customer_label.setStyleSheet('color: #2c3e50; background-color: #f8f9fa; padding: 8px; border-radius: 4px;')
        
        self.customer_input = QLineEdit()
        self.customer_input.setPlaceholderText('Nama pembeli atau nomor referensi')
        self.customer_input.setStyleSheet('QLineEdit { padding: 10px; border: 2px solid #e0e0e0; border-radius: 6px; }')
        
        layout.addWidget(customer_label)
        layout.addWidget(self.customer_input)
        
        layout.addStretch()
        
        # Buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.setStyleSheet('''
            QPushButton {
                padding: 12px 24px;
                border: none;
                border-radius: 6px;
                font-weight: bold;
                min-width: 100px;
            }
            QPushButton[text="OK"] {
                background-color: #27ae60;
                color: white;
            }
            QPushButton[text="OK"]:hover {
                background-color: #2ecc71;
            }
            QPushButton[text="Cancel"] {
                background-color: #95a5a6;
                color: white;
            }
            QPushButton[text="Cancel"]:hover {
                background-color: #7f8c8d;
            }
        ''')
        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
    
    def load_products(self):
        """Load available products into combo box"""
        try:
            products = ProductController.get_all_products(active_only=True)
            self.product_combo.clear()
            self.products_data = []
            
            for product in products:
                stok = product.get('stok', 0)
                if stok > 0:
                    price = float(product.get('harga_jual', 0))
                    price_text = format_currency(price)
                    image_icon = ' 📷' if product.get('gambar') else ''
                    nama = product.get('nama_produk', '')
                    item_text = nama + ' - ' + price_text + ' (Stok: ' + str(stok) + ')' + image_icon
                    self.product_combo.addItem(item_text)
                    self.products_data.append(product)
            
            if self.products_data:
                self.product_combo.setCurrentIndex(0)
        except Exception as e:
            QMessageBox.warning(self, 'Error', 'Gagal memuat produk: ' + str(e))
    
    def on_product_changed(self):
        """Handle product selection change"""
        if self.product_combo.currentIndex() >= 0 and self.products_data:
            product = self.products_data[self.product_combo.currentIndex()]
            price = float(product.get('harga_jual', 0))
            stok = product.get('stok', 0)
            
            self.price_display.setText(format_currency(price))
            self.stock_info.setText('Stok: ' + str(stok) + ' unit')
            
            # Load image
            image_path = product.get('gambar')
            if image_path and os.path.exists(image_path):
                pixmap = QPixmap(image_path)
                scaled_pixmap = pixmap.scaled(180, 180, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                self.product_image.setPixmap(scaled_pixmap)
            else:
                self.product_image.setText('📷\nTidak Ada\nGambar')
                self.product_image.setPixmap(None)
            
            # Reset quantity
            self.quantity_spin.setValue(1)
            self.on_quantity_changed()
    
    def on_quantity_changed(self):
        """Calculate total when quantity changes"""
        if self.product_combo.currentIndex() >= 0 and self.products_data:
            product = self.products_data[self.product_combo.currentIndex()]
            price = float(product.get('harga_jual', 0))
            quantity = self.quantity_spin.value()
            total = price * quantity
            
            self.total_display.setText(format_currency(total))
    
    def validate_and_accept(self):
        """Validate form before accepting"""
        if self.product_combo.currentIndex() < 0:
            QMessageBox.warning(self, 'Error', 'Pilih produk terlebih dahulu!')
            return
        
        product = self.products_data[self.product_combo.currentIndex()]
        stok = product.get('stok', 0)
        quantity = self.quantity_spin.value()
        
        if quantity > stok:
            QMessageBox.warning(self, 'Error', 'Stok tidak mencukupi!\nStok tersedia: ' + str(stok) + ' unit')
            return
        
        self.accept()
    
    def get_data(self):
        """Get form data"""
        product = self.products_data[self.product_combo.currentIndex()]
        price = float(product.get('harga_jual', 0))
        quantity = self.quantity_spin.value()
        
        return {
            'product_id': product.get('id'),
            'product_name': product.get('nama_produk', ''),
            'quantity': quantity,
            'price': price,
            'total': price * quantity,
            'customer': self.customer_input.text() or 'Pembeli Umum'
        }


class SalesWindow(QWidget):
    """Sales management window with transaction history"""
    
    # Signals for navigation
    back_clicked = pyqtSignal()
    inventory_clicked = pyqtSignal()
    expenses_clicked = pyqtSignal()
    reports_clicked = pyqtSignal()
    settings_clicked = pyqtSignal()
    logout_clicked = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.user_role = 'admin'
        self.refresh_timer = None
        self.init_ui()
    
    def init_ui(self):
        """Initialize the window UI"""
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Header with navigation
        header = NavigationHeader('sales', self.user_role)
        header.dashboard_clicked.connect(self.back_clicked.emit)
        header.inventory_clicked.connect(self.inventory_clicked.emit)
        header.expenses_clicked.connect(self.expenses_clicked.emit)
        header.reports_clicked.connect(self.reports_clicked.emit)
        header.settings_clicked.connect(self.settings_clicked.emit)
        header.logout_clicked.connect(self.logout_clicked.emit)
        
        # Scroll area for content
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet('QScrollArea { border: none; background-color: #f8f9fa; }')
        
        # Main content widget
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(20)
        
        # Page title with action button
        title_layout = QHBoxLayout()
        page_title = QLabel('💳 Penjualan')
        page_title.setFont(QFont('Arial', 28, QFont.Bold))
        page_title.setStyleSheet('color: #2c3e50;')
        
        title_layout.addWidget(page_title)
        title_layout.addStretch()
        
        subtitle = QLabel('Kelola dan catat semua transaksi penjualan')
        subtitle.setFont(QFont('Arial', 12))
        subtitle.setStyleSheet('color: #7f8c8d;')
        content_layout.addWidget(subtitle)

        add_btn = PrimaryButton('Tambah Penjualan', '➕')
        add_btn.clicked.connect(self.add_sale)
        title_layout.addWidget(add_btn)
        
        content_layout.addLayout(title_layout)

        # Search and filter
        filter_layout = QHBoxLayout()
        filter_layout.setSpacing(12)
        self.search_input = SearchInput("🔍 Cari transaksi...")
        self.date_filter = StyledComboBox(["Semua Waktu", "Hari ini", "Minggu ini", "Bulan ini"])
        self.date_filter.setFixedWidth(180)
        filter_layout.addWidget(self.search_input)
        filter_layout.addWidget(self.date_filter)
        filter_layout.addStretch()
        content_layout.addLayout(filter_layout)

        # Stat cards layout
        self.stats_layout = QHBoxLayout()
        self.stats_layout.setSpacing(20)
        content_layout.addLayout(self.stats_layout)
        
        # Transactions table frame
        table_frame = QFrame()
        table_frame.setStyleSheet('QFrame { background-color: white; border-radius: 12px; padding: 20px; border: 1px solid #e0e0e0; }')
        
        table_layout = QVBoxLayout(table_frame)
        table_layout.setSpacing(15)
        
        table_header_layout = QHBoxLayout()
        table_title = QLabel('📊 Riwayat Penjualan')
        table_title.setFont(QFont('Arial', 18, QFont.Bold))
        table_title.setStyleSheet('color: #2c3e50;')
        table_header_layout.addWidget(table_title)
        table_header_layout.addStretch()
        
        refresh_btn = QPushButton('🔄 Refresh')
        refresh_btn.setMaximumWidth(120)
        refresh_btn.setStyleSheet('QPushButton { background-color: #3498db; color: white; padding: 8px 16px; border-radius: 4px; font-weight: bold; }')
        refresh_btn.clicked.connect(self.load_data)
        table_header_layout.addWidget(refresh_btn)
        
        # Transactions table (DataTable) - styled like inventory
        columns = ['KODE', 'TANGGAL', 'PEMBELI', 'ITEMS', 'TOTAL', 'STATUS', 'AKSI']
        self.table = DataTable(columns)
        self.table.verticalHeader().setDefaultSectionSize(65)
        
        table_layout.addLayout(table_header_layout)
        table_layout.addWidget(self.table)
        
        content_layout.addWidget(table_frame)
        content_layout.addStretch()
        
        scroll_area.setWidget(content_widget)
        
        main_layout.addWidget(header)
        main_layout.addWidget(scroll_area, 1)
        
        self.setLayout(main_layout)
        self.setStyleSheet('background-color: #f8f9fa;')
        
        # Setup auto-refresh timer
        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self.load_data)
        self.refresh_timer.start(30000)  # Refresh every 30 seconds
        
        self.load_data()
    
    def add_sale(self):
        """Add new sale transaction"""
        dialog = AddSaleDialog(self)
        if dialog.exec_():
            data = dialog.get_data()
            try:
                user_id = 1  # Default user ID
                success, result = TransactionController.create_transaction(
                    user_id=user_id,
                    product_id=data['product_id'],
                    quantity=data['quantity'],
                    customer_name=data['customer']
                )
                
                if success:
                    QMessageBox.information(self, 'Sukses', 'Penjualan berhasil ditambahkan!')
                    self.load_data()
                else:
                    QMessageBox.warning(self, 'Error', 'Gagal menambah penjualan: ' + str(result))
            except Exception as e:
                QMessageBox.warning(self, 'Error', 'Error: ' + str(e))
    
    def load_data(self):
        """Load transaction data into table"""
        # Clear existing stat cards
        while self.stats_layout.count():
            child = self.stats_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
        
        # Create stat cards
        stats_data = [
            ('Total Penjualan', 'Rp 0', 'Rp 0', '#27ae60', '💳'),
            ('Transaksi Hari Ini', '0', '0 transaksi', '#3498db', '📈'),
            ('Rata-rata Transaksi', 'Rp 0', 'Rp 0', '#f39c12', '📊'),
            ('Terlaris', '-', '0 unit', '#9b59b6', '⭐')
        ]
        
        for title, value, change, color, icon in stats_data:
            card = StatCard(title, value, change, color, icon)
            self.stats_layout.addWidget(card)
        
        self.stats_layout.addStretch()
        
        # Load transaction data
        try:
            transactions = TransactionController.get_all_transactions(limit=20)
            self.table.setRowCount(len(transactions))
            
            # use DataTable API
            self.table.clear_data()
            for trans in transactions:
                trans_id = str(trans.get('id', ''))
                tanggal = str(trans.get('tanggal_transaksi', '')).split()[0]
                produk = str(trans.get('customer_nama', 'Produk'))
                pembeli = str(trans.get('customer_nama', '-'))
                qty = str(trans.get('item_count', 1))
                harga = format_currency(trans.get('harga_satuan', 0))
                total = format_currency(trans.get('total', 0))

                # prepare row data (exclude action column)
                row_data = [f"🔖 {trans_id}", f"📅 {tanggal}", f"🛍️ {pembeli}", f"📦 {qty}", f"💵 {total}", "Selesai"]

                # action callbacks expect functions accepting (checked) arg
                def make_delete_fn(tid):
                    return lambda checked=False, _tid=tid: self.delete_transaction_by_id(_tid)

                action_callbacks = {
                    'edit': lambda checked=False, t=trans: self.open_transaction_details(t),
                    'delete': make_delete_fn(trans.get('id'))
                }

                # add_row: DataTable will place action group in last column
                self.table.add_row(row_data, action_callbacks)
        except Exception as e:
            print('Error loading transactions: ' + str(e))

    def delete_transaction_by_id(self, sale_id):
        """Delete (mark/cancel) a transaction by id using controller"""
        reply = QMessageBox.question(
            self,
            'Konfirmasi Hapus',
            'Apakah Anda yakin ingin menghapus transaksi ini?',
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            try:
                success, result = TransactionController.delete_transaction(sale_id)
                if success:
                    QMessageBox.information(self, 'Sukses', 'Transaksi berhasil dihapus!')
                    self.load_data()
                else:
                    QMessageBox.warning(self, 'Error', 'Gagal menghapus transaksi: ' + str(result))
            except Exception as e:
                QMessageBox.warning(self, 'Error', 'Error: ' + str(e))

    def open_transaction_details(self, transaction):
        """Placeholder: open detail dialog or view for a transaction"""
        QMessageBox.information(self, 'Detail Transaksi', f"Transaksi: {transaction.get('kode_transaksi', transaction.get('id'))}")
    
    def delete_transaction(self, row):
        """Delete a transaction"""
        reply = QMessageBox.question(
            self,
            'Konfirmasi Hapus',
            'Apakah Anda yakin ingin menghapus transaksi ini?',
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            QMessageBox.information(self, 'Sukses', 'Transaksi berhasil dihapus!')
            self.load_data()
    
    def set_user_role(self, role):
        """Set user role for view customization"""
        self.user_role = role
    
    def closeEvent(self, event):
        """Clean up timer on close"""
        if self.refresh_timer:
            self.refresh_timer.stop()
        super().closeEvent(event)
