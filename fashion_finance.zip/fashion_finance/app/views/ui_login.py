# app/Views/LoginView.py

from PyQt5.QtWidgets import (
    QWidget, QLabel, QVBoxLayout, QHBoxLayout, QPushButton,
    QLineEdit, QComboBox, QMessageBox, QFrame, QCheckBox
)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QFont, QIcon


class LoginView(QWidget):
    # Signal to emit when login is successful
    loginSuccessful = pyqtSignal(str, str)  # username, role
    
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        mainLayout = QVBoxLayout()
        mainLayout.setSpacing(0)
        mainLayout.setContentsMargins(0, 0, 0, 0)

        # Main container
        containerFrame = QFrame()
        containerFrame.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #f7f8ff, stop:1 #f5eef8);
            }
        """)
        containerLayout = QHBoxLayout()
        containerLayout.setSpacing(0)
        containerLayout.setContentsMargins(0, 0, 0, 0)

        # Left side - Info Panel (minimalist)
        leftPanel = QFrame()
        leftPanel.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #2c3e50, stop:1 #34495e);
                color: white;
                border-right: 1px solid rgba(255,255,255,0.08);
            }
            QLabel { color: rgba(255,255,255,0.95); }
        """)
        leftLayout = QVBoxLayout()
        leftLayout.setContentsMargins(60, 60, 60, 60)
        leftLayout.setSpacing(24)

        # Company Logo/Title
        companyTitle = QLabel("Fashion Finance")
        companyTitle.setFont(QFont("Segoe UI", 28, QFont.Bold))
        companyTitle.setStyleSheet("color: white;")
        leftLayout.addWidget(companyTitle)

        # Subtitle
        subtitle = QLabel("Business Management System")
        subtitle.setFont(QFont("Segoe UI", 12))
        subtitle.setStyleSheet("color: rgba(255,255,255,0.85);")
        leftLayout.addWidget(subtitle)

        # Info text
        leftLayout.addSpacing(40)
        
        infoText = QLabel(
            "Manage your fashion business with ease.\n\n"
            "• Dashboard Analytics\n"
            "• Product Management\n"
            "• Order Tracking\n"
            "• User Management\n"
            "• Dark Mode Support"
        )
        infoText.setFont(QFont("Segoe UI", 11))
        infoText.setStyleSheet("color: rgba(255,255,255,0.9); line-height: 1.6;")
        leftLayout.addWidget(infoText)

        leftLayout.addStretch()

        # Footer
        footerLabel = QLabel("© 2025 Fashion Finance")
        footerLabel.setFont(QFont("Segoe UI", 9))
        footerLabel.setStyleSheet("color: rgba(255,255,255,0.8);")
        leftLayout.addWidget(footerLabel)

        leftPanel.setLayout(leftLayout)
        leftPanel.setMinimumWidth(380)

        # Right side - Login/Signup Form
        rightPanel = QFrame()
        rightPanel.setStyleSheet("QFrame { background-color: #ffffff; border-radius: 8px; }")
        rightLayout = QVBoxLayout()
        rightLayout.setContentsMargins(60, 60, 60, 60)
        rightLayout.setSpacing(0)

        # Tab buttons
        tabLayout = QHBoxLayout()
        tabLayout.setSpacing(0)

        self.loginTabBtn = QPushButton("Sign In")
        self.loginTabBtn.setFont(QFont("Segoe UI", 11, QFont.Bold))
        self.loginTabBtn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #3498db;
                border: none;
                border-bottom: 2px solid #3498db;
                padding: 12px 24px;
                font-weight: bold;
            }
            QPushButton:hover {
                color: #2980b9;
                border-bottom: 2px solid #2980b9;
            }
        """)
        self.loginTabBtn.clicked.connect(self._show_login_tab)

        self.signupTabBtn = QPushButton("Sign Up")
        self.signupTabBtn.setFont(QFont("Segoe UI", 11))
        self.signupTabBtn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #999999;
                border: none;
                border-bottom: 2px solid transparent;
                padding: 12px 24px;
            }
            QPushButton:hover {
                color: #666666;
            }
        """)
        self.signupTabBtn.clicked.connect(self._show_signup_tab)

        tabLayout.addWidget(self.loginTabBtn)
        tabLayout.addWidget(self.signupTabBtn)
        tabLayout.addStretch()
        rightLayout.addLayout(tabLayout)

        # Separator
        separator = QFrame()
        separator.setStyleSheet("QFrame { background-color: #f0f0f0; height: 1px; margin: 0px; }")
        rightLayout.addWidget(separator)

        rightLayout.addSpacing(24)

        # Separator
        separator = QFrame()
        separator.setStyleSheet("QFrame { background-color: #e5e5e5; height: 1px; }")
        rightLayout.addWidget(separator)

        # Login Form (initially visible)
        self.loginForm = self._create_login_form()
        rightLayout.addWidget(self.loginForm)

        # Sign Up Form (initially hidden)
        self.signupForm = self._create_signup_form()
        self.signupForm.hide()
        rightLayout.addWidget(self.signupForm)

        rightLayout.addStretch()

        rightPanel.setLayout(rightLayout)

        containerLayout.addWidget(leftPanel)
        containerLayout.addWidget(rightPanel, 1)

        containerFrame.setLayout(containerLayout)
        mainLayout.addWidget(containerFrame)

        self.setLayout(mainLayout)
        self.setWindowTitle("Fashion Finance - Login")
        self.resize(1200, 700)

    def _create_login_form(self):
        """Create login form"""
        form = QFrame()
        layout = QVBoxLayout()
        layout.setSpacing(12)

        # Title
        title = QLabel("Welcome Back")
        title.setFont(QFont("Segoe UI", 18, QFont.Bold))
        title.setStyleSheet("color: #222222;")
        layout.addWidget(title)

        # Email
        emailLabel = QLabel("Email Address")
        emailLabel.setFont(QFont("Segoe UI", 10, QFont.Bold))
        emailLabel.setStyleSheet("color: #666;")
        layout.addWidget(emailLabel)

        self.loginEmailInput = QLineEdit()
        self.loginEmailInput.setPlaceholderText("Enter your email")
        self.loginEmailInput.setMinimumHeight(40)
        self.loginEmailInput.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ddd;
                border-radius: 6px;
                padding: 10px;
                font-size: 11px;
                background-color: #f8f8f8;
            }
            QLineEdit:focus {
                border: 2px solid #667eea;
                background-color: white;
            }
        """)
        layout.addWidget(self.loginEmailInput)

        # Password
        passwordLabel = QLabel("Password")
        passwordLabel.setFont(QFont("Segoe UI", 10, QFont.Bold))
        passwordLabel.setStyleSheet("color: #666;")
        layout.addWidget(passwordLabel)

        # Password input with show/hide toggle
        passwordContainer = QHBoxLayout()
        passwordContainer.setSpacing(8)
        passwordContainer.setContentsMargins(0, 0, 0, 0)

        self.loginPasswordInput = QLineEdit()
        self.loginPasswordInput.setPlaceholderText("Enter your password")
        self.loginPasswordInput.setEchoMode(QLineEdit.Password)
        self.loginPasswordInput.setMinimumHeight(40)
        self.loginPasswordInput.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ddd;
                border-radius: 6px;
                padding: 10px;
                font-size: 11px;
                background-color: #f8f8f8;
            }
            QLineEdit:focus {
                border: 2px solid #667eea;
                background-color: white;
            }
        """)
        passwordContainer.addWidget(self.loginPasswordInput)

        self.loginShowPasswordBtn = QPushButton("👁️")
        self.loginShowPasswordBtn.setMaximumWidth(40)
        self.loginShowPasswordBtn.setMinimumHeight(40)
        self.loginShowPasswordBtn.setStyleSheet("""
            QPushButton {
                background-color: #f8f8f8;
                border: 1px solid #ddd;
                border-radius: 6px;
                font-size: 16px;
                border-left: none;
                border-top-left-radius: 0px;
                border-bottom-left-radius: 0px;
            }
            QPushButton:hover {
                background-color: #f0f0f0;
            }
        """)
        self.loginShowPasswordBtn.clicked.connect(self._toggle_login_password_visibility)
        passwordContainer.addWidget(self.loginShowPasswordBtn)

        passwordWidget = QFrame()
        passwordWidget.setLayout(passwordContainer)
        layout.addWidget(passwordWidget)

        # Remember Me
        rememberCheckbox = QCheckBox("Remember me")
        rememberCheckbox.setFont(QFont("Segoe UI", 10))
        rememberCheckbox.setStyleSheet("color: #666;")
        layout.addWidget(rememberCheckbox)

        # Forgot Password Link
        forgotLabel = QLabel("Forgot Password?")
        forgotLabel.setFont(QFont("Segoe UI", 10))
        forgotLabel.setStyleSheet("color: #667eea; text-decoration: underline;")
        forgotLabel.setCursor(Qt.PointingHandCursor)
        layout.addWidget(forgotLabel)

        # Login Button
        loginBtn = QPushButton("Sign In")
        loginBtn.setFont(QFont("Segoe UI", 11, QFont.Bold))
        loginBtn.setMinimumHeight(45)
        loginBtn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #3498db, stop:1 #2980b9);
                color: white;
                border: none;
                border-radius: 8px;
                font-weight: bold;
                padding: 10px 20px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #2c87c8, stop:1 #236aa8);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #1f5f8a, stop:1 #1a4d6f);
            }
        """)
        loginBtn.clicked.connect(self._on_login)
        loginBtn.setCursor(Qt.PointingHandCursor)
        layout.addWidget(loginBtn)

        # Demo Credentials
        demoLabel = QLabel("Demo: admin@fashion.com / password123")
        demoLabel.setFont(QFont("Segoe UI", 9))
        demoLabel.setStyleSheet("color: #3498db; text-align: center; margin-top: 16px;")
        layout.addWidget(demoLabel)

        form.setLayout(layout)
        return form

    def _create_signup_form(self):
        """Create sign up form"""
        form = QFrame()
        layout = QVBoxLayout()
        layout.setSpacing(12)

        # Title
        title = QLabel("Create Account")
        title.setFont(QFont("Segoe UI", 18, QFont.Bold))
        title.setStyleSheet("color: #222222;")
        layout.addWidget(title)

        # Full Name
        nameLabel = QLabel("Full Name")
        nameLabel.setFont(QFont("Segoe UI", 10, QFont.Bold))
        nameLabel.setStyleSheet("color: #666;")
        layout.addWidget(nameLabel)

        self.signupNameInput = QLineEdit()
        self.signupNameInput.setPlaceholderText("Enter your full name")
        self.signupNameInput.setMinimumHeight(40)
        self.signupNameInput.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ddd;
                border-radius: 6px;
                padding: 10px;
                font-size: 11px;
                background-color: #f8f8f8;
            }
            QLineEdit:focus {
                border: 2px solid #667eea;
                background-color: white;
            }
        """)
        layout.addWidget(self.signupNameInput)

        # Email
        emailLabel = QLabel("Email Address")
        emailLabel.setFont(QFont("Segoe UI", 10, QFont.Bold))
        emailLabel.setStyleSheet("color: #666;")
        layout.addWidget(emailLabel)

        self.signupEmailInput = QLineEdit()
        self.signupEmailInput.setPlaceholderText("Enter your email")
        self.signupEmailInput.setMinimumHeight(40)
        self.signupEmailInput.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ddd;
                border-radius: 6px;
                padding: 10px;
                font-size: 11px;
                background-color: #f8f8f8;
            }
            QLineEdit:focus {
                border: 2px solid #667eea;
                background-color: white;
            }
        """)
        layout.addWidget(self.signupEmailInput)

        # Role Selection
        roleLabel = QLabel("Role")
        roleLabel.setFont(QFont("Segoe UI", 10, QFont.Bold))
        roleLabel.setStyleSheet("color: #666;")
        layout.addWidget(roleLabel)

        self.roleCombo = QComboBox()
        self.roleCombo.addItems(["Admin", "Cashier"])
        self.roleCombo.setMinimumHeight(40)
        self.roleCombo.setStyleSheet("""
            QComboBox {
                border: 1px solid #ddd;
                border-radius: 6px;
                padding: 8px;
                font-size: 11px;
                background-color: #f8f8f8;
            }
            QComboBox:focus {
                border: 2px solid #667eea;
                background-color: white;
            }
        """)
        layout.addWidget(self.roleCombo)

        # Password
        passwordLabel = QLabel("Password")
        passwordLabel.setFont(QFont("Segoe UI", 10, QFont.Bold))
        passwordLabel.setStyleSheet("color: #666;")
        layout.addWidget(passwordLabel)

        # Password input with show/hide toggle
        passwordContainer = QHBoxLayout()
        passwordContainer.setSpacing(8)
        passwordContainer.setContentsMargins(0, 0, 0, 0)

        self.signupPasswordInput = QLineEdit()
        self.signupPasswordInput.setPlaceholderText("Create a strong password")
        self.signupPasswordInput.setEchoMode(QLineEdit.Password)
        self.signupPasswordInput.setMinimumHeight(40)
        self.signupPasswordInput.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ddd;
                border-radius: 6px;
                padding: 10px;
                font-size: 11px;
                background-color: #f8f8f8;
            }
            QLineEdit:focus {
                border: 2px solid #667eea;
                background-color: white;
            }
        """)
        passwordContainer.addWidget(self.signupPasswordInput)

        self.signupShowPasswordBtn = QPushButton("👁️")
        self.signupShowPasswordBtn.setMaximumWidth(40)
        self.signupShowPasswordBtn.setMinimumHeight(40)
        self.signupShowPasswordBtn.setStyleSheet("""
            QPushButton {
                background-color: #f8f8f8;
                border: 1px solid #ddd;
                border-radius: 6px;
                font-size: 16px;
                border-left: none;
                border-top-left-radius: 0px;
                border-bottom-left-radius: 0px;
            }
            QPushButton:hover {
                background-color: #f0f0f0;
            }
        """)
        self.signupShowPasswordBtn.clicked.connect(self._toggle_signup_password_visibility)
        self.signupShowPasswordBtn.setCursor(Qt.PointingHandCursor)
        passwordContainer.addWidget(self.signupShowPasswordBtn)

        passwordWidget = QFrame()
        passwordWidget.setLayout(passwordContainer)
        layout.addWidget(passwordWidget)

        # Confirm Password
        confirmLabel = QLabel("Confirm Password")
        confirmLabel.setFont(QFont("Segoe UI", 10, QFont.Bold))
        confirmLabel.setStyleSheet("color: #666;")
        layout.addWidget(confirmLabel)

        # Confirm password input with show/hide toggle
        confirmContainer = QHBoxLayout()
        confirmContainer.setSpacing(8)
        confirmContainer.setContentsMargins(0, 0, 0, 0)

        self.signupConfirmInput = QLineEdit()
        self.signupConfirmInput.setPlaceholderText("Confirm your password")
        self.signupConfirmInput.setEchoMode(QLineEdit.Password)
        self.signupConfirmInput.setMinimumHeight(40)
        self.signupConfirmInput.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ddd;
                border-radius: 6px;
                padding: 10px;
                font-size: 11px;
                background-color: #f8f8f8;
            }
            QLineEdit:focus {
                border: 2px solid #667eea;
                background-color: white;
            }
        """)
        confirmContainer.addWidget(self.signupConfirmInput)

        self.signupShowConfirmBtn = QPushButton("👁️")
        self.signupShowConfirmBtn.setMaximumWidth(40)
        self.signupShowConfirmBtn.setMinimumHeight(40)
        self.signupShowConfirmBtn.setStyleSheet("""
            QPushButton {
                background-color: #f8f8f8;
                border: 1px solid #ddd;
                border-radius: 6px;
                font-size: 16px;
                border-left: none;
                border-top-left-radius: 0px;
                border-bottom-left-radius: 0px;
            }
            QPushButton:hover {
                background-color: #f0f0f0;
            }
        """)
        self.signupShowConfirmBtn.clicked.connect(self._toggle_signup_confirm_visibility)
        self.signupShowConfirmBtn.setCursor(Qt.PointingHandCursor)
        confirmContainer.addWidget(self.signupShowConfirmBtn)

        confirmWidget = QFrame()
        confirmWidget.setLayout(confirmContainer)
        layout.addWidget(confirmWidget)

        # Terms Checkbox
        termsCheckbox = QCheckBox("I agree to the Terms of Service")
        termsCheckbox.setFont(QFont("Segoe UI", 10))
        termsCheckbox.setStyleSheet("color: #666;")
        layout.addWidget(termsCheckbox)

        # Sign Up Button
        signupBtn = QPushButton("Create Account")
        signupBtn.setFont(QFont("Segoe UI", 11, QFont.Bold))
        signupBtn.setMinimumHeight(45)
        signupBtn.setStyleSheet("""
            QPushButton {
                background-color: #667eea;
                color: white;
                border: none;
                border-radius: 6px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #5568d3;
            }
        """)
        signupBtn.clicked.connect(self._on_signup)
        layout.addWidget(signupBtn)

        form.setLayout(layout)
        return form

    def _show_login_tab(self):
        """Show login form"""
        self.loginForm.show()
        self.signupForm.hide()
        self.loginTabBtn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #667eea;
                border: none;
                border-bottom: 2px solid #667eea;
                padding: 12px 24px;
                font-weight: bold;
            }
            QPushButton:hover {
                color: #5568d3;
                border-bottom: 2px solid #5568d3;
            }
        """)
        self.signupTabBtn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #999999;
                border: none;
                border-bottom: 2px solid transparent;
                padding: 12px 24px;
            }
            QPushButton:hover {
                color: #666666;
            }
        """)

    def _show_signup_tab(self):
        """Show sign up form"""
        self.loginForm.hide()
        self.signupForm.show()
        self.signupTabBtn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #667eea;
                border: none;
                border-bottom: 2px solid #667eea;
                padding: 12px 24px;
                font-weight: bold;
            }
            QPushButton:hover {
                color: #5568d3;
                border-bottom: 2px solid #5568d3;
            }
        """)
        self.loginTabBtn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #999999;
                border: none;
                border-bottom: 2px solid transparent;
                padding: 12px 24px;
            }
            QPushButton:hover {
                color: #666666;
            }
        """)

    def _toggle_login_password_visibility(self):
        """Toggle login password visibility"""
        if self.loginPasswordInput.echoMode() == QLineEdit.Password:
            self.loginPasswordInput.setEchoMode(QLineEdit.Normal)
            self.loginShowPasswordBtn.setText("🙈")
        else:
            self.loginPasswordInput.setEchoMode(QLineEdit.Password)
            self.loginShowPasswordBtn.setText("👁️")

    def _toggle_signup_password_visibility(self):
        """Toggle signup password visibility"""
        if self.signupPasswordInput.echoMode() == QLineEdit.Password:
            self.signupPasswordInput.setEchoMode(QLineEdit.Normal)
            self.signupShowPasswordBtn.setText("🙈")
        else:
            self.signupPasswordInput.setEchoMode(QLineEdit.Password)
            self.signupShowPasswordBtn.setText("👁️")

    def _toggle_signup_confirm_visibility(self):
        """Toggle signup confirm password visibility"""
        if self.signupConfirmInput.echoMode() == QLineEdit.Password:
            self.signupConfirmInput.setEchoMode(QLineEdit.Normal)
            self.signupShowConfirmBtn.setText("🙈")
        else:
            self.signupConfirmInput.setEchoMode(QLineEdit.Password)
            self.signupShowConfirmBtn.setText("👁️")

    def _on_login(self):
        """Handle login"""
        email = self.loginEmailInput.text()
        password = self.loginPasswordInput.text()

        if not email or not password:
            QMessageBox.warning(self, "Validation", "Please enter email and password")
            return

        # Demo authentication
        # Accept several demo credential variants for convenience
        admin_usernames = {"admin@fashion.com", "admin", "administrator"}
        cashier_usernames = {"cashier@fashion.com", "cashier", "kasir"}
        admin_passwords = {"password123", "admin"}
        cashier_passwords = {"password123", "kasir"}

        lower_email = email.strip().lower()
        if lower_email in admin_usernames and password in admin_passwords:
            QMessageBox.information(self, "Success", "Login successful! Welcome back!")
            self.loginSuccessful.emit("Admin User", "admin")
        elif lower_email in cashier_usernames and password in cashier_passwords:
            QMessageBox.information(self, "Success", "Login successful! Welcome back!")
            self.loginSuccessful.emit("Cashier User", "cashier")
        else:
            QMessageBox.warning(self, "Error", "Invalid email or password")

    def _on_signup(self):
        """Handle sign up"""
        name = self.signupNameInput.text()
        email = self.signupEmailInput.text()
        password = self.signupPasswordInput.text()
        confirm = self.signupConfirmInput.text()
        role = self.roleCombo.currentText().lower()

        if not name or not email or not password or not confirm:
            QMessageBox.warning(self, "Validation", "Please fill in all fields")
            return

        if password != confirm:
            QMessageBox.warning(self, "Validation", "Passwords do not match")
            return

        if len(password) < 6:
            QMessageBox.warning(self, "Validation", "Password must be at least 6 characters")
            return

        QMessageBox.information(self, "Success", 
            f"Account created successfully!\n\nName: {name}\nEmail: {email}\nRole: {role}\n\nPlease login with your credentials")
        
        # Clear fields and switch to login
        self.signupNameInput.clear()
        self.signupEmailInput.clear()
        self.signupPasswordInput.clear()
        self.signupConfirmInput.clear()
        self._show_login_tab()