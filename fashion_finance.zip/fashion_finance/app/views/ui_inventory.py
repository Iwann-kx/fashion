from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QFrame, QTableWidget, QTableWidgetItem,
                             QHeaderView, QMessageBox, QScrollArea,
                             QLineEdit, QComboBox)
from PyQt5.QtCore import pyqtSignal, Qt, QTimer
from PyQt5.QtGui import QFont, QColor
from app.components import NavigationHeader
from app.controllers.product_controller import ProductController
from app.utils.helpers import format_currency
from app.views.add_product_dialog import AddProductDialog

class InventoryWindow(QWidget):
    back_clicked = pyqtSignal()
    sales_clicked = pyqtSignal()
    expenses_clicked = pyqtSignal()
    reports_clicked = pyqtSignal()
    settings_clicked = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.table = None
        self.init_ui()

    def init_ui(self):
        """Initialize the UI"""
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Header with navigation
        header = NavigationHeader("inventory", "admin")
        header.dashboard_clicked.connect(self.back_clicked.emit)
        header.sales_clicked.connect(self.sales_clicked.emit)
        header.expenses_clicked.connect(self.expenses_clicked.emit)
        header.reports_clicked.connect(self.reports_clicked.emit)
        header.settings_clicked.connect(self.settings_clicked.emit)
        
        # Scroll area for content
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("""
            QScrollArea { border: none; background-color: #f8f9fa; }
            QScrollBar:vertical { background-color: #e0e0e0; width: 12px; border-radius: 6px; }
            QScrollBar::handle:vertical { background-color: #bdc3c7; border-radius: 6px; min-height: 20px; }
        """)
        
        # Content widget
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(20)
        
        # Title
        page_title = QLabel("Inventori")
        page_title.setFont(QFont("Arial", 24, QFont.Bold))
        page_title.setStyleSheet("color: #2c3e50;")
        
        subtitle = QLabel("Kelola stok dan produk Anda")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7f8c8d;")
        
        content_layout.addWidget(page_title)
        content_layout.addWidget(subtitle)
        
        # Stats cards
        stats_layout = QHBoxLayout()
        stats_data = [
            ("Total Produk", "0", "0 produk", "#3498db", "📦"),
            ("Stok Rendah", "0", "Semua tercukupi", "#e74c3c", "⚠️"),
            ("Nilai Inventori", "Rp 0", "Rp 0", "#27ae60", "💰"),
            ("Kategori Terbanyak", "-", "-", "#9b59b6", "🏷️")
        ]
        for title, value, change, color, icon in stats_data:
            stats_layout.addWidget(self.create_stat_card_large(title, value, change, color, icon))
        stats_layout.addStretch()
        content_layout.addLayout(stats_layout)
        
        # Products table section
        table_section = QFrame()
        table_section.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
                border: 1px solid #e0e0e0;
            }
        """)
        
        table_layout = QVBoxLayout(table_section)
        table_layout.setSpacing(15)
        
        # Table header with title and add button
        table_header = QHBoxLayout()
        table_title = QLabel("Daftar Produk")
        table_title.setFont(QFont("Arial", 18, QFont.Bold))
        table_title.setStyleSheet("color: #2c3e50;")
        
        add_btn = QPushButton("➕ Tambah Produk")
        add_btn.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                color: white;
                padding: 12px 20px;
                border: none;
                border-radius: 8px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #2ecc71; }
        """)
        add_btn.clicked.connect(self.add_product)
        
        table_header.addWidget(table_title)
        table_header.addStretch()
        table_header.addWidget(add_btn)
        
        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels(["PRODUK", "KATEGORI", "STOK", "HARGA", "GAMBAR", "STATUS", "AKSI"])
        self.table.setStyleSheet("""
            QTableWidget {
                background-color: white;
                border: none;
                gridline-color: #e9ecef;
                font-size: 14px;
                border-radius: 8px;
                alternate-background-color: #f8f9fa;
            }
            QTableWidget::item {
                padding: 16px 12px;
                border-bottom: 1px solid #e9ecef;
                font-size: 13px;
            }
            QTableWidget::item:selected { background-color: #3498db; color: white; }
            QHeaderView::section {
                background-color: #2c3e50;
                color: white;
                padding: 16px 12px;
                border: none;
                border-bottom: 2px solid #e9ecef;
                font-weight: bold;
                font-size: 13px;
            }
        """)
        self.table.verticalHeader().setDefaultSectionSize(65)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setMinimumHeight(400)
        
        table_layout.addLayout(table_header)
        table_layout.addWidget(self.table)
        
        content_layout.addWidget(table_section)
        content_layout.addStretch()
        
        scroll_area.setWidget(content_widget)
        
        main_layout.addWidget(header)
        main_layout.addWidget(scroll_area, 1)
        
        self.setLayout(main_layout)
        self.setStyleSheet("background-color: #f8f9fa;")
        self.load_data()

    def create_stat_card_large(self, title, value, change, color, icon):
        card = QFrame()
        card.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 25px;
                border: 1px solid #e0e0e0;
            }
            QFrame:hover {
                border: 1px solid #bdc3c7;
            }
        """)
        card.setMinimumHeight(350)
        card.setMinimumWidth(400)
        
        layout = QVBoxLayout(card)
        layout.setSpacing(8)
        
        # Header with icon
        header_layout = QHBoxLayout()
        icon_label = QLabel(icon)
        icon_label.setFont(QFont("Arial", 16))
        icon_label.setStyleSheet(f"color: {color};")
        
        card_title = QLabel(title)
        card_title.setFont(QFont("Arial", 12))
        card_title.setStyleSheet("color: #7f8c8d;")
        
        header_layout.addWidget(icon_label)
        header_layout.addWidget(card_title)
        header_layout.addStretch()
        
        # Value
        value_label = QLabel(value)
        value_label.setFont(QFont("Arial", 18, QFont.Bold))
        value_label.setStyleSheet(f"color: {color}; margin-top: 5px;")
        
        # Change indicator
        change_label = QLabel(change)
        change_label.setFont(QFont("Arial", 11))
        change_label.setStyleSheet("color: #7f8c8d; font-weight: bold;")
        
        layout.addLayout(header_layout)
        layout.addWidget(value_label)
        layout.addWidget(change_label)
        layout.addStretch()
        
        return card

    def load_data(self):
        # Clear table
        self.table.setRowCount(0)
        
        # Get products from controller
        products = ProductController.get_all_products()
        
        # Populate table
        for product in products:
            row = self.table.rowCount()
            self.table.insertRow(row)
            
            # Create items
            name_item = QTableWidgetItem(product['nama_produk'])
            name_item.setFont(QFont("Arial", 13, QFont.Bold))
            
            cat_item = QTableWidgetItem(product['kategori'])
            
            stok_val = product['stok']
            stok_item = QTableWidgetItem(f"{stok_val} pcs")
            if stok_val < 5:
                stok_item.setForeground(QColor("#e74c3c"))
                stok_item.setFont(QFont("Arial", 13, QFont.Bold))
            
            price_item = QTableWidgetItem(format_currency(product['harga_jual']))
            
            img_item = QTableWidgetItem("📷 Lihat")
            img_item.setForeground(QColor("#3498db"))
            
            status_item = QTableWidgetItem("✅ Aktif" if product['status'] == 'aktif' else "❌ Nonaktif")
            if product['status'] == 'aktif':
                status_item.setForeground(QColor("#27ae60"))
            else:
                status_item.setForeground(QColor("#7f8c8d"))
                
            # Action buttons cell
            action_widget = QWidget()
            action_layout = QHBoxLayout(action_widget)
            action_layout.setContentsMargins(5, 5, 5, 5)
            action_layout.setSpacing(10)
            
            edit_btn = QPushButton("✏️")
            edit_btn.setFixedSize(30, 30)
            edit_btn.setToolTip("Edit Produk")
            edit_btn.setStyleSheet("background-color: #f39c12; color: white; border-radius: 4px;")
            edit_btn.clicked.connect(lambda checked, p=product: self.edit_product(p))
            
            delete_btn = QPushButton("🗑️")
            delete_btn.setFixedSize(30, 30)
            delete_btn.setToolTip("Hapus Produk")
            delete_btn.setStyleSheet("background-color: #e74c3c; color: white; border-radius: 4px;")
            delete_btn.clicked.connect(lambda checked, p=product: self.delete_product(p))
            
            action_layout.addWidget(edit_btn)
            action_layout.addWidget(delete_btn)
            action_layout.addStretch()
            
            # Set items
            self.table.setItem(row, 0, name_item)
            self.table.setItem(row, 1, cat_item)
            self.table.setItem(row, 2, stok_item)
            self.table.setItem(row, 3, price_item)
            self.table.setItem(row, 4, img_item)
            self.table.setItem(row, 5, status_item)
            self.table.setCellWidget(row, 6, action_widget)

    def add_product(self):
        dialog = AddProductDialog(self)
        if dialog.exec_():
            # Reload data
            self.load_data()
            QMessageBox.information(self, "Sukses", "Produk berhasil ditambahkan!")

    def edit_product(self, product_data):
        dialog = AddProductDialog(self, product_data)
        if dialog.exec_():
            # Reload data
            self.load_data()
            QMessageBox.information(self, "Sukses", "Produk berhasil diperbarui!")

    def delete_product(self, product_data):
        reply = QMessageBox.question(self, 'Konfirmasi Hapus', 
                                   f"Apakah Anda yakin ingin menghapus produk '{product_data['nama_produk']}'?",
                                   QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            if ProductController.delete_product(product_data['id']):
                self.load_data()
                QMessageBox.information(self, "Sukses", "Produk berhasil dihapus!")
            else:
                QMessageBox.warning(self, "Error", "Gagal menghapus produk")

    def back_to_login(self):
        """Handle logout"""
        reply = QMessageBox.question(self, "Konfirmasi", 
                                   "Apakah Anda yakin ingin logout?",
                                   QMessageBox.Yes | QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            self.logout_clicked.emit()