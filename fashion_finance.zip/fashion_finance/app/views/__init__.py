"""Views module - UI components"""

