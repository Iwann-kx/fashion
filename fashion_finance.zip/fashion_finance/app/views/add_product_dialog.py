"""Product Dialog View - Refactored with FormDialog base class"""

from PyQt5.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QFrame, 
                             QPushButton, QFileDialog, QMessageBox)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QColor, QPixmap
from app.components.dialogs import FormDialog
from app.components.inputs import StyledLineEdit, StyledComboBox, StyledSpinBox
import os


class ProductImageSection(QFrame):
    """Component for product image upload and display"""
    
    def __init__(self):
        super().__init__()
        self.selected_image_path = None
        self.init_ui()
    
    def init_ui(self):
        """Initialize image section UI"""
        self.setStyleSheet("""
            QFrame {
                background-color: #f8f9fa;
                border: 0px solid #e0e0e0;
                border-radius: 0px;
                padding: 0px;
            }
        """)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        
        # Title
        title = QLabel("🖼️ Gambar Produk")
        title.setFont(QFont("Arial", 11, QFont.Bold))
        title.setStyleSheet("color: #2c3e50; padding none;")
        
        # Image display frame
        image_frame = QFrame()
        image_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border: none;
                border-radius: 8px;
            }
        """)
        image_frame.setFixedSize(200, 200)
        
        frame_layout = QVBoxLayout(image_frame)
        frame_layout.setAlignment(Qt.AlignCenter)
        
        self.image_label = QLabel()
        self.image_label.setMinimumSize(150, 150)
        self.image_label.setMaximumSize(400, 400)
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setStyleSheet("background-color: transparent;")
        self.image_label.setText("📷\nKlik untuk\nmemilih gambar")
        self.image_label.mousePressEvent = lambda e: self.select_image()
        self.image_label.setCursor(Qt.PointingHandCursor)
        
        frame_layout.addWidget(self.image_label)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        select_btn = self._create_button("📁 Pilih Gambar", "#3498db", "#2980b9")
        select_btn.clicked.connect(self.select_image)
        
        clear_btn = self._create_button("🗑️ Hapus", "#e74c3c", "#c0392b")
        clear_btn.clicked.connect(self.clear_image)
        
        button_layout.addWidget(select_btn)
        button_layout.addWidget(clear_btn)
        
        layout.addWidget(title)
        layout.addWidget(image_frame, 0, Qt.AlignCenter)
        layout.addLayout(button_layout)
    
    @staticmethod
    def _create_button(text, bg_color, hover_color):
        """Create styled button"""
        btn = QPushButton(text)
        btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {bg_color};
                color: white;
                padding: 8px 12px;
                border: none;
                border-radius: 6px;
                font-size: 11px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {hover_color};
            }}
        """)
        return btn
    
    def select_image(self):
        """Open file dialog to select image"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, 
            "Pilih Gambar Produk", 
            "", 
            "Image Files (*.png *.jpg *.jpeg *.bmp *.gif)"
        )
        
        if file_path:
            self.selected_image_path = file_path
            self.load_image(file_path)
    
    def load_image(self, image_path):
        """Load and display image"""
        if os.path.exists(image_path):
            pixmap = QPixmap(image_path)
            scaled_pixmap = pixmap.scaled(120, 120, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.image_label.setPixmap(scaled_pixmap)
            self.image_label.setText("")
        else:
            self.image_label.setText("❌\nGambar\ntidak ditemukan")
    
    def clear_image(self):
        """Clear selected image"""
        self.selected_image_path = None
        self.image_label.clear()
        self.image_label.setText("📷\nKlik untuk\nmemilih gambar")
    
    def get_image_path(self):
        """Get selected image path"""
        return self.selected_image_path
    
    def set_image_path(self, image_path):
        """Set and display image"""
        if image_path and os.path.exists(image_path):
            self.selected_image_path = image_path
            self.load_image(image_path)


class AddProductDialog(FormDialog):
    """Dialog for adding/editing products using FormDialog base class"""
    
    CATEGORIES = ["Dress", "Kemeja", "Celana", "Aksesoris", "Sepatu", "Jaket"]
    
    def __init__(self, parent=None, product_data=None):
        self.product_data = product_data
        self.is_edit = product_data is not None
        
        title = "✏️ Edit Produk" if self.is_edit else "➕ Tambah Produk"
        
        # Configure form fields
        fields_config = [
            {
                'name': 'name',
                'label': '📝 Nama Produk',
                'type': 'text',
                'placeholder': 'Nama produk',
                'required': True
            },
            {
                'name': 'category',
                'label': '📂 Kategori',
                'type': 'combo',
                'items': self.CATEGORIES,
                'required': True
            },
            {
                'name': 'stock',
                'label': '📊 Stok',
                'type': 'number',
                'min': 0,
                'max': 1000,
                'required': True
            },
            {
                'name': 'price',
                'label': '💰 Harga',
                'type': 'text',
                'placeholder': 'Contoh: 120000 (tanpa titik/koma)',
                'required': True
            },
            {
                'name': 'Kode Produk',
                'label': '🏷️ SKU',
                'type': 'text',
                'placeholder': 'Kode Produk',
                'required': True
            }
        ]
        
        # Prepare data for pre-filling
        data = self._prepare_product_data()
        
        super().__init__(title, fields_config, data, parent)
        self._setup_image_section()
    
    def _prepare_product_data(self):
        """Extract and prepare product data for form pre-filling"""
        data = {}
        if self.is_edit and self.product_data:
            try:
                # Product tuple format: (id, name, category, stock, price, sku, user_id, placeholder, image, status)
                data['name'] = str(self.product_data[1])
                data['category'] = str(self.product_data[2])
                data['stock'] = int(self.product_data[3])
                data['price'] = str(int(self.product_data[4]))
                data['Kode Produk'] = str(self.product_data[5])
            except (ValueError, IndexError, TypeError) as e:
                print(f"Error loading product data: {e}")
        
        return data
    
    def _setup_image_section(self):
        """Setup the image upload section"""
        self.image_section = ProductImageSection()
        
        # Add image section before buttons in the content layout
        self.content_layout.insertWidget(0, self.image_section)
        
        # Load existing image if editing
        if self.is_edit and self.product_data and len(self.product_data) > 8:
            if self.product_data[8]:  # Image path at index 8
                self.image_section.set_image_path(self.product_data[8])
    
    def validate_and_accept(self):
        """Custom validation for product form"""
        # Run parent validation first
        try:
            super().validate_and_accept()
        except:
            return
        
        # Additional validation for price
        try:
            price_text = self.fields['price'].text().replace('.', '').replace(',', '')
            price = int(price_text)
            if price <= 0:
                self.show_error("Harga harus lebih dari 0!")
                return
        except ValueError:
            self.show_error("Format harga tidak valid! Gunakan angka saja.")
            return
        
        # Price validation passed, accept the dialog
        self.accept()
    
    def get_data(self):
        """Get product form data"""
        data = super().get_data()
        
        # Convert price to integer
        try:
            price_text = data['price'].replace('.', '').replace(',', '')
            data['price'] = int(price_text)
        except ValueError:
            data['price'] = 0
        
        # Add image path
        data['image_path'] = self.image_section.get_image_path()
        
        return data
