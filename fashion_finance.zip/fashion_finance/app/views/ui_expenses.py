"""Expenses View - Complete with all features for expense management"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QScrollArea, QMessageBox, QFrame, QDialog,
                             QLineEdit, QComboBox, QDateEdit, QDialogButtonBox, QTableWidget, QTableWidgetItem,
                             QPushButton, QHeaderView, QSpinBox)
from PyQt5.QtCore import pyqtSignal, Qt, QDate, QTimer
from PyQt5.QtGui import QFont
from app.components import NavigationHeader, StatCard
from app.components.buttons import PrimaryButton
from app.controllers.expense_controller import ExpenseController
from app.utils.helpers import format_currency
from datetime import datetime


class AddExpenseDialog(QDialog):
    """Dialog for adding/editing expenses"""
    
    def __init__(self, parent=None, expense_data=None):
        super().__init__(parent)
        self.expense_data = expense_data
        self.init_ui()
    
    def init_ui(self):
        """Initialize the dialog UI"""
        title = '✏️ Edit Pengeluaran' if self.expense_data else '➕ Tambah Pengeluaran'
        self.setWindowTitle(title)
        self.setFixedSize(700, 500)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Title section
        heading = QLabel(title)
        heading.setFont(QFont('Arial', 16, QFont.Bold))
        heading.setStyleSheet('color: #2c3e50; background-color: #ecf0f1; padding: 15px; border-radius: 8px;')
        layout.addWidget(heading)
        
        # Tanggal
        date_label = QLabel('📅 TANGGAL')
        date_label.setFont(QFont('Arial', 12, QFont.Bold))
        date_label.setStyleSheet('color: #2c3e50; background-color: #f8f9fa; padding: 8px; border-radius: 4px;')
        
        self.date_edit = QDateEdit()
        self.date_edit.setDate(QDate.currentDate())
        self.date_edit.setStyleSheet('QDateEdit { padding: 10px; border: 2px solid #e0e0e0; border-radius: 6px; }')
        
        layout.addWidget(date_label)
        layout.addWidget(self.date_edit)
        
        # Deskripsi
        desc_label = QLabel('📝 DESKRIPSI')
        desc_label.setFont(QFont('Arial', 12, QFont.Bold))
        desc_label.setStyleSheet('color: #2c3e50; background-color: #f8f9fa; padding: 8px; border-radius: 4px;')
        
        self.desc_input = QLineEdit()
        self.desc_input.setPlaceholderText('Contoh: Pembelian bahan baku kain')
        self.desc_input.setStyleSheet('QLineEdit { padding: 10px; border: 2px solid #e0e0e0; border-radius: 6px; }')
        
        layout.addWidget(desc_label)
        layout.addWidget(self.desc_input)
        
        # Kategori
        cat_label = QLabel('📂 KATEGORI')
        cat_label.setFont(QFont('Arial', 12, QFont.Bold))
        cat_label.setStyleSheet('color: #2c3e50; background-color: #f8f9fa; padding: 8px; border-radius: 4px;')
        
        self.category_combo = QComboBox()
        self.category_combo.addItems(['Bahan Baku', 'Operasional', 'Marketing', 'Utilitas', 'Transportasi', 'Lainnya'])
        self.category_combo.setStyleSheet('QComboBox { padding: 10px; border: 2px solid #e0e0e0; border-radius: 6px; }')
        
        layout.addWidget(cat_label)
        layout.addWidget(self.category_combo)
        
        # Jumlah
        amount_label = QLabel('💰 JUMLAH')
        amount_label.setFont(QFont('Arial', 12, QFont.Bold))
        amount_label.setStyleSheet('color: #2c3e50; background-color: #f8f9fa; padding: 8px; border-radius: 4px;')
        
        self.amount_input = QLineEdit()
        self.amount_input.setPlaceholderText('Contoh: 500000')
        self.amount_input.setStyleSheet('QLineEdit { padding: 10px; border: 2px solid #e0e0e0; border-radius: 6px; }')
        
        layout.addWidget(amount_label)
        layout.addWidget(self.amount_input)
        
        # Status
        status_label = QLabel('📊 STATUS PEMBAYARAN')
        status_label.setFont(QFont('Arial', 12, QFont.Bold))
        status_label.setStyleSheet('color: #2c3e50; background-color: #f8f9fa; padding: 8px; border-radius: 4px;')
        
        self.status_combo = QComboBox()
        self.status_combo.addItems(['Lunas', 'Pending'])
        self.status_combo.setStyleSheet('QComboBox { padding: 10px; border: 2px solid #e0e0e0; border-radius: 6px; }')
        
        layout.addWidget(status_label)
        layout.addWidget(self.status_combo)
        
        layout.addStretch()
        
        # Buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.setStyleSheet('''
            QPushButton {
                padding: 12px 24px;
                border: none;
                border-radius: 6px;
                font-weight: bold;
                min-width: 100px;
            }
            QPushButton[text="OK"] {
                background-color: #e74c3c;
                color: white;
            }
            QPushButton[text="OK"]:hover {
                background-color: #c0392b;
            }
            QPushButton[text="Cancel"] {
                background-color: #95a5a6;
                color: white;
            }
            QPushButton[text="Cancel"]:hover {
                background-color: #7f8c8d;
            }
        ''')
        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
        if self.expense_data:
            self.load_data()
    
    def load_data(self):
        """Load expense data for editing"""
        if len(self.expense_data) >= 6:
            self.date_edit.setDate(QDate.fromString(str(self.expense_data[1]), 'yyyy-MM-dd'))
            self.desc_input.setText(str(self.expense_data[2]))
            self.category_combo.setCurrentText(str(self.expense_data[3]))
            self.amount_input.setText(str(self.expense_data[4]))
            self.status_combo.setCurrentText(str(self.expense_data[5]))
    
    def validate_and_accept(self):
        """Validate form before accepting"""
        if not self.desc_input.text():
            QMessageBox.warning(self, 'Error', 'Deskripsi tidak boleh kosong!')
            return
        try:
            amount = int(self.amount_input.text())
            if amount <= 0:
                QMessageBox.warning(self, 'Error', 'Jumlah harus lebih dari 0!')
                return
        except ValueError:
            QMessageBox.warning(self, 'Error', 'Jumlah harus berupa angka!')
            return
        self.accept()
    
    def get_data(self):
        """Get form data"""
        return {
            'date': self.date_edit.date().toString('yyyy-MM-dd'),
            'description': self.desc_input.text(),
            'category': self.category_combo.currentText(),
            'amount': int(self.amount_input.text()),
            'status': self.status_combo.currentText()
        }


class ExpensesWindow(QWidget):
    """Expenses management window"""
    
    # Signals for navigation
    back_clicked = pyqtSignal()
    inventory_clicked = pyqtSignal()
    sales_clicked = pyqtSignal()
    reports_clicked = pyqtSignal()
    settings_clicked = pyqtSignal()
    logout_clicked = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.user_role = 'admin'
        self.refresh_timer = None
        self.init_ui()
    
    def init_ui(self):
        """Initialize the window UI"""
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Header with navigation
        header = NavigationHeader('expenses', self.user_role)
        header.dashboard_clicked.connect(self.back_clicked.emit)
        header.inventory_clicked.connect(self.inventory_clicked.emit)
        header.sales_clicked.connect(self.sales_clicked.emit)
        header.reports_clicked.connect(self.reports_clicked.emit)
        header.settings_clicked.connect(self.settings_clicked.emit)
        header.logout_clicked.connect(self.logout_clicked.emit)
        
        # Scroll area for content
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet('QScrollArea { border: none; background-color: #f8f9fa; }')
        
        # Main content widget
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(20)
        
        # Page title with action button
        
        title_layout = QHBoxLayout()
        page_title = QLabel('💸 Pengeluaran')
        page_title.setFont(QFont('Arial', 28, QFont.Bold))
        page_title.setStyleSheet('color: #2c3e50;')
        
        title_layout.addWidget(page_title)
        title_layout.addStretch()
        
        subtitle = QLabel('Kelola dan catat semua pengeluaran bisnis')
        subtitle.setFont(QFont('Arial', 12))
        subtitle.setStyleSheet('color: #7f8c8d;')
        content_layout.addWidget(subtitle)

        add_btn = PrimaryButton('Tambah Pengeluaran', '➕')
        add_btn.clicked.connect(self.add_expense)
        title_layout.addWidget(add_btn)
        
        content_layout.addLayout(title_layout)
        
        # Stat cards layout
        self.stats_layout = QHBoxLayout()
        self.stats_layout.setSpacing(20)
        content_layout.addLayout(self.stats_layout)
        
        # Expenses table frame
        table_frame = QFrame()
        table_frame.setStyleSheet('QFrame { background-color: white; border-radius: 12px; padding: 20px; border: 1px solid #e0e0e0; }')
        
        table_layout = QVBoxLayout(table_frame)
        table_layout.setSpacing(15)
        
        table_header_layout = QHBoxLayout()
        table_title = QLabel('📋 Daftar Pengeluaran')
        table_title.setFont(QFont('Arial', 18, QFont.Bold))
        table_title.setStyleSheet('color: #2c3e50;')
        table_header_layout.addWidget(table_title)
        table_header_layout.addStretch()
        
        refresh_btn = QPushButton('🔄 Refresh')
        refresh_btn.setMaximumWidth(120)
        refresh_btn.setStyleSheet('QPushButton { background-color: #3498db; color: white; padding: 8px 16px; border-radius: 4px; font-weight: bold; }')
        refresh_btn.clicked.connect(self.load_data)
        table_header_layout.addWidget(refresh_btn)
        
        # Expenses table
        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels(['TANGGAL', 'DESKRIPSI', 'KATEGORI', 'JUMLAH', 'STATUS', 'EDIT', 'HAPUS', ''])
        # Expenses table - single action column like inventory
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(['TANGGAL', 'DESKRIPSI', 'KATEGORI', 'JUMLAH', 'STATUS', 'AKSI'])
        self.table.setStyleSheet('''
            QTableWidget {
                background-color: white;
                border: none;
                gridline-color: #e0e0e0;
            }
            QHeaderView::section {
                background-color: #2c3e50;
                color: white;
                padding: 12px;
                border: none;
                font-weight: bold;
            }
            QTableWidget::item {
                padding: 8px;
            }
        ''')
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setRowCount(0)
        
        table_layout.addLayout(table_header_layout)
        table_layout.addWidget(self.table)
        
        content_layout.addWidget(table_frame)
        content_layout.addStretch()
        
        scroll_area.setWidget(content_widget)
        
        main_layout.addWidget(header)
        main_layout.addWidget(scroll_area, 1)
        
        self.setLayout(main_layout)
        self.setStyleSheet('background-color: #f8f9fa;')
        
        # Setup auto-refresh timer
        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self.load_data)
        self.refresh_timer.start(30000)  # Refresh every 30 seconds
        
        self.load_data()
    
    def add_expense(self):
        """Add new expense"""
        dialog = AddExpenseDialog(self)
        if dialog.exec_():
            data = dialog.get_data()
            try:
                success, result = ExpenseController.create_expense(
                    tanggal=data['date'],
                    deskripsi=data['description'],
                    kategori=data['category'],
                    jumlah=data['amount'],
                    status=data['status']
                )
                
                if success:
                    QMessageBox.information(self, 'Sukses', 'Pengeluaran berhasil ditambahkan!')
                    self.load_data()
                else:
                    QMessageBox.warning(self, 'Error', 'Gagal menambah pengeluaran: ' + str(result))
            except Exception as e:
                QMessageBox.warning(self, 'Error', 'Error: ' + str(e))
    
    def load_data(self):
        """Load expense data into table"""
        # keep current expenses for row->id mapping
        self.current_expenses = []
        # Clear existing stat cards
        while self.stats_layout.count():
            child = self.stats_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
        
        # Create stat cards
        stats_data = [
            ('Total Pengeluaran', 'Rp 0', 'Rp 0', '#e74c3c', '💸'),
            ('Pengeluaran Hari Ini', 'Rp 0', '0 item', '#c0392b', '📊'),
            ('Rata-rata Harian', 'Rp 0', 'Rp 0', '#e67e22', '📈'),
            ('Kategori Terbesar', '-', 'Rp 0', '#d35400', '📂')
        ]
        
        for title, value, change, color, icon in stats_data:
            card = StatCard(title, value, change, color, icon)
            self.stats_layout.addWidget(card)
        
        self.stats_layout.addStretch()
        
        # Load expense data
        try:
            expenses = ExpenseController.get_all_expenses()
            # store for later operations (edit/delete)
            self.current_expenses = expenses or []
            self.table.setRowCount(len(self.current_expenses))

            for row, expense in enumerate(self.current_expenses):
                tanggal = str(expense.get('tanggal', '')).split()[0]
                deskripsi = str(expense.get('deskripsi', ''))
                kategori = str(expense.get('kategori', ''))
                jumlah = format_currency(expense.get('jumlah', 0))
                status = str(expense.get('status', ''))

                self.table.setItem(row, 0, QTableWidgetItem(tanggal))
                self.table.setItem(row, 1, QTableWidgetItem(deskripsi))
                self.table.setItem(row, 2, QTableWidgetItem(kategori))
                self.table.setItem(row, 3, QTableWidgetItem(jumlah))
                self.table.setItem(row, 4, QTableWidgetItem(status))

                # Action widget (small icon buttons)
                action_widget = QWidget()
                action_layout = QHBoxLayout(action_widget)
                action_layout.setContentsMargins(5, 5, 5, 5)
                action_layout.setSpacing(8)

                edit_btn = QPushButton('✏️')
                edit_btn.setFixedSize(30, 30)
                edit_btn.setStyleSheet('background-color: #3498db; color: white; border-radius: 4px;')
                edit_btn.clicked.connect(lambda checked, e=expense: self.edit_expense_by_obj(e))

                delete_btn = QPushButton('🗑️')
                delete_btn.setFixedSize(30, 30)
                delete_btn.setStyleSheet('background-color: #e74c3c; color: white; border-radius: 4px;')
                delete_btn.clicked.connect(lambda checked, e=expense: self.delete_expense_by_obj(e))

                action_layout.addWidget(edit_btn)
                action_layout.addWidget(delete_btn)
                action_layout.addStretch()
                self.table.setCellWidget(row, 5, action_widget)
        except Exception as e:
            print('Error loading expenses: ' + str(e))
    
    def edit_expense(self, row):
        """Edit an expense"""
        # Use stored expense object for accurate id and fields
        try:
            expense = self.current_expenses[row]
        except Exception:
            QMessageBox.warning(self, 'Error', 'Data pengeluaran tidak ditemukan untuk baris ini.')
            return

        expense_tuple = (
            expense.get('id'),
            expense.get('tanggal'),
            expense.get('deskripsi'),
            expense.get('kategori'),
            expense.get('jumlah'),
            expense.get('status')
        )

        dialog = AddExpenseDialog(self, expense_tuple)
        if dialog.exec_():
            data = dialog.get_data()
            try:
                success, result = ExpenseController.update_expense(
                    expense.get('id'),
                    tanggal=data['date'],
                    deskripsi=data['description'],
                    kategori=data['category'],
                    jumlah=int(data['amount']),
                    status=data['status']
                )
                if success:
                    QMessageBox.information(self, 'Sukses', 'Pengeluaran berhasil diperbarui!')
                    self.load_data()
                else:
                    QMessageBox.warning(self, 'Error', 'Gagal memperbarui pengeluaran: ' + str(result))
            except Exception as e:
                QMessageBox.warning(self, 'Error', 'Error: ' + str(e))

    def edit_expense_by_obj(self, expense):
        """Edit expense using expense object"""
        if not expense:
            QMessageBox.warning(self, 'Error', 'Data pengeluaran tidak valid.')
            return

        expense_tuple = (
            expense.get('id'),
            expense.get('tanggal'),
            expense.get('deskripsi'),
            expense.get('kategori'),
            expense.get('jumlah'),
            expense.get('status')
        )

        dialog = AddExpenseDialog(self, expense_tuple)
        if dialog.exec_():
            data = dialog.get_data()
            try:
                success, result = ExpenseController.update_expense(
                    expense.get('id'),
                    tanggal=data['date'],
                    deskripsi=data['description'],
                    kategori=data['category'],
                    jumlah=int(data['amount']),
                    status=data['status']
                )
                if success:
                    QMessageBox.information(self, 'Sukses', 'Pengeluaran berhasil diperbarui!')
                    self.load_data()
                else:
                    QMessageBox.warning(self, 'Error', 'Gagal memperbarui pengeluaran: ' + str(result))
            except Exception as e:
                QMessageBox.warning(self, 'Error', 'Error: ' + str(e))

    def delete_expense_by_obj(self, expense):
        """Delete expense using expense object"""
        if not expense:
            QMessageBox.warning(self, 'Error', 'Data pengeluaran tidak valid.')
            return

        reply = QMessageBox.question(self, 'Konfirmasi Hapus', f"Yakin ingin menghapus pengeluaran '{expense.get('deskripsi')}'?", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            try:
                success, result = ExpenseController.delete_expense(expense.get('id'))
                if success:
                    QMessageBox.information(self, 'Sukses', 'Pengeluaran berhasil dihapus!')
                    self.load_data()
                else:
                    QMessageBox.warning(self, 'Error', 'Gagal menghapus pengeluaran: ' + str(result))
            except Exception as e:
                QMessageBox.warning(self, 'Error', 'Error: ' + str(e))
    
    def delete_expense(self, row):
        """Delete an expense"""
        reply = QMessageBox.question(
            self,
            'Konfirmasi Hapus',
            'Apakah Anda yakin ingin menghapus pengeluaran ini?',
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            try:
                expense = self.current_expenses[row]
            except Exception:
                QMessageBox.warning(self, 'Error', 'Data pengeluaran tidak ditemukan untuk baris ini.')
                return

            try:
                success, result = ExpenseController.delete_expense(expense.get('id'))
                if success:
                    QMessageBox.information(self, 'Sukses', 'Pengeluaran berhasil dihapus!')
                    self.load_data()
                else:
                    QMessageBox.warning(self, 'Error', 'Gagal menghapus pengeluaran: ' + str(result))
            except Exception as e:
                QMessageBox.warning(self, 'Error', 'Error: ' + str(e))
    
    def set_user_role(self, role):
        """Set user role for view customization"""
        self.user_role = role
    
    def closeEvent(self, event):
        """Clean up timer on close"""
        if self.refresh_timer:
            self.refresh_timer.stop()
        super().closeEvent(event)
