# setup.py
from setup_database import create_database_schema
from insert_sample_data import insert_sample_data

def setup_system():
    """Setup sistem database"""
    print("SETUP SISTEM DATABASE TOKO")
    print("=" * 50)
    
    # Buat skema database
    print("1. Membuat skema database...")
    create_database_schema()
    
    # Insert sample data
    print("\n2. Memasukkan data sample...")
    insert_sample_data()
    
    print("\n✅ Setup berhasil! Jalankan 'python main.py' untuk menjalankan aplikasi.")

if __name__ == "__main__":
    setup_system()