# database_operations.py
import mysql.connector
from mysql.connector import Error

def test_connection():
    """Test koneksi ke database"""
    try:
        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='fashion_finance'
        )
        
        if connection.is_connected():
            print("✅ Koneksi database berhasil!")
            return True
            
    except Error as e:
        print(f"❌ Koneksi database gagal: {e}")
        return False
    finally:
        if 'connection' in locals() and connection.is_connected():
            connection.close()

def main():
    """Fungsi utama untuk menjalankan aplikasi"""
    print("🚀 Menjalankan Aplikasi Fashion Finance...")
    
    # Test koneksi terlebih dahulu
    if test_connection():
        print("✅ Aplikasi siap dijalankan!")
        print("\n📋 Informasi Database:")
        print("   - Host: localhost")
        print("   - Database: fashion_finance")
        print("   - User: root")
        print("\n🎯 Silakan jalankan aplikasi utama untuk melanjutkan...")
    else:
        print("❌ Tidak dapat menjalankan aplikasi. Periksa koneksi database.")