from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QFrame, QGridLayout, QScrollArea)
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QFont
from database import db

class DashboardWindow(QWidget):
    inventory_clicked = pyqtSignal()
    sales_clicked = pyqtSignal()
    expenses_clicked = pyqtSignal()
    reports_clicked = pyqtSignal()
    settings_clicked = pyqtSignal()
    logout_clicked = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.user_role = "kasir"  # Default role
        self.init_ui()
        
    def init_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Header - SEPERTI YANG LAIN
        header = self.create_header()
        
        # Content dengan scroll area - SEPERTI YANG LAIN
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setStyleSheet("""
            QScrollArea { 
                border: none; 
                background-color: #f8f9fa;
            }
            QScrollBar:vertical {
                background-color: #e0e0e0;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background-color: #bdc3c7;
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #95a5a6;
            }
        """)
        
        # Content widget utama - SEPERTI YANG LAIN
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(20)
        
        # Page title - SEPERTI YANG LAIN
        page_title = QLabel("Dasbor")
        page_title.setFont(QFont("Arial", 24, QFont.Bold))
        page_title.setStyleSheet("color: #2c3e50; margin-bottom: 5px;")
        
        subtitle = QLabel("Ringkasan keuangan bisnis fashion Anda")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7f8c8d;")
        
        content_layout.addWidget(page_title)
        content_layout.addWidget(subtitle)
        
        # Stats section - SEPERTI YANG LAIN (satu baris horizontal)
        stats_layout = QHBoxLayout()
        stats_layout.setSpacing(20)

        stats_data = [
            ("Total Penjualan", "Rp 15.750.000", "+8% dari bulan lalu", "#27ae60", "📈"),
            ("Total Pengeluaran", "Rp 8.250.000", "+5% dari bulan lalu", "#e74c3c", "📉"), 
            ("Keuntungan Bersih", "Rp 7.500.000", "+12% dari bulan lalu", "#2980b9", "💰"),
            ("Stok Produk", "245 pcs", "+15 dari bulan lalu", "#f39c12", "📦")
        ]

        for title, value, change, color, icon in stats_data:
            stat_card = self.create_stat_card_large(title, value, change, color, icon)
            stats_layout.addWidget(stat_card)

        stats_layout.addStretch()
        content_layout.addLayout(stats_layout)
        
        # Bottom sections - SEPERTI YANG LAIN
        bottom_layout = QHBoxLayout()
        bottom_layout.setSpacing(20)
        
        # Recent sales - SEPERTI YANG LAIN
        recent_sales_frame = QFrame()
        recent_sales_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
                border: 1px solid #e0e0e0;
            }
        """)
        recent_sales_frame.setMinimumWidth(500)
        recent_sales_frame.setMinimumHeight(400)
        
        recent_layout = QVBoxLayout(recent_sales_frame)
        recent_layout.setSpacing(15)
        
        recent_title = QLabel("🛍️ Penjualan Terbaru")
        recent_title.setFont(QFont("Arial", 18, QFont.Bold))
        recent_title.setStyleSheet("color: #2c3e50; margin-bottom: 10px;")
        
        self.recent_sales_content = QVBoxLayout()
        self.recent_sales_content.setSpacing(12)
        
        recent_layout.addWidget(recent_title)
        recent_layout.addLayout(self.recent_sales_content)
        recent_layout.addStretch()
        
        # Best sellers - SEPERTI YANG LAIN
        best_sellers_frame = QFrame()
        best_sellers_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
                border: 1px solid #e0e0e0;
            }
        """)
        best_sellers_frame.setMinimumWidth(500)
        best_sellers_frame.setMinimumHeight(400)
        
        best_layout = QVBoxLayout(best_sellers_frame)
        best_layout.setSpacing(15)
        
        best_title = QLabel("🏆 Produk Terlaris")
        best_title.setFont(QFont("Arial", 18, QFont.Bold))
        best_title.setStyleSheet("color: #2c3e50; margin-bottom: 10px;")
        
        self.best_sellers_content = QVBoxLayout()
        self.best_sellers_content.setSpacing(12)
        
        best_layout.addWidget(best_title)
        best_layout.addLayout(self.best_sellers_content)
        best_layout.addStretch()
        
        bottom_layout.addWidget(recent_sales_frame)
        bottom_layout.addWidget(best_sellers_frame)
        
        # Add all to content layout
        content_layout.addLayout(stats_layout)
        content_layout.addSpacing(20)
        content_layout.addLayout(bottom_layout)
        content_layout.addStretch()
        
        # Set content widget to scroll area
        scroll_area.setWidget(content_widget)
        
        # Add to main layout
        main_layout.addWidget(header)
        main_layout.addWidget(scroll_area, 1)
        
        self.setLayout(main_layout)
        self.setStyleSheet("background-color: #f8f9fa;")
        self.load_data()

    def create_stat_card_large(self, title, value, change, color, icon):
        """Membuat stat card besar dengan icon seperti yang lain"""
        stat_frame = QFrame()
        stat_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 25px;
                border: 1px solid #e0e0e0;
            }
        """)
        stat_frame.setMinimumHeight(120)
        stat_frame.setMinimumWidth(280)
        
        stat_layout = QVBoxLayout(stat_frame)
        stat_layout.setSpacing(8)
        
        # Header dengan icon
        header_layout = QHBoxLayout()
        icon_label = QLabel(icon)
        icon_label.setFont(QFont("Arial", 16))
        icon_label.setStyleSheet("color: %s;" % color)
        
        stat_title = QLabel(title)
        stat_title.setFont(QFont("Arial", 12))
        stat_title.setStyleSheet("color: #7f8c8d;")
        
        header_layout.addWidget(icon_label)
        header_layout.addWidget(stat_title)
        header_layout.addStretch()
        
        # Value
        value_label = QLabel(value)
        value_label.setFont(QFont("Arial", 18, QFont.Bold))
        value_label.setStyleSheet("color: %s; margin-top: 5px;" % color)
        
        # Change
        change_label = QLabel(change)
        change_label.setFont(QFont("Arial", 11))
        change_label.setStyleSheet("color: #7f8c8d; font-weight: bold;")
        
        stat_layout.addLayout(header_layout)
        stat_layout.addWidget(value_label)
        stat_layout.addWidget(change_label)
        stat_layout.addStretch()
        
        return stat_frame
    
    def create_header(self):
        header = QFrame()
        header.setFixedHeight(70)
        header.setStyleSheet("""
            QFrame {
                background-color: #2c3e50;
                color: white;
                border-bottom: 3px solid #3498db;
            }
        """)
        
        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(30, 15, 30, 15)
        
        title = QLabel("🏪 Fashion Finance")
        title.setFont(QFont("Arial", 18, QFont.Bold))
        title.setStyleSheet("color: white;")
        
        nav_layout = QHBoxLayout()
        nav_layout.setSpacing(8)
        
        # Navigation buttons - SEPERTI YANG LAIN
        dashboard_btn = QPushButton("📊 Dasbor")
        inventory_btn = QPushButton("📦 Inventori")
        sales_btn = QPushButton("💳 Penjualan")
        expenses_btn = QPushButton("📋 Pengeluaran")
        reports_btn = QPushButton("📈 Laporan")
        settings_btn = QPushButton("⚙️ Pengaturan")
        logout_btn = QPushButton("🚪 Keluar")
        
        menu_style = """
            QPushButton {
                color: white;
                border: 2px solid transparent;
                padding: 10px 16px;
                background: rgba(255,255,255,0.1);
                font-size: 12px;
                font-weight: bold;
                border-radius: 8px;
                min-height: 25px;
            }
            QPushButton:hover {
                background-color: #34495e;
                border: 2px solid #5a6c7d;
            }
            QPushButton:disabled {
                background-color: #1abc9c;
                color: white;
                border: 2px solid #16a085;
                font-weight: bold;
            }
        """
        
        for btn in [dashboard_btn, inventory_btn, sales_btn, expenses_btn, reports_btn, settings_btn, logout_btn]:
            btn.setStyleSheet(menu_style)
            btn.setCursor(Qt.PointingHandCursor)
        
        dashboard_btn.setEnabled(False)
        inventory_btn.clicked.connect(self.inventory_clicked.emit)
        sales_btn.clicked.connect(self.sales_clicked.emit)
        expenses_btn.clicked.connect(self.expenses_clicked.emit)
        reports_btn.clicked.connect(self.reports_clicked.emit)
        settings_btn.clicked.connect(self.settings_clicked.emit)
        logout_btn.clicked.connect(self.logout_clicked.emit)
        
        # Apply role-based restrictions
        self.apply_role_restrictions(inventory_btn, reports_btn, settings_btn)
        
        nav_layout.addWidget(dashboard_btn)
        nav_layout.addWidget(inventory_btn)
        nav_layout.addWidget(sales_btn)
        nav_layout.addWidget(expenses_btn)
        nav_layout.addWidget(reports_btn)
        nav_layout.addWidget(settings_btn)
        nav_layout.addStretch()
        nav_layout.addWidget(logout_btn)
        
        header_layout.addWidget(title)
        header_layout.addStretch()
        header_layout.addLayout(nav_layout)
        header.setLayout(header_layout)
        
        return header
    
    def set_user_role(self, role):
        """Set user role and update UI accordingly"""
        self.user_role = role
        self.update_ui_for_role()
    
    def apply_role_restrictions(self, inventory_btn, reports_btn, settings_btn):
        """Apply restrictions based on user role"""
        if self.user_role == "kasir":
            inventory_btn.setEnabled(False)
            inventory_btn.setToolTip("Akses terbatas untuk kasir")
            reports_btn.setEnabled(False)
            reports_btn.setToolTip("Akses terbatas untuk kasir")
            settings_btn.setEnabled(False)
            settings_btn.setToolTip("Akses terbatas untuk kasir")
    
    def update_ui_for_role(self):
        """Update UI elements based on user role"""
        # Method ini bisa dipanggil setelah set_user_role
        # Untuk sekarang, restrictions sudah dihandle di apply_role_restrictions
        pass
    
    def load_data(self):
        # Update recent sales - SEPERTI YANG LAIN
        self.clear_layout(self.recent_sales_content)
        recent_sales_data = [
            ("Dress Floral Summer", 450000, "13 Nov 2024 - 14:30"),
            ("Kemeja Putih Casual", 320000, "13 Nov 2024 - 14:15"),
            ("Celana Jeans Slim Fit", 280000, "13 Nov 2024 - 13:45"),
            ("Tas Handbag Leather", 650000, "13 Nov 2024 - 12:20"),
            ("Sepatu Sneakers Sport", 420000, "13 Nov 2024 - 11:30")
        ]
        
        for product_name, amount, timestamp in recent_sales_data:
            sale_frame = QFrame()
            sale_frame.setStyleSheet("""
                QFrame { 
                    background-color: #f8f9fa; 
                    border-radius: 10px; 
                    padding: 15px; 
                    border: 1px solid #e9ecef;
                }
                QFrame:hover {
                    background-color: #e9ecef;
                }
            """)
            sale_layout = QHBoxLayout()
            sale_layout.setSpacing(15)
            
            # Icon dengan background
            icon_frame = QFrame()
            icon_frame.setStyleSheet("""
                QFrame {
                    background-color: #27ae60;
                    border-radius: 8px;
                    padding: 8px;
                }
            """)
            icon_frame.setFixedSize(40, 40)
            icon_layout = QVBoxLayout(icon_frame)
            product_icon = QLabel("💰")
            product_icon.setFont(QFont("Arial", 14))
            product_icon.setAlignment(Qt.AlignCenter)
            icon_layout.addWidget(product_icon)
            
            # Text content
            text_layout = QVBoxLayout()
            text_layout.setSpacing(4)
            
            name_label = QLabel(product_name)
            name_label.setFont(QFont("Arial", 12, QFont.Bold))
            name_label.setStyleSheet("color: #2c3e50;")
            name_label.setWordWrap(True)
            
            time_label = QLabel(timestamp)
            time_label.setFont(QFont("Arial", 10))
            time_label.setStyleSheet("color: #7f8c8d;")
            
            text_layout.addWidget(name_label)
            text_layout.addWidget(time_label)
            
            # Amount
            amount_label = QLabel(f"Rp {amount:,}".replace(',', '.'))
            amount_label.setFont(QFont("Arial", 13, QFont.Bold))
            amount_label.setStyleSheet("color: #27ae60;")
            amount_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            
            sale_layout.addWidget(icon_frame)
            sale_layout.addLayout(text_layout)
            sale_layout.addStretch()
            sale_layout.addWidget(amount_label)
            sale_frame.setLayout(sale_layout)
            
            self.recent_sales_content.addWidget(sale_frame)
        
        # Update best sellers - SEPERTI YANG LAIN
        self.clear_layout(self.best_sellers_content)
        best_sellers_data = [
            ("Dress Floral Summer", 45),
            ("Kemeja Putih Casual", 38),
            ("Celana Jeans Slim Fit", 32),
            ("Tas Handbag Leather", 28),
            ("Sepatu Sneakers Sport", 25)
        ]
        
        for rank, (product_name, sold_count) in enumerate(best_sellers_data, 1):
            product_frame = QFrame()
            product_frame.setStyleSheet("""
                QFrame { 
                    background-color: #f8f9fa; 
                    border-radius: 10px; 
                    padding: 15px; 
                    border: 1px solid #e9ecef;
                }
                QFrame:hover {
                    background-color: #e9ecef;
                }
            """)
            product_layout = QHBoxLayout()
            product_layout.setSpacing(15)
            
            # Rank dengan background warna berbeda
            rank_colors = ["#e74c3c", "#3498db", "#f39c12", "#9b59b6", "#1abc9c"]
            rank_color = rank_colors[rank-1] if rank <= 5 else "#95a5a6"
            
            rank_frame = QFrame()
            rank_frame.setStyleSheet(f"""
                QFrame {{
                    background-color: {rank_color};
                    border-radius: 8px;
                    padding: 8px;
                }}
            """)
            rank_frame.setFixedSize(40, 40)
            rank_layout = QVBoxLayout(rank_frame)
            
            rank_icon = "🥇" if rank == 1 else "🥈" if rank == 2 else "🥉" if rank == 3 else f"{rank}"
            rank_label = QLabel(rank_icon)
            rank_label.setFont(QFont("Arial", 12 if rank <= 3 else 14))
            rank_label.setStyleSheet("color: white; font-weight: bold;")
            rank_label.setAlignment(Qt.AlignCenter)
            rank_layout.addWidget(rank_label)
            
            # Text content
            text_layout = QVBoxLayout()
            text_layout.setSpacing(4)
            
            name_label = QLabel(product_name)
            name_label.setFont(QFont("Arial", 12, QFont.Bold))
            name_label.setStyleSheet("color: #2c3e50;")
            name_label.setWordWrap(True)
            
            count_label = QLabel(f"{sold_count} terjual")
            count_label.setFont(QFont("Arial", 11))
            count_label.setStyleSheet("color: #7f8c8d;")
            
            text_layout.addWidget(name_label)
            text_layout.addWidget(count_label)
            
            product_layout.addWidget(rank_frame)
            product_layout.addLayout(text_layout)
            product_layout.addStretch()
            
            product_frame.setLayout(product_layout)
            
            self.best_sellers_content.addWidget(product_frame)
    
    def clear_layout(self, layout):
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()