from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QFrame, QTableWidget, QTableWidgetItem,
                             QHeaderView, QDialog, QComboBox, QSpinBox, 
                             QDialogButtonBox, QMessageBox, QGridLayout, QScrollArea,
                             QLineEdit, QMessageBox)
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QFont, QPalette, QColor, QPixmap
from database import db
from datetime import datetime
import os

class AddSaleDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()
        
    def init_ui(self):
        self.setWindowTitle("💳 Tambah Transaksi Penjualan")
        self.setFixedSize(700, 600)
        
        layout = QVBoxLayout()
        layout.setSpacing(0)
        
        # Title
        title = QLabel("Tambah Transaksi Baru")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        title.setStyleSheet("color: #2c3e50; margin-bottom: 10px; background-color: #ecf0f1; padding: 10px; border-radius: 8px;")
        layout.addWidget(title)
        
        # Product selection section dengan gambar
        product_section = self.create_product_section()
        layout.addLayout(product_section)
        
        # Quantity
        quantity_label = QLabel("📊 JUMLAH")
        quantity_label.setFont(QFont("Arial", 12, QFont.Bold))
        quantity_label.setStyleSheet("color: #2c3e50; background-color: #f8f9fa; padding: 5px; border-radius: 4px;")
        self.quantity_spin = QSpinBox()
        self.quantity_spin.setRange(1, 100)
        self.quantity_spin.setStyleSheet("""
            QSpinBox {
                padding: 12px;
                border: 2px solid #bdc3c7;
                border-radius: 8px;
                font-size: 14px;
                background-color: white;
                color: #2c3e50;
            }
            QSpinBox:focus {
                border-color: #3498db;
            }
        """)
        self.quantity_spin.valueChanged.connect(self.calculate_total)
        
        layout.addWidget(quantity_label)
        layout.addWidget(self.quantity_spin)
        
        # Price info
        price_layout = QHBoxLayout()
        price_label = QLabel("💰 HARGA SATUAN:")
        price_label.setFont(QFont("Arial", 12, QFont.Bold))
        price_label.setStyleSheet("color: #2c3e50;")
        self.price_label = QLabel("Rp 0")
        self.price_label.setFont(QFont("Arial", 14, QFont.Bold))
        self.price_label.setStyleSheet("color: #27ae60; background-color: #d5f4e6; padding: 8px 12px; border-radius: 6px;")
        
        price_layout.addWidget(price_label)
        price_layout.addStretch()
        price_layout.addWidget(self.price_label)
        
        # Total
        total_layout = QHBoxLayout()
        total_label = QLabel("💵 TOTAL:")
        total_label.setFont(QFont("Arial", 14, QFont.Bold))
        total_label.setStyleSheet("color: #2c3e50;")
        self.total_label = QLabel("Rp 0")
        self.total_label.setFont(QFont("Arial", 18, QFont.Bold))
        self.total_label.setStyleSheet("color: #27ae60; background-color: #d5f4e6; padding: 12px 16px; border-radius: 8px; border: 2px solid #27ae60;")
        
        total_layout.addWidget(total_label)
        total_layout.addStretch()
        total_layout.addWidget(self.total_label)
        
        # Add widgets to layout
        layout.addSpacing(15)
        layout.addLayout(price_layout)
        layout.addLayout(total_layout)
        layout.addStretch()
        
        # Buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.setStyleSheet("""
            QPushButton {
                padding: 12px 24px;
                border: none;
                border-radius: 6px;
                font-weight: bold;
                min-width: 100px;
                font-size: 14px;
            }
            QPushButton[text="OK"] {
                background-color: #27ae60;
                color: white;
            }
            QPushButton[text="OK"]:hover {
                background-color: #2ecc71;
            }
            QPushButton[text="Cancel"] {
                background-color: #95a5a6;
                color: white;
            }
            QPushButton[text="Cancel"]:hover {
                background-color: #7f8c8d;
            }
        """)
        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)
        
        layout.addWidget(button_box)
        self.setLayout(layout)
    
    def create_product_section(self):
        """Membuat section pemilihan produk dengan gambar"""
        product_layout = QHBoxLayout()
        product_layout.setSpacing(20)
        
        # Left: Product selection
        left_layout = QVBoxLayout()
        
        product_label = QLabel("🛍️ PILIH PRODUK")
        product_label.setFont(QFont("Arial", 12, QFont.Bold))
        product_label.setStyleSheet("color: #2c3e50; background-color: #f8f9fa; padding: 5px; border-radius: 4px;")
        
        self.product_combo = QComboBox()
        self.product_combo.setStyleSheet("""
            QComboBox {
                padding: 12px;
                border: 2px solid #bdc3c7;
                border-radius: 8px;
                font-size: 14px;
                background-color: white;
                color: #2c3e50;
            }
            QComboBox:focus {
                border-color: #3498db;
            }
        """)
        self.load_products()
        
        left_layout.addWidget(product_label)
        left_layout.addWidget(self.product_combo)
        
        # Right: Product image
        right_layout = QVBoxLayout()
        
        image_label = QLabel("🖼️ GAMBAR PRODUK")
        image_label.setFont(QFont("Arial", 12, QFont.Bold))
        image_label.setStyleSheet("color: #2c3e50; background-color: #f8f9fa; padding: 5px; border-radius: 4px;")
        
        self.product_image = QLabel()
        self.product_image.setFixedSize(150, 150)
        self.product_image.setStyleSheet("""
            QLabel {
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                background-color: #f8f9fa;
            }
        """)
        self.product_image.setAlignment(Qt.AlignCenter)
        self.product_image.setText("📷\nPilih produk\nuntuk melihat\ngambar")
        
        right_layout.addWidget(image_label)
        right_layout.addWidget(self.product_image, 0, Qt.AlignCenter)
        
        product_layout.addLayout(left_layout)
        product_layout.addLayout(right_layout)
        
        # Connect product change
        self.product_combo.currentIndexChanged.connect(self.product_changed)
        
        return product_layout
    
    def load_products(self):
        products = db.get_products()
        self.product_combo.clear()
        self.products_data = []
        
        for product in products:
            if product[3] > 0:  # Only show products with stock
                price = product[4]
                price_text = f"Rp {price:,}".replace(',', '.')
                
                # Tambah icon gambar jika produk punya gambar
                image_icon = " 📷" if product[6] else ""
                
                self.product_combo.addItem(f"{product[1]} - {price_text} (Stok: {product[3]}){image_icon}")
                self.products_data.append(product)
        
        # Auto-select produk pertama jika ada
        if self.products_data:
            self.product_combo.setCurrentIndex(0)
    
    def product_changed(self):
        if self.product_combo.currentIndex() >= 0:
            product = self.products_data[self.product_combo.currentIndex()]
            price = product[4]
            price_text = f"Rp {price:,}".replace(',', '.')
            self.price_label.setText(price_text)
            
            # Load dan tampilkan gambar produk
            self.load_product_image(product[6])
            
            self.calculate_total()
    
    def load_product_image(self, image_path):
        """Load dan tampilkan gambar produk"""
        if image_path and os.path.exists(image_path):
            pixmap = QPixmap(image_path)
            # Scale image to fit display
            scaled_pixmap = pixmap.scaled(150, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.product_image.setPixmap(scaled_pixmap)
        else:
            # Jika tidak ada gambar lokal, tampilkan placeholder berdasarkan kategori
            if self.product_combo.currentIndex() >= 0:
                product = self.products_data[self.product_combo.currentIndex()]
                category = product[2]
                
                # Tampilkan placeholder berdasarkan kategori
                placeholders = {
                    "Dress": "👗\nDress",
                    "Kemeja": "👔\nKemeja", 
                    "Celana": "👖\nCelana",
                    "Sepatu": "👟\nSepatu",
                    "Jaket": "🧥\nJaket",
                    "Aksesoris": "💎\nAksesoris"
                }
                
                placeholder = placeholders.get(category, "📷\nSample")
                self.product_image.setText(placeholder)
            else:
                self.product_image.setText("📷\nTidak ada\ngambar")
    
    def calculate_total(self):
        if self.product_combo.currentIndex() >= 0:
            product = self.products_data[self.product_combo.currentIndex()]
            total = product[4] * self.quantity_spin.value()
            total_text = f"Rp {total:,}".replace(',', '.')
            self.total_label.setText(total_text)
    
    def validate_and_accept(self):
        if self.product_combo.currentIndex() < 0:
            QMessageBox.warning(self, "Error", "❌ PILIH PRODUK TERLEBIH DAHULU!")
            return
        
        product = self.products_data[self.product_combo.currentIndex()]
        if self.quantity_spin.value() > product[3]:
            QMessageBox.warning(self, "Error", f"❌ STOK TIDAK MENCUKUPI! Stok tersedia: {product[3]}")
            return
        
        self.accept()
    
    def get_data(self):
        product = self.products_data[self.product_combo.currentIndex()]
        transaction_id = f"TRX{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        return {
            'transaction_id': transaction_id,
            'product_id': product[0],
            'product_name': product[1],
            'quantity': self.quantity_spin.value(),
            'amount': product[4] * self.quantity_spin.value()
        }

class SalesWindow(QWidget):
    back_clicked = pyqtSignal()
    inventory_clicked = pyqtSignal()
    expenses_clicked = pyqtSignal()
    reports_clicked = pyqtSignal()
    settings_clicked = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.init_ui()
        
    def init_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Header
        header = self.create_header()
        
        # Content dengan scroll area - SEPERTI EXPENSES
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setStyleSheet("""
            QScrollArea { 
                border: none; 
                background-color: #f8f9fa;
            }
            QScrollBar:vertical {
                background-color: #e0e0e0;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background-color: #bdc3c7;
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #95a5a6;
            }
        """)
        
        # Content widget utama - SEPERTI EXPENSES
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(20)
        
        # Page title - SEPERTI EXPENSES
        page_title = QLabel("Penjualan")
        page_title.setFont(QFont("Arial", 24, QFont.Bold))
        page_title.setStyleSheet("color: #2c3e50; margin-bottom: 5px;")
        
        subtitle = QLabel("Kelola dan catat semua transaksi penjualan")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7f8c8d;")
        
        content_layout.addWidget(page_title)
        content_layout.addWidget(subtitle)
        
        # Search and filter section - SEPERTI EXPENSES
        filter_section = QHBoxLayout()
        filter_section.setSpacing(15)
        
        # Search input
        search_input = QLineEdit()
        search_input.setPlaceholderText("🔍 Cari transaksi...")
        search_input.setFixedWidth(250)
        search_input.setStyleSheet("""
            QLineEdit {
                padding: 12px 15px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 14px;
                background-color: white;
            }
            QLineEdit:focus {
                border-color: #3498db;
            }
        """)
        
        # Date filter
        date_filter = QComboBox()
        date_filter.addItems(["Semua Waktu", "Hari ini", "Minggu ini", "Bulan ini"])
        date_filter.setFixedWidth(180)
        date_filter.setStyleSheet("""
            QComboBox {
                padding: 12px 15px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 14px;
                background-color: white;
            }
        """)
        
        filter_section.addWidget(search_input)
        filter_section.addWidget(date_filter)
        filter_section.addStretch()
        
        content_layout.addLayout(filter_section)
        
        # Stats section - SEPERTI EXPENSES (satu baris horizontal)
        stats_layout = QHBoxLayout()
        stats_layout.setSpacing(20)

        stats_data = [
            ("Total Penjualan", "Rp 15.750.000", "+8% dari bulan lalu", "#27ae60", "📈"),
            ("Transaksi Hari Ini", "8 transaksi", "+2 dari kemarin", "#3498db", "📊"),
            ("Rata-rata Transaksi", "Rp 156.250", "+5% dari kemarin", "#f39c12", "💰"),
            ("Produk Terlaris", "Dress Floral", "15 terjual", "#9b59b6", "🏆")
        ]

        for title, value, change, color, icon in stats_data:
            stat_card = self.create_stat_card_large(title, value, change, color, icon)
            stats_layout.addWidget(stat_card)

        stats_layout.addStretch()
        content_layout.addLayout(stats_layout)
        
        # Sales table section - SEPERTI EXPENSES
        table_section = QFrame()
        table_section.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
                border: 1px solid #e0e0e0;
            }
        """)
        
        table_layout = QVBoxLayout(table_section)
        table_layout.setSpacing(15)
        
        # Table header
        table_header = QHBoxLayout()
        table_title = QLabel("Transaksi Terbaru")
        table_title.setFont(QFont("Arial", 18, QFont.Bold))
        table_title.setStyleSheet("color: #2c3e50;")
        
        table_header.addWidget(table_title)
        table_header.addStretch()
        
        # Add sale button
        add_btn = QPushButton("➕ Tambah Transaksi")
        add_btn.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                color: white;
                padding: 12px 20px;
                border: none;
                border-radius: 8px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2ecc71;
            }
        """)
        add_btn.clicked.connect(self.add_sale)
        
        table_header.addWidget(add_btn)
        
        # Table - SEPERTI EXPENSES
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["ID TRANSAKSI", "TANGGAL", "PRODUK", "JUMLAH", "TOTAL", "STATUS"])
        
        # Style table seperti expenses
        self.table.setStyleSheet("""
            QTableWidget {
                background-color: white;
                border: none;
                gridline-color: #e9ecef;
                font-size: 14px;
                border-radius: 8px;
                alternate-background-color: #f8f9fa;
            }
            QTableWidget::item {
                padding: 16px 12px;
                border-bottom: 1px solid #e9ecef;
                font-size: 13px;
            }
            QTableWidget::item:selected {
                background-color: #3498db;
                color: white;
            }
            QHeaderView::section {
                background-color: #2c3e50;
                color: white;
                padding: 16px 12px;
                border: none;
                border-bottom: 2px solid #e9ecef;
                font-weight: bold;
                font-size: 13px;
            }
        """)
        
        self.table.verticalHeader().setDefaultSectionSize(65)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setMinimumHeight(400)
        
        table_layout.addLayout(table_header)
        table_layout.addWidget(self.table)
        
        content_layout.addWidget(table_section)
        content_layout.addStretch()
        
        scroll_area.setWidget(content_widget)
        
        # Add to main layout
        main_layout.addWidget(header)
        main_layout.addWidget(scroll_area, 1)
        
        self.setLayout(main_layout)
        self.setStyleSheet("background-color: #f8f9fa;")
        self.load_data()

    def create_stat_card_large(self, title, value, change, color, icon):
        """Membuat stat card besar dengan icon seperti expenses"""
        stat_frame = QFrame()
        stat_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 25px;
                border: 1px solid #e0e0e0;
            }
        """)
        stat_frame.setMinimumHeight(350)
        stat_frame.setMinimumWidth(400)
        
        stat_layout = QVBoxLayout(stat_frame)
        stat_layout.setSpacing(8)
        
        # Header dengan icon
        header_layout = QHBoxLayout()
        icon_label = QLabel(icon)
        icon_label.setFont(QFont("Arial", 16))
        icon_label.setStyleSheet("color: %s;" % color)
        
        stat_title = QLabel(title)
        stat_title.setFont(QFont("Arial", 12))
        stat_title.setStyleSheet("color: #7f8c8d;")
        
        header_layout.addWidget(icon_label)
        header_layout.addWidget(stat_title)
        header_layout.addStretch()
        
        # Value
        value_label = QLabel(value)
        value_label.setFont(QFont("Arial", 18, QFont.Bold))
        value_label.setStyleSheet("color: %s; margin-top: 5px;" % color)
        
        # Change
        change_label = QLabel(change)
        change_label.setFont(QFont("Arial", 11))
        change_label.setStyleSheet("color: #7f8c8d; font-weight: bold;")
        
        stat_layout.addLayout(header_layout)
        stat_layout.addWidget(value_label)
        stat_layout.addWidget(change_label)
        stat_layout.addStretch()
        
        return stat_frame
    
    def create_header(self):
        header = QFrame()
        header.setFixedHeight(70)
        header.setStyleSheet("""
            QFrame {
                background-color: #2c3e50;
                color: white;
                border-bottom: 3px solid #3498db;
            }
        """)
        
        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(30, 15, 30, 15)
        
        title = QLabel("🏪 Fashion Finance")
        title.setFont(QFont("Arial", 18, QFont.Bold))
        title.setStyleSheet("color: white;")
        
        nav_layout = QHBoxLayout()
        nav_layout.setSpacing(8)
        
        # Navigation buttons
        dashboard_btn = QPushButton("📊 Dashboard")
        inventory_btn = QPushButton("📦 Inventori")
        sales_btn = QPushButton("💳 Penjualan")
        expenses_btn = QPushButton("📋 Pengeluaran")
        reports_btn = QPushButton("📈 Laporan")
        settings_btn = QPushButton("⚙️ Pengaturan")
        logout_btn = QPushButton("🚪 Logout")
        
        menu_style = """
            QPushButton {
                color: white;
                border: 2px solid transparent;
                padding: 10px 16px;
                background: rgba(255,255,255,0.1);
                font-size: 12px;
                font-weight: bold;
                border-radius: 8px;
                min-height: 25px;
            }
            QPushButton:hover {
                background-color: #34495e;
                border: 2px solid #5a6c7d;
            }
            QPushButton:disabled {
                background-color: #1abc9c;
                color: white;
                border: 2px solid #16a085;
                font-weight: bold;
            }
        """
        
        for btn in [dashboard_btn, inventory_btn, sales_btn, expenses_btn, reports_btn, settings_btn, logout_btn]:
            btn.setStyleSheet(menu_style)
            btn.setCursor(Qt.PointingHandCursor)
        
        sales_btn.setEnabled(False)
        dashboard_btn.clicked.connect(self.back_clicked.emit)
        inventory_btn.clicked.connect(self.inventory_clicked.emit)
        expenses_btn.clicked.connect(self.expenses_clicked.emit)
        reports_btn.clicked.connect(self.reports_clicked.emit)
        settings_btn.clicked.connect(self.settings_clicked.emit)
        logout_btn.clicked.connect(self.back_to_login)
        
        nav_layout.addWidget(dashboard_btn)
        nav_layout.addWidget(inventory_btn)
        nav_layout.addWidget(sales_btn)
        nav_layout.addWidget(expenses_btn)
        nav_layout.addWidget(reports_btn)
        nav_layout.addWidget(settings_btn)
        nav_layout.addStretch()
        nav_layout.addWidget(logout_btn)
        
        header_layout.addWidget(title)
        header_layout.addStretch()
        header_layout.addLayout(nav_layout)
        header.setLayout(header_layout)
        
        return header
    
    def load_data(self):
        data = db.get_sales_data()
        
        # Load transactions table
        self.table.setRowCount(len(data['recent_transactions']))
        
        for row, transaction in enumerate(data['recent_transactions']):
            # ID Transaksi
            id_item = QTableWidgetItem(f"🔖 {transaction[0]}")
            id_item.setData(Qt.UserRole, transaction[0])
            
            # Tanggal
            date_item = QTableWidgetItem(f"📅 {transaction[1].split()[0]}")
            
            # Produk
            product_item = QTableWidgetItem(f"🛍️ {transaction[2]}")
            
            # Jumlah
            qty_item = QTableWidgetItem(f"📦 {transaction[3]} pcs")
            qty_item.setTextAlignment(Qt.AlignCenter)
            
            # Total - Format currency
            amount = transaction[4]
            if isinstance(amount, (int, float)):
                amount_text = f"Rp {amount:,}".replace(',', '.')
            else:
                amount_text = f"Rp {amount}"
            amount_item = QTableWidgetItem(f"💵 {amount_text}")
            amount_item.setTextAlignment(Qt.AlignRight)
            
            # Status
            status_icon = "🟢" if transaction[5] == "Selesai" else "🟡"
            status_item = QTableWidgetItem(f"{status_icon} {transaction[5]}")
            status_item.setTextAlignment(Qt.AlignCenter)
            
            # Set items dengan style
            items = [id_item, date_item, product_item, qty_item, amount_item, status_item]
            for item in items:
                item.setFont(QFont("Arial", 11))
                if row % 2 == 0:
                    item.setBackground(QColor(248, 249, 250))
                else:
                    item.setBackground(QColor(255, 255, 255))
            
            self.table.setItem(row, 0, id_item)
            self.table.setItem(row, 1, date_item)
            self.table.setItem(row, 2, product_item)
            self.table.setItem(row, 3, qty_item)
            self.table.setItem(row, 4, amount_item)
            self.table.setItem(row, 5, status_item)
    
    def add_sale(self):
        dialog = AddSaleDialog(self)
        if dialog.exec_():
            data = dialog.get_data()
            db.add_sale(data['transaction_id'], data['product_id'], data['product_name'], data['quantity'], data['amount'])
            self.load_data()
            QMessageBox.information(self, "Sukses", "✅ TRANSAKSI PENJUALAN BERHASIL DITAMBAHKAN!")
    
    def back_to_login(self):
        reply = QMessageBox.question(self, "Konfirmasi Logout", 
                                   "Apakah Anda yakin ingin logout?",
                                   QMessageBox.Yes | QMessageBox.No,
                                   QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            self.back_clicked.emit()