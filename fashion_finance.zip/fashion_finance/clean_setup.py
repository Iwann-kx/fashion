# clean_setup.py
import os
import sqlite3
import shutil

def clean_setup():
    print("🧹 Membersihkan setup lama...")
    
    # Hapus database lama
    if os.path.exists('fashion_finance.db'):
        os.remove('fashion_finance.db')
        print("✅ Database lama dihapus")
    
    # Hapus folder images lama
    if os.path.exists('images'):
        shutil.rmtree('images')
        print("✅ Folder images lama dihapus")
    
    # Buat folder images
    os.makedirs('images/products', exist_ok=True)
    print("✅ Folder images/products dibuat")
    
    # Buat database baru dengan struktur yang benar
    print("📊 Membuat database baru...")
    conn = sqlite3.connect('fashion_finance.db')
    cursor = conn.cursor()
    
    # Buat tabel barang dengan kolom gambar
    cursor.execute('''
        CREATE TABLE barang (
            id_barang INTEGER PRIMARY KEY AUTOINCREMENT,
            id_kasir INTEGER,
            nama_barang VARCHAR(100),
            harga INTEGER,
            stok INTEGER,
            kode_barang VARCHAR(45) UNIQUE,
            kategori VARCHAR(50),
            gambar TEXT,
            status VARCHAR(20) DEFAULT 'Aktif'
        )
    ''')
    
    # Buat tabel sederhana lainnya untuk testing
    cursor.execute('''
        CREATE TABLE owners (
            id_owner INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_owner VARCHAR(100),
            username VARCHAR(50),
            password VARCHAR(255),
            email VARCHAR(100)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE kasir (
            id_kasir INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_kasir VARCHAR(100),
            username VARCHAR(50),
            password VARCHAR(255),
            no_hp VARCHAR(20),
            alamat TEXT,
            tanggal_bergabung DATETIME,
            id_owner INTEGER
        )
    ''')
    
    # Insert sample data
    import hashlib
    from datetime import datetime
    
    # Insert owner
    cursor.execute('''
        INSERT INTO owners (nama_owner, username, password, email)
        VALUES (?, ?, ?, ?)
    ''', ("Admin Fashion", "admin", 
          hashlib.sha256("admin".encode()).hexdigest(), 
          "admin@fashion.com"))
    
    owner_id = cursor.lastrowid
    
    # Insert kasir
    cursor.execute('''
        INSERT INTO kasir (nama_kasir, username, password, no_hp, alamat, tanggal_bergabung, id_owner)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', ("Kasir Utama", "kasir", 
          hashlib.sha256("kasir".encode()).hexdigest(),
          "08123456789", "Jl. Kasir No. 123", datetime.now(), owner_id))
    
    kasir_id = cursor.lastrowid
    
    # Insert sample produk tanpa gambar dulu
    sample_products = [
        ("Dress Floral Summer", 450000, 25, "BRG001", "Dress", None, kasir_id),
        ("Kemeja Formal Putih", 275000, 15, "BRG002", "Kemeja", None, kasir_id),
        ("Celana Jeans Slim", 320000, 30, "BRG003", "Celana", None, kasir_id),
        ("Tas Handbag Leather", 650000, 10, "BRG004", "Aksesoris", None, kasir_id),
        ("Sepatu Sneakers Sport", 420000, 20, "BRG005", "Sepatu", None, kasir_id),
    ]
    
    for product in sample_products:
        cursor.execute('''
            INSERT INTO barang (nama_barang, harga, stok, kode_barang, kategori, gambar, id_kasir)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', product)
        print(f"✅ {product[0]} ditambahkan")
    
    conn.commit()
    conn.close()
    
    print("🎉 Setup berhasil! Database baru dibuat dengan struktur yang benar.")
    print("🚀 Sekarang jalankan: python main.py")

if __name__ == "__main__":
    clean_setup()