# app.py - Aplikasi Utama Fashion Finance
import sys
import mysql.connector
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QLabel, QPushButton, QStackedWidget, QMessageBox, QFrame,
                             QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QIcon
from datetime import datetime

class MainApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.init_ui()
        
    def init_ui(self):
        self.setWindowTitle("Fashion Finance - Aplikasi Utama")
        self.setGeometry(100, 100, 1200, 800)
        
        # Central widget dengan stacked widget
        self.stacked_widget = QStackedWidget()
        self.setCentralWidget(self.stacked_widget)
        
        # Create different pages
        self.dashboard_page = self.create_dashboard_page()
        self.inventory_page = self.create_inventory_page()
        self.sales_page = self.create_sales_page()
        
        # Add pages to stacked widget
        self.stacked_widget.addWidget(self.dashboard_page)
        self.stacked_widget.addWidget(self.inventory_page)
        self.stacked_widget.addWidget(self.sales_page)
        
        # Show dashboard first
        self.stacked_widget.setCurrentWidget(self.dashboard_page)
        
        # Load initial data
        self.load_dashboard_data()
        
    def create_dashboard_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        
        # Header
        header = QLabel("🏠 Dashboard - Fashion Finance")
        header.setStyleSheet("font-size: 28px; font-weight: bold; color: #2c3e50; margin: 20px;")
        header.setAlignment(Qt.AlignCenter)
        
        # Stats grid
        stats_layout = QHBoxLayout()
        
        stats_data = [
            ("Total Produk", "50", "#3498db"),
            ("Total Penjualan", "Rp 1.210.000", "#27ae60"),
            ("Total Pengeluaran", "Rp 2.970.000", "#e74c3c"),
            ("Profit", "Rp -1.760.000", "#f39c12")
        ]
        
        for title, value, color in stats_data:
            stat_frame = self.create_stat_card(title, value, color)
            stats_layout.addWidget(stat_frame)
        
        # Recent sales table
        sales_group = QGroupBox("Penjualan Terakhir")
        sales_group.setStyleSheet("QGroupBox { font-weight: bold; font-size: 16px; }")
        sales_layout = QVBoxLayout(sales_group)
        
        self.sales_table = QTableWidget()
        self.sales_table.setColumnCount(4)
        self.sales_table.setHorizontalHeaderLabels(["Kode Transaksi", "Tanggal", "Total", "Kasir"])
        self.sales_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        
        sales_layout.addWidget(self.sales_table)
        
        # Navigation buttons
        nav_layout = QHBoxLayout()
        
        btn_inventory = QPushButton("📦 Kelola Inventori")
        btn_inventory.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                border: none;
                padding: 15px;
                font-size: 14px;
                font-weight: bold;
                border-radius: 8px;
                min-width: 150px;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        btn_inventory.clicked.connect(lambda: self.stacked_widget.setCurrentWidget(self.inventory_page))
        
        btn_sales = QPushButton("💰 Kelola Penjualan")
        btn_sales.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                color: white;
                border: none;
                padding: 15px;
                font-size: 14px;
                font-weight: bold;
                border-radius: 8px;
                min-width: 150px;
            }
            QPushButton:hover {
                background-color: #219a52;
            }
        """)
        btn_sales.clicked.connect(lambda: self.stacked_widget.setCurrentWidget(self.sales_page))
        
        nav_layout.addWidget(btn_inventory)
        nav_layout.addWidget(btn_sales)
        nav_layout.addStretch()
        
        # Add all to main layout
        layout.addWidget(header)
        layout.addLayout(stats_layout)
        layout.addWidget(sales_group)
        layout.addLayout(nav_layout)
        layout.addStretch()
        
        return page
    
    def create_stat_card(self, title, value, color):
        frame = QFrame()
        frame.setFrameStyle(QFrame.StyledPanel)
        frame.setStyleSheet(f"""
            QFrame {{
                background-color: {color};
                border-radius: 10px;
                padding: 20px;
            }}
        """)
        
        layout = QVBoxLayout(frame)
        
        title_label = QLabel(title)
        title_label.setStyleSheet("color: white; font-size: 14px; font-weight: bold;")
        
        value_label = QLabel(value)
        value_label.setStyleSheet("color: white; font-size: 24px; font-weight: bold;")
        
        layout.addWidget(title_label)
        layout.addWidget(value_label)
        
        return frame
    
    def create_inventory_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        
        header = QLabel("📦 Manajemen Inventori")
        header.setStyleSheet("font-size: 28px; font-weight: bold; color: #2c3e50; margin: 20px;")
        header.setAlignment(Qt.AlignCenter)
        
        # Inventory table
        self.inventory_table = QTableWidget()
        self.inventory_table.setColumnCount(6)
        self.inventory_table.setHorizontalHeaderLabels(["Kode", "Nama Produk", "Kategori", "Harga Jual", "Stok", "Satuan"])
        self.inventory_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        
        # Back button
        btn_back = QPushButton("← Kembali ke Dashboard")
        btn_back.setStyleSheet("""
            QPushButton {
                background-color: #95a5a6;
                color: white;
                border: none;
                padding: 10px 20px;
                font-size: 14px;
                border-radius: 6px;
            }
            QPushButton:hover {
                background-color: #7f8c8d;
            }
        """)
        btn_back.clicked.connect(lambda: self.stacked_widget.setCurrentWidget(self.dashboard_page))
        
        layout.addWidget(header)
        layout.addWidget(self.inventory_table)
        layout.addWidget(btn_back)
        
        return page
    
    def create_sales_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        
        header = QLabel("💰 Manajemen Penjualan")
        header.setStyleSheet("font-size: 28px; font-weight: bold; color: #2c3e50; margin: 20px;")
        header.setAlignment(Qt.AlignCenter)
        
        # Sales table
        self.sales_detail_table = QTableWidget()
        self.sales_detail_table.setColumnCount(5)
        self.sales_detail_table.setHorizontalHeaderLabels(["Kode Transaksi", "Produk", "Qty", "Harga", "Subtotal"])
        self.sales_detail_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        
        # Back button
        btn_back = QPushButton("← Kembali ke Dashboard")
        btn_back.setStyleSheet("""
            QPushButton {
                background-color: #95a5a6;
                color: white;
                border: none;
                padding: 10px 20px;
                font-size: 14px;
                border-radius: 6px;
            }
            QPushButton:hover {
                background-color: #7f8c8d;
            }
        """)
        btn_back.clicked.connect(lambda: self.stacked_widget.setCurrentWidget(self.dashboard_page))
        
        layout.addWidget(header)
        layout.addWidget(self.sales_detail_table)
        layout.addWidget(btn_back)
        
        return page
    
    def load_dashboard_data(self):
        """Load data untuk dashboard"""
        try:
            connection = mysql.connector.connect(
                host='localhost',
                user='root',
                password='',
                database='fashion_finance'
            )
            
            cursor = connection.cursor()
            
            # Load recent sales
            cursor.execute("""
                SELECT s.kode_transaksi, s.tanggal_transaksi, s.total, u.username 
                FROM sales s 
                LEFT JOIN users u ON s.user_id = u.id 
                ORDER BY s.created_at DESC 
                LIMIT 10
            """)
            
            sales_data = cursor.fetchall()
            
            self.sales_table.setRowCount(len(sales_data))
            for row, sale in enumerate(sales_data):
                for col, value in enumerate(sale):
                    self.sales_table.setItem(row, col, QTableWidgetItem(str(value)))
            
            # Load inventory data
            cursor.execute("SELECT COUNT(*) FROM products")
            total_products = cursor.fetchone()[0]
            
            cursor.execute("SELECT SUM(total) FROM sales")
            total_sales = cursor.fetchone()[0] or 0
            
            cursor.execute("SELECT SUM(jumlah) FROM expenses")
            total_expenses = cursor.fetchone()[0] or 0
            
            profit = total_sales - total_expenses
            
            # Update stat cards (you would need to store references to these)
            
            cursor.close()
            connection.close()
            
        except Exception as e:
            print(f"Error loading data: {e}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Set application style
    app.setStyleSheet("""
        QMainWindow {
            background-color: #f8f9fa;
        }
        QTableWidget {
            background-color: white;
            border: 1px solid #bdc3c7;
            border-radius: 5px;
        }
        QHeaderView::section {
            background-color: #34495e;
            color: white;
            padding: 8px;
            border: none;
        }
    """)
    
    main_app = MainApp()
    main_app.show()
    
    sys.exit(app.exec_())