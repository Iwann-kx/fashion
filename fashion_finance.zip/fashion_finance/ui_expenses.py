from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QFrame, QTableWidget, QTableWidgetItem,
                             QHeaderView, QDialog, QLineEdit, QComboBox, 
                             QDateEdit, QDialogButtonBox, QMessageBox, QScrollArea)
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QFont
from database import db
from datetime import datetime

class AddExpenseDialog(QDialog):
    def __init__(self, parent=None, expense_data=None):
        super().__init__(parent)
        self.expense_data = expense_data
        self.is_edit = expense_data is not None
        self.init_ui()
        
    def init_ui(self):
        self.setWindowTitle("✏️ Edit Pengeluaran" if self.is_edit else "➕ Tambah Pengeluaran")
        self.setFixedSize(600, 600)
        
        layout = QVBoxLayout()
        layout.setSpacing(0)
        
        # Title
        title = QLabel("Edit Pengeluaran" if self.is_edit else "Tambah Pengeluaran Baru")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        title.setStyleSheet("color: #2c3e50; margin-bottom: 20px;")
        layout.addWidget(title)
        
        # Form fields
        fields = [
            ("📅 Tanggal", QDateEdit()),
            ("📝 Deskripsi", QLineEdit()),
            ("📂 Kategori", QComboBox()),
            ("💰 Jumlah", QLineEdit()),
            ("📊 Status", QComboBox())
        ]
        
        self.date_edit, self.desc_input, self.category_combo, self.amount_input, self.status_combo = [field[1] for field in fields]
        
        # Setup date
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDate(datetime.now().date())
        
        # Setup category combo
        self.category_combo.addItems(["Bahan Baku", "Operasional", "Marketing", "Lainnya"])
        
        # Setup amount input
        self.amount_input.setPlaceholderText("Contoh: 500000 (tanpa titik/koma)")
        
        # Setup status combo
        self.status_combo.addItems(["Lunas", "Pending"])
        
        # Add fields to layout
        for label_text, widget in fields:
            field_layout = QVBoxLayout()
            label = QLabel(label_text)
            label.setFont(QFont("Arial", 11, QFont.Bold))
            label.setStyleSheet("color: #2c3e50; margin-bottom: 5px;")
            
            widget.setStyleSheet("""
                QLineEdit, QComboBox, QDateEdit {
                    padding: 12px;
                    border: 2px solid #e0e0e0;
                    border-radius: 8px;
                    font-size: 14px;
                    background-color: white;
                }
                QLineEdit:focus, QComboBox:focus, QDateEdit:focus {
                    border-color: #3498db;
                }
            """)
            
            field_layout.addWidget(label)
            field_layout.addWidget(widget)
            layout.addLayout(field_layout)
        
        # Pre-fill data if editing
        if self.is_edit:
            try:
                if len(self.expense_data) >= 6:
                    self.date_edit.setDate(datetime.strptime(self.expense_data[1], '%Y-%m-%d').date())
                    self.desc_input.setText(str(self.expense_data[2]))
                    
                    category_value = self.expense_data[3]
                    if isinstance(category_value, int):
                        categories = ["Bahan Baku", "Operasional", "Marketing", "Lainnya"]
                        if 0 <= category_value < len(categories):
                            self.category_combo.setCurrentText(categories[category_value])
                        else:
                            self.category_combo.setCurrentIndex(0)
                    else:
                        self.category_combo.setCurrentText(str(category_value))
                    
                    self.amount_input.setText(str(self.expense_data[4]))
                    
                    status_value = self.expense_data[5]
                    if isinstance(status_value, int):
                        statuses = ["Lunas", "Pending"]
                        if 0 <= status_value < len(statuses):
                            self.status_combo.setCurrentText(statuses[status_value])
                        else:
                            self.status_combo.setCurrentIndex(0)
                    else:
                        self.status_combo.setCurrentText(str(status_value))
                else:
                    self.desc_input.setText(str(self.expense_data[1]) if len(self.expense_data) > 1 else "")
                    self.amount_input.setText(str(self.expense_data[2]) if len(self.expense_data) > 2 else "")
                    
            except (ValueError, IndexError) as e:
                print(f"Error loading expense data: {e}")
        
        # Buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.setStyleSheet("""
            QPushButton {
                padding: 10px 20px;
                border: none;
                border-radius: 6px;
                font-weight: bold;
                min-width: 80px;
            }
            QPushButton[text="OK"] {
                background-color: #27ae60;
                color: white;
            }
            QPushButton[text="Cancel"] {
                background-color: #95a5a6;
                color: white;
            }
        """)
        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)
        
        layout.addWidget(button_box)
        self.setLayout(layout)
    
    def validate_and_accept(self):
        if not all([self.desc_input.text(), self.amount_input.text()]):
            QMessageBox.warning(self, "Error", "Harap isi semua field!")
            return
        
        try:
            amount = int(self.amount_input.text())
            if amount <= 0:
                QMessageBox.warning(self, "Error", "Jumlah harus lebih dari 0!")
                return
        except ValueError:
            QMessageBox.warning(self, "Error", "Jumlah harus angka!")
            return
        
        self.accept()
    
    def get_data(self):
        return {
            'date': self.date_edit.date().toString('yyyy-MM-dd'),
            'description': self.desc_input.text(),
            'category': self.category_combo.currentText(),
            'amount': int(self.amount_input.text()),
            'status': self.status_combo.currentText()
        }

class ExpensesWindow(QWidget):
    back_clicked = pyqtSignal()
    inventory_clicked = pyqtSignal()
    sales_clicked = pyqtSignal()
    reports_clicked = pyqtSignal()
    settings_clicked = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.init_ui()
        
    def init_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Header
        header = self.create_header()
        
        # Content dengan scroll area - DIPERBAIKI: Scroll area seperti inventory
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setStyleSheet("""
            QScrollArea { 
                border: none; 
                background-color: #f8f9fa;
            }
            QScrollBar:vertical {
                background-color: #e0e0e0;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background-color: #bdc3c7;
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #95a5a6;
            }
        """)
        
        # Content widget utama - DIPERBAIKI: Layout seperti inventory
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(20)  # Spacing lebih rapi
        
        # Page title - DIPERBAIKI: Layout vertikal seperti inventory
        page_title = QLabel("Pengeluaran")
        page_title.setFont(QFont("Arial", 24, QFont.Bold))
        page_title.setStyleSheet("color: #2c3e50; margin-bottom: 5px;")
        
        subtitle = QLabel("Kelola dan catat semua pengeluaran bisnis")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7f8c8d;")
        
        content_layout.addWidget(page_title)
        content_layout.addWidget(subtitle)
        
        # Search and filter section - DIPERBAIKI: Layout horizontal seperti inventory
        filter_section = QHBoxLayout()
        filter_section.setSpacing(15)
        
        # Search input
        search_input = QLineEdit()
        search_input.setPlaceholderText("🔍 Cari pengeluaran...")
        search_input.setFixedWidth(250)
        search_input.setStyleSheet("""
            QLineEdit {
                padding: 12px 15px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 14px;
                background-color: white;
            }
            QLineEdit:focus {
                border-color: #3498db;
            }
        """)
        
        # Category filter
        category_filter = QComboBox()
        category_filter.addItems(["Semua Kategori", "Bahan Baku", "Operasional", "Marketing", "Lainnya"])
        category_filter.setFixedWidth(180)
        category_filter.setStyleSheet("""
            QComboBox {
                padding: 12px 15px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 14px;
                background-color: white;
            }
        """)
        
        filter_section.addWidget(search_input)
        filter_section.addWidget(category_filter)
        filter_section.addStretch()
        
        content_layout.addLayout(filter_section)
        
        # Stats section - KEMBALIKAN SEPERTI SEMULA (seperti screenshot 245)
        stats_layout = QHBoxLayout()
        stats_layout.setSpacing(20)

        stats_data = [
            ("Total Pengeluaran", "Rp 8.250.000", "+5% dari bulan lalu", "#e74c3c", "📉"),
            ("Pengeluaran Bulan Ini", "Rp 1.250.000", "-2% dari target", "#3498db", "📊"),
            ("Rata-rata per Hari", "Rp 41.667", "+8% dari bulan lalu", "#f39c12", "📅"),
            ("Kategori Terbesar", "Bahan Baku", "42% dari total", "#9b59b6", "🏷️")
        ]

        for title, value, change, color, icon in stats_data:
            stat_card = self.create_stat_card_large(title, value, change, color, icon)
            stats_layout.addWidget(stat_card)

        stats_layout.addStretch()
        content_layout.addLayout(stats_layout)
        
        # Expenses table section - DIPERBAIKI: Layout seperti inventory
        table_section = QFrame()
        table_section.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
                border: 1px solid #e0e0e0;
            }
        """)
        
        table_layout = QVBoxLayout(table_section)
        table_layout.setSpacing(15)
        
        # Table header
        table_header = QHBoxLayout()
        table_title = QLabel("Pengeluaran Terbaru")
        table_title.setFont(QFont("Arial", 18, QFont.Bold))
        table_title.setStyleSheet("color: #2c3e50;")
        
        table_header.addWidget(table_title)
        table_header.addStretch()
        
        # Add expense button
        add_btn = QPushButton("➕ Tambah Pengeluaran")
        add_btn.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                color: white;
                padding: 12px 20px;
                border: none;
                border-radius: 8px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2ecc71;
            }
        """)
        add_btn.clicked.connect(self.add_expense)
        
        table_header.addWidget(add_btn)
        
        # Table - DIPERBAIKI: Style dan ukuran seperti inventory
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["TANGGAL", "DESKRIPSI", "KATEGORI", "JUMLAH", "STATUS", "AKSI"])
        
        # Style table seperti inventory
        self.table.setStyleSheet("""
            QTableWidget {
                background-color: white;
                border: none;
                gridline-color: #e9ecef;
                font-size: 14px;
                border-radius: 8px;
                alternate-background-color: #f8f9fa;
            }
            QTableWidget::item {
                padding: 16px 12px;
                border-bottom: 1px solid #e9ecef;
                font-size: 13px;
            }
            QTableWidget::item:selected {
                background-color: #3498db;
                color: white;
            }
            QHeaderView::section {
                background-color: #2c3e50;
                color: white;
                padding: 16px 12px;
                border: none;
                border-bottom: 2px solid #e9ecef;
                font-weight: bold;
                font-size: 13px;
            }
        """)
        
        self.table.verticalHeader().setDefaultSectionSize(65)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setMinimumHeight(400)
        
        table_layout.addLayout(table_header)
        table_layout.addWidget(self.table)
        
        content_layout.addWidget(table_section)
        content_layout.addStretch()
        
        scroll_area.setWidget(content_widget)
        
        # Add to main layout
        main_layout.addWidget(header)
        main_layout.addWidget(scroll_area, 1)
        
        self.setLayout(main_layout)
        self.setStyleSheet("background-color: #f8f9fa;")
        self.load_data()

    def create_stat_card_large(self, title, value, change, color, icon):
        """Membuat stat card besar dengan icon seperti screenshot 245"""
        stat_frame = QFrame()
        stat_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 25px;
                border: 1px solid #e0e0e0;
            }
        """)
        stat_frame.setMinimumHeight(350)
        stat_frame.setMinimumWidth(400)
        
        stat_layout = QVBoxLayout(stat_frame)
        stat_layout.setSpacing(8)
        
        # Header dengan icon
        header_layout = QHBoxLayout()
        icon_label = QLabel(icon)
        icon_label.setFont(QFont("Arial", 16))
        icon_label.setStyleSheet("color: %s;" % color)
        
        stat_title = QLabel(title)
        stat_title.setFont(QFont("Arial", 12))
        stat_title.setStyleSheet("color: #7f8c8d;")
        
        header_layout.addWidget(icon_label)
        header_layout.addWidget(stat_title)
        header_layout.addStretch()
        
        # Value
        value_label = QLabel(value)
        value_label.setFont(QFont("Arial", 18, QFont.Bold))
        value_label.setStyleSheet("color: %s; margin-top: 5px;" % color)
        
        # Change
        change_label = QLabel(change)
        change_label.setFont(QFont("Arial", 11))
        change_label.setStyleSheet("color: #7f8c8d; font-weight: bold;")
        
        stat_layout.addLayout(header_layout)
        stat_layout.addWidget(value_label)
        stat_layout.addWidget(change_label)
        stat_layout.addStretch()
        
        return stat_frame
    
    def create_header(self):
        header = QFrame()
        header.setFixedHeight(70)
        header.setStyleSheet("""
            QFrame {
                background-color: #2c3e50;
                color: white;
            }
        """)
        
        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(30, 15, 30, 15)
        
        title = QLabel("🏪 Fashion Finance")
        title.setFont(QFont("Arial", 20, QFont.Bold))
        
        nav_layout = QHBoxLayout()
        nav_layout.setSpacing(10)
        
        dashboard_btn = QPushButton("📊 Dashboard")
        inventory_btn = QPushButton("📦 Inventori")
        sales_btn = QPushButton("💳 Penjualan")
        expenses_btn = QPushButton("📋 Pengeluaran")
        reports_btn = QPushButton("📈 Laporan")
        settings_btn = QPushButton("⚙️ Pengaturan")
        logout_btn = QPushButton("🚪 Logout")
        
        menu_style = """
            QPushButton {
                color: white;
                border: none;
                padding: 12px 18px;
                background: transparent;
                font-size: 14px;
                font-weight: bold;
                border-radius: 6px;
                min-height: 25px;
            }
            QPushButton:hover {
                background-color: #34495e;
                border: 1px solid #5a6c7d;
            }
            QPushButton:disabled {
                background-color: #1abc9c;
                color: white;
                border: 1px solid #16a085;
            }
        """
        
        for btn in [dashboard_btn, inventory_btn, sales_btn, expenses_btn, reports_btn, settings_btn, logout_btn]:
            btn.setStyleSheet(menu_style)
        
        expenses_btn.setEnabled(False)
        dashboard_btn.clicked.connect(self.back_clicked.emit)
        inventory_btn.clicked.connect(self.inventory_clicked.emit)
        sales_btn.clicked.connect(self.sales_clicked.emit)
        reports_btn.clicked.connect(self.reports_clicked.emit)
        settings_btn.clicked.connect(self.settings_clicked.emit)
        logout_btn.clicked.connect(self.back_to_login)
        
        nav_layout.addWidget(dashboard_btn)
        nav_layout.addWidget(inventory_btn)
        nav_layout.addWidget(sales_btn)
        nav_layout.addWidget(expenses_btn)
        nav_layout.addWidget(reports_btn)
        nav_layout.addWidget(settings_btn)
        nav_layout.addStretch()
        nav_layout.addWidget(logout_btn)
        
        header_layout.addWidget(title)
        header_layout.addStretch()
        header_layout.addLayout(nav_layout)
        header.setLayout(header_layout)
        
        return header
    
    def load_data(self):
        # Data dummy
        dummy_expenses = [
            (1, "2024-01-15", "Pembelian Kain Katun\nSupplier: PT Tekstil Jaya", "Bahan Baku", 1500000, "Lunas"),
            (2, "2024-01-14", "Biaya Listrik Toko\nBulan Desember 2023", "Operasional", 450000, "Lunas"),
            (3, "2024-01-13", "Iklan Facebook Ads\nKampanye Januari 2024", "Marketing", 750000, "Pending"),
            (4, "2024-01-12", "Gaji Karyawan\nBulan Januari 2024", "Operasional", 3200000, "Lunas"),
            (5, "2024-01-10", "Pembuatan Banner Promo\nUkuran 2x3 meter", "Marketing", 650000, "Lunas")
        ]
        
        # Load expenses table
        self.table.setRowCount(len(dummy_expenses))
        
        for row, expense in enumerate(dummy_expenses):
            # Date - format lebih user friendly
            date_obj = datetime.strptime(expense[1], '%Y-%m-%d')
            date_text = date_obj.strftime('%d %b %Y')
            date_item = QTableWidgetItem(date_text)
            
            # Description dengan format multi-line
            desc_item = QTableWidgetItem(expense[2])
            
            # Category dengan icon
            category_icon = ""
            if expense[3] == "Bahan Baku": category_icon = "🧵"
            elif expense[3] == "Operasional": category_icon = "⚡"
            elif expense[3] == "Marketing": category_icon = "📢"
            else: category_icon = "📦"
            category_item = QTableWidgetItem(f"{category_icon} {expense[3]}")
            
            # Amount - Format currency Indonesia
            amount = expense[4]
            if isinstance(amount, (int, float)):
                amount_text = f"Rp {amount:,.0f}".replace(',', '.')
            else:
                amount_text = f"Rp {amount}"
            amount_item = QTableWidgetItem(amount_text)
            
            # Status dengan warna dan style
            status = expense[5]
            status_item = QTableWidgetItem(status)
            if status == "Lunas":
                status_item.setForeground(Qt.darkGreen)
                status_item.setFont(QFont("Arial", 11, QFont.Bold))
            else:
                status_item.setForeground(Qt.darkRed)
                status_item.setFont(QFont("Arial", 11, QFont.Bold))
            
            # Action buttons
            action_widget = QWidget()
            action_layout = QHBoxLayout(action_widget)
            action_layout.setContentsMargins(8, 5, 8, 5)
            action_layout.setSpacing(8)
            
            edit_btn = QPushButton("✏️ Edit")
            delete_btn = QPushButton("🗑️ Hapus")
            
            edit_btn.setStyleSheet("""
                QPushButton {
                    background-color: #3498db;
                    color: white;
                    border: none;
                    padding: 8px 12px;
                    border-radius: 6px;
                    font-size: 12px;
                    font-weight: bold;
                    min-width: 60px;
                }
                QPushButton:hover {
                    background-color: #2980b9;
                }
            """)
            
            delete_btn.setStyleSheet("""
                QPushButton {
                    background-color: #e74c3c;
                    color: white;
                    border: none;
                    padding: 8px 12px;
                    border-radius: 6px;
                    font-size: 12px;
                    font-weight: bold;
                    min-width: 60px;
                }
                QPushButton:hover {
                    background-color: #c0392b;
                }
            """)
            
            edit_btn.clicked.connect(lambda checked, e=expense: self.edit_expense(e))
            delete_btn.clicked.connect(lambda checked, e=expense: self.delete_expense(e))
            
            action_layout.addWidget(edit_btn)
            action_layout.addWidget(delete_btn)
            action_layout.addStretch()
            
            # Set items
            self.table.setItem(row, 0, date_item)
            self.table.setItem(row, 1, desc_item)
            self.table.setItem(row, 2, category_item)
            self.table.setItem(row, 3, amount_item)
            self.table.setItem(row, 4, status_item)
            self.table.setCellWidget(row, 5, action_widget)
    
    def add_expense(self):
        dialog = AddExpenseDialog(self)
        if dialog.exec_():
            data = dialog.get_data()
            QMessageBox.information(self, "Sukses", "✅ Pengeluaran berhasil ditambahkan!")
            self.load_data()
    
    def edit_expense(self, expense):
        dialog = AddExpenseDialog(self, expense)
        if dialog.exec_():
            data = dialog.get_data()
            QMessageBox.information(self, "Sukses", "✅ Pengeluaran berhasil diupdate!")
            self.load_data()
    
    def delete_expense(self, expense):
        reply = QMessageBox.question(self, "Konfirmasi", 
                                   f"Apakah Anda yakin ingin menghapus pengeluaran '{expense[2].split(chr(10))[0]}'?",
                                   QMessageBox.Yes | QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            QMessageBox.information(self, "Sukses", "✅ Pengeluaran berhasil dihapus!")
            self.load_data()
    
    def back_to_login(self):
        reply = QMessageBox.question(self, "Konfirmasi", 
                                   "Apakah Anda yakin ingin logout?",
                                   QMessageBox.Yes | QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            self.back_clicked.emit()