"""
Development Server with Auto-Reload
Automatically restarts the application when code changes are detected.

Usage:
    python dev_server.py

This will monitor all .py files in the project and restart main.py when changes are detected.
"""

import os
import sys
import time
import subprocess
from pathlib import Path
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

class CodeChangeHandler(FileSystemEventHandler):
    """Handler for file system events"""
    
    def __init__(self, restart_callback):
        self.restart_callback = restart_callback
        self.last_restart = 0
        self.debounce_seconds = 1  # Wait 1 second before restarting
        
    def on_modified(self, event):
        """Called when a file is modified"""
        if event.is_directory:
            return
            
        # Only watch Python files
        if not event.src_path.endswith('.py'):
            return
            
        # Debounce: prevent multiple restarts in quick succession
        current_time = time.time()
        if current_time - self.last_restart < self.debounce_seconds:
            return
            
        self.last_restart = current_time
        print(f"\n[CHANGE DETECTED] {event.src_path}")
        self.restart_callback()

class DevServer:
    """Development server with auto-reload functionality"""
    
    def __init__(self, script_path='main.py', watch_dirs=None):
        self.script_path = script_path
        self.watch_dirs = watch_dirs or ['.']
        self.process = None
        self.observer = None
        
    def start_app(self):
        """Start the application"""
        if self.process:
            self.stop_app()
            
        print("\n" + "="*60)
        print("[STARTING] Fashion Finance Application...")
        print("="*60)
        
        try:
            # Start the application as a subprocess
            self.process = subprocess.Popen(
                [sys.executable, self.script_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1
            )
            
            print(f"[OK] Application started (PID: {self.process.pid})")
            print("[INFO] Watching for file changes...")
            print("="*60 + "\n")
            
            # Print output in real-time
            self._print_output()
            
        except Exception as e:
            print(f"[ERROR] Failed to start application: {e}")
    
    def _print_output(self):
        """Print application output in real-time"""
        try:
            for line in iter(self.process.stdout.readline, ''):
                if line:
                    print(line.rstrip())
        except Exception:
            pass
    
    def stop_app(self):
        """Stop the application"""
        if self.process:
            print("\n[STOPPING] Application...")
            try:
                self.process.terminate()
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                print("[WARNING] Process didn't terminate, killing...")
                self.process.kill()
            except Exception as e:
                print(f"[ERROR] Error stopping process: {e}")
            finally:
                self.process = None
                print("[OK] Application stopped\n")
    
    def restart_app(self):
        """Restart the application"""
        print("\n" + "="*60)
        print("[RESTARTING] Reloading application...")
        print("="*60)
        self.start_app()
    
    def start_watching(self):
        """Start watching for file changes"""
        event_handler = CodeChangeHandler(self.restart_app)
        self.observer = Observer()
        
        # Watch all specified directories
        for watch_dir in self.watch_dirs:
            path = Path(watch_dir).resolve()
            if path.exists():
                self.observer.schedule(event_handler, str(path), recursive=True)
                print(f"[WATCH] Monitoring: {path}")
        
        self.observer.start()
        print("[INFO] File watcher started")
        print("[INFO] Press Ctrl+C to stop\n")
    
    def run(self):
        """Run the development server"""
        print("\n" + "="*60)
        print("FASHION FINANCE - DEVELOPMENT SERVER")
        print("="*60)
        print("[INFO] Auto-reload enabled")
        print("[INFO] Watching .py files for changes")
        print("="*60 + "\n")
        
        try:
            # Start watching for changes
            self.start_watching()
            
            # Start the application
            self.start_app()
            
            # Keep the script running
            while True:
                time.sleep(1)
                
                # Check if process is still running
                if self.process and self.process.poll() is not None:
                    print("\n[WARNING] Application exited")
                    print("[INFO] Waiting for file changes to restart...")
                    self.process = None
                    
        except KeyboardInterrupt:
            print("\n\n[SHUTDOWN] Stopping development server...")
            self.stop_app()
            if self.observer:
                self.observer.stop()
                self.observer.join()
            print("[OK] Development server stopped")
            print("="*60 + "\n")

def main():
    """Main function"""
    # Configuration
    SCRIPT_PATH = 'main.py'
    WATCH_DIRS = [
        '.',           # Root directory
        'app',         # App directory
    ]
    
    # Exclude directories (not watched)
    EXCLUDE_DIRS = [
        '__pycache__',
        '.git',
        'venv',
        'env',
        'images'
    ]
    
    # Check if watchdog is installed
    try:
        import watchdog
    except ImportError:
        print("\n[ERROR] 'watchdog' package is not installed")
        print("\n[FIX] Install it with:")
        print("   pip install watchdog")
        print("\nOr run:")
        print("   pip install -r requirements.txt")
        sys.exit(1)
    
    # Check if main.py exists
    if not os.path.exists(SCRIPT_PATH):
        print(f"\n[ERROR] {SCRIPT_PATH} not found")
        print(f"[INFO] Make sure you're in the project directory")
        sys.exit(1)
    
    # Start the development server
    server = DevServer(SCRIPT_PATH, WATCH_DIRS)
    server.run()

if __name__ == "__main__":
    main()
